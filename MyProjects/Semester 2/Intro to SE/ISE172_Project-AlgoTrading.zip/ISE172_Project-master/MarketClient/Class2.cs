﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MarketClient.DataEntries;
using MarketClient.Utils;
using MarketClient;
using BL;

namespace MarketClient
{

    public class Class2
    {
        private const string Url = "http://ise172.ise.bgu.ac.il";
        private const string User = "user39";
        private const string PrivateKey =
        @"-----BEGIN RSA PRIVATE KEY-----
        MIICXQIBAAKBgQDFVnV4cmYNmsxUxwmyZaiEQ8UP77yObHTxNlwDFmBAgS60svyr
        v8ogpSDCYtS11zBIUlZMgdiUmNblc1EzrhVvJgd7vAWD8d2hqK71FoifQYWP54gp
        5EAMsLSLKUIZNXDSuTD4xMwsCx/akU+nCMEiiuKBNKJFu0u38xY5V/fI7QIDAQAB
        AoGBAIXTKD7SddrsC33CrRTKVAm+W7l+/wQnEPczwhpl5khYUvBAIZHnso+I7Dpn
        A5F9qUSicdvYgqPjMnjQR1UgzW8tW6FvpVe0Y9d2B/ZfAkjaPdHX9MC8Q2omo3qU
        BSasN5ls7DyUbqdjqvOFsgtx1b/Y+Ym54Ggh8jMK0y1RuvMRAkEA0S7lNSQw/IlQ
        oB+AiBU/IsMBH1hSkqGDBMq/vtjULnmtqGsnXlWQb83KmAhUTbyl1GCMyAcn4wND
        zvbLv/WVgwJBAPGA4XsdGBqE1xIaM4URzQc+WjeMY8QmwsDe1+3tKNFuC8OrqJ18
        4DUID9TvZSPvlHmJAzgtV2LDsK9Xk4krTM8CQHQecCYbvQWyxAre8d6YzL9jOJBJ
        2yyCc9SJJ/+tJbvW18uSD/yRyugFeN0EYqf0fKl0HzI6pq2h9lZBMcGRdjkCQQCU
        pD+j9+9K+zIouSm2oJMx/yWmBOmu5DCAZ2g9z/eMl4/0GiaI8EBLQ7AC3mnA6YfY
        GgV6QSYE6u9HrL5o8davAkAzF9bt78+GsxoR3VPQlh7gtQvlVirNyxArbj7bPCS2
        WfMJyweydEvMfN4DgcoK8an3F7wkuM9KHNcXiWVYbx1G
        -----END RSA PRIVATE KEY-----";

        //private string token = SimpleCtyptoLibrary.CreateToken(User, PrivateKey);
        public Class2()
        {

        }
        public int CommodityBidPrice(int commodity)
        {
            SimpleHTTPClient SHC = new SimpleHTTPClient();
            QueryMarketRequest request = new QueryMarketRequest(commodity);
            CommodityOffer output = SHC.SendPostRequest<QueryMarketRequest, CommodityOffer>(Url, User, PrivateKey, request);
            return output.bid;
        }
        public int CommodityAskPrice(int commodity)
        {
            SimpleHTTPClient SHC = new SimpleHTTPClient();
            QueryMarketRequest request = new QueryMarketRequest(commodity);
            CommodityOffer output = SHC.SendPostRequest<QueryMarketRequest, CommodityOffer>(Url, User, PrivateKey, request);
            return output.ask;
        }
        public int getUserCommodity(int commodity)
        {
            SimpleHTTPClient SHC = new SimpleHTTPClient();
            QueryUserRequest request = new QueryUserRequest();
            UserData output = SHC.SendPostRequest<QueryUserRequest, UserData>(Url, User, PrivateKey, request);
            return output.findMyCommodities(commodity);

        }
        public double getUserFunds()
        {
            SimpleHTTPClient SHC = new SimpleHTTPClient();
            QueryUserRequest request = new QueryUserRequest();
            UserData output = SHC.SendPostRequest<QueryUserRequest, UserData>(Url, User, PrivateKey, request);
            return output.findMyFunds();

        }
        public string cancelTopXRequests(int x) //returns a string of all the requests canceled
        {
            //initializes variables
            MarketClient.Class1 class1Instance = new Class1();
            SimpleHTTPClient SHC = new SimpleHTTPClient();
            QueryUserRequest request = new QueryUserRequest();
            UserData userData = SHC.SendPostRequest<QueryUserRequest, UserData>(Url, User, PrivateKey, request);
            int requestsDeleted = 0; //number of requests canceled
            string output = ""; //output
            foreach (int requestID in userData.requests) //foreach request in userData
            {
                if (requestsDeleted < x) //if havnt deleted x requests yet, cancel this request
                {
                    class1Instance.SendCancelBuySellRequest(requestID);
                    output = output +" "+ requestID;
                    requestsDeleted++;
                }
            }
            return output;
        }
        public int getAmountOfRequests()
        {
            SimpleHTTPClient SHC = new SimpleHTTPClient();
            QueryUserRequest request = new QueryUserRequest();
            UserData userData = SHC.SendPostRequest<QueryUserRequest, UserData>(Url, User, PrivateKey, request);
            int output = 0;
            foreach (int requestID in userData.requests) //foreach request in userData
            {
                output++;
            }
            return output;
        }
    }
}
