﻿using log4net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketClient
{
    class History
    {
        private ILog specialLogger2 = LogManager.GetLogger("MyFileAppender");

        public void wrhighTHistory(string type, int price, int amount, int commodity, int id, string status)
        {
            specialLogger2.Info("." + type + "." + price + "." + amount + "." + commodity + "." + id + "." + status);
        }

    }
}
