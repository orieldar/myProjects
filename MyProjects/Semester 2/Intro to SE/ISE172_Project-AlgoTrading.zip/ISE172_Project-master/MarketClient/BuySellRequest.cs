﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
    class BuySellRequest
    {
        public int commodity;
        public int price;
        public int amount;
        public string type;

        public BuySellRequest(int commodity, int price, int amount, string type)
        {
            this.commodity = commodity;
            this.price = price;
            this.amount = amount;
            this.type = type;
        }


    }
}
