﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketClient
{
    public class AllUserRequestsData
    {
        public int id;
        public ItemQuery request;
        public AllUserRequestsData(int id, ItemQuery request)
        {
            this.id = id;
            this.request = request;
        }
        public override string ToString()
        {
            String output = "Request ID: " + id + "\n" + request.ToString();
            return output;
        }
    }
}
