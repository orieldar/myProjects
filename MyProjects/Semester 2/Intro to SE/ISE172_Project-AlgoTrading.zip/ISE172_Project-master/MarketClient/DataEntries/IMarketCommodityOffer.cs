﻿namespace MarketClient.DataEntries
{
    public interface IMarketCommodityOffer
    {
    }
}
