﻿using System.Net.Http;
using MarketClient.Utils;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Security.Cryptography;

using System.Text;
using System;
namespace MarketClient
{
    public class SimpleHTTPClient
    {
        private const string PrivateKey =
         @"-----BEGIN RSA PRIVATE KEY-----
        MIICXQIBAAKBgQDFVnV4cmYNmsxUxwmyZaiEQ8UP77yObHTxNlwDFmBAgS60svyr
        v8ogpSDCYtS11zBIUlZMgdiUmNblc1EzrhVvJgd7vAWD8d2hqK71FoifQYWP54gp
        5EAMsLSLKUIZNXDSuTD4xMwsCx/akU+nCMEiiuKBNKJFu0u38xY5V/fI7QIDAQAB
        AoGBAIXTKD7SddrsC33CrRTKVAm+W7l+/wQnEPczwhpl5khYUvBAIZHnso+I7Dpn
        A5F9qUSicdvYgqPjMnjQR1UgzW8tW6FvpVe0Y9d2B/ZfAkjaPdHX9MC8Q2omo3qU
        BSasN5ls7DyUbqdjqvOFsgtx1b/Y+Ym54Ggh8jMK0y1RuvMRAkEA0S7lNSQw/IlQ
        oB+AiBU/IsMBH1hSkqGDBMq/vtjULnmtqGsnXlWQb83KmAhUTbyl1GCMyAcn4wND
        zvbLv/WVgwJBAPGA4XsdGBqE1xIaM4URzQc+WjeMY8QmwsDe1+3tKNFuC8OrqJ18
        4DUID9TvZSPvlHmJAzgtV2LDsK9Xk4krTM8CQHQecCYbvQWyxAre8d6YzL9jOJBJ
        2yyCc9SJJ/+tJbvW18uSD/yRyugFeN0EYqf0fKl0HzI6pq2h9lZBMcGRdjkCQQCU
        pD+j9+9K+zIouSm2oJMx/yWmBOmu5DCAZ2g9z/eMl4/0GiaI8EBLQ7AC3mnA6YfY
        GgV6QSYE6u9HrL5o8davAkAzF9bt78+GsxoR3VPQlh7gtQvlVirNyxArbj7bPCS2
        WfMJyweydEvMfN4DgcoK8an3F7wkuM9KHNcXiWVYbx1G
        -----END RSA PRIVATE KEY-----";
        /// <summary>
        /// Send an object of type T1, @item, parsed as json string embedded with the 
        /// authentication token, that is build using @user and @token, 
        /// as an HTTP post request to server at address @url.
        /// This method parse the reserver response using JSON to object of type T2.
        /// </summary>
        /// <typeparam name="T1">Type of the data object to send</typeparam>
        /// <typeparam name="T2">Type of the return object</typeparam>
        /// <param name="url">address of the server</param>
        /// <param name="user">username for authentication data</param>
        /// <param name="token">token for authentication data</param>
        /// <param name="item">the data item to send in the reuqest</param>
        /// <returns>the server response parsed as T2 object in json format</returns>
        public T2 SendPostRequest<T1, T2>(string url, string user, string privateKey, T1 item) where T2 : class
        {
            var response = SendPostRequest(url, user, PrivateKey, item);
            if (response is string && response != "Non unique nonce")
                return response == null ? null : FromJson<T2>(response);
            else // If nonce is non unique, try again with a different one
                return SendPostRequest<T1, T2>(url, user, PrivateKey, item);
            //var response = SendPostRequest(url, user, privateKey, item);
            //  return response == null ? null : FromJson<T2>(response);
        }

        /// <summary>
        /// Send an object of type T1, @item, parsed as json string embedded with the 
        /// authentication token, that is build using @user and @token, 
        /// as an HTTP post request to server at address @url.
        /// This method reutens the server response as is.
        /// </summary>
        /// <typeparam name="T1">Type of the data object to send</typeparam>
        /// <param name="url">address of the server</param>
        /// <param name="user">username for authentication data</param>
        /// <param name="token">token for authentication data</param>
        /// <param name="item">the data item to send in the reuqest</param>
        /// <returns>the server response</returns>
        public string SendPostRequest<T1>(string url, string user, string privateKey, T1 item)
        {
            while (true)
            {
                try
                {
                    Random random = new Random();
                    int nonce = random.Next(int.MinValue, int.MaxValue); ;//get uniqe value for nonce
                    string token = SimpleCtyptoLibrary.CreateToken(user, privateKey, nonce); //create new token with unique nonce
                    var auth = new { user, token, nonce };
                    JObject jsonItem = JObject.FromObject(item);
                    jsonItem.Add("auth", JObject.FromObject(auth));
                    StringContent content = new StringContent(jsonItem.ToString());

                    using (var client = new HttpClient())
                    {

                        var result = client.PostAsync(url, content).Result;
                        var responseContent = result?.Content?.ReadAsStringAsync().Result;
                        if (responseContent != "Verification failure")
                        {
                            return SimpleCtyptoLibrary.decrypt(responseContent, privateKey);
                        }
                    }
                }

                catch (Exception E)
                {
                    if (E.Message != "Verification failure")
                        throw E;

                }
            }
        }


        private static T FromJson<T>(string response) where T : class
        {
            if (response == null)
            {
                return null;
            }
            try
            {
                return JsonConvert.DeserializeObject<T>(response, new JsonSerializerSettings
                {
                    Error = delegate
                    {
                        throw new JsonException(response);
                    }
                });
            }
            catch
            {
                throw new MarketException(response);
            }
        }
        public string SendPostRequestNonce<T1>(string url, string user, int nonce, T1 item)
        {



            string token = SimpleCtyptoLibrary.CreateToken(user, PrivateKey, nonce);
            var auth = new { user, nonce, token };
            JObject jsonItem = JObject.FromObject(item);
            jsonItem.Add("auth", JObject.FromObject(auth));
            StringContent content = new StringContent(jsonItem.ToString());
            using (var client = new HttpClient())
            {
                var result = client.PostAsync(url, content).Result;
                var responseContent = result?.Content?.ReadAsStringAsync().Result;

                return responseContent;



            }
        }
    }
}

/*using System.Net.Http;
using MarketClient.Utils;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Security.Cryptography;

using System.Text;
using System;
namespace MarketClient
{
    public class SimpleHTTPClient
    {
        private const string PrivateKey =
         @"-----BEGIN RSA PRIVATE KEY-----
        MIICXQIBAAKBgQDFVnV4cmYNmsxUxwmyZaiEQ8UP77yObHTxNlwDFmBAgS60svyr
        v8ogpSDCYtS11zBIUlZMgdiUmNblc1EzrhVvJgd7vAWD8d2hqK71FoifQYWP54gp
        5EAMsLSLKUIZNXDSuTD4xMwsCx/akU+nCMEiiuKBNKJFu0u38xY5V/fI7QIDAQAB
        AoGBAIXTKD7SddrsC33CrRTKVAm+W7l+/wQnEPczwhpl5khYUvBAIZHnso+I7Dpn
        A5F9qUSicdvYgqPjMnjQR1UgzW8tW6FvpVe0Y9d2B/ZfAkjaPdHX9MC8Q2omo3qU
        BSasN5ls7DyUbqdjqvOFsgtx1b/Y+Ym54Ggh8jMK0y1RuvMRAkEA0S7lNSQw/IlQ
        oB+AiBU/IsMBH1hSkqGDBMq/vtjULnmtqGsnXlWQb83KmAhUTbyl1GCMyAcn4wND
        zvbLv/WVgwJBAPGA4XsdGBqE1xIaM4URzQc+WjeMY8QmwsDe1+3tKNFuC8OrqJ18
        4DUID9TvZSPvlHmJAzgtV2LDsK9Xk4krTM8CQHQecCYbvQWyxAre8d6YzL9jOJBJ
        2yyCc9SJJ/+tJbvW18uSD/yRyugFeN0EYqf0fKl0HzI6pq2h9lZBMcGRdjkCQQCU
        pD+j9+9K+zIouSm2oJMx/yWmBOmu5DCAZ2g9z/eMl4/0GiaI8EBLQ7AC3mnA6YfY
        GgV6QSYE6u9HrL5o8davAkAzF9bt78+GsxoR3VPQlh7gtQvlVirNyxArbj7bPCS2
        WfMJyweydEvMfN4DgcoK8an3F7wkuM9KHNcXiWVYbx1G
        -----END RSA PRIVATE KEY-----";
        /// <summary>
        /// Send an object of type T1, @item, parsed as json string embedded with the 
        /// authentication token, that is build using @user and @token, 
        /// as an HTTP post request to server at address @url.
        /// This method parse the reserver response using JSON to object of type T2.
        /// </summary>
        /// <typeparam name="T1">Type of the data object to send</typeparam>
        /// <typeparam name="T2">Type of the return object</typeparam>
        /// <param name="url">address of the server</param>
        /// <param name="user">username for authentication data</param>
        /// <param name="token">token for authentication data</param>
        /// <param name="item">the data item to send in the reuqest</param>
        /// <returns>the server response parsed as T2 object in json format</returns>
        public T2 SendPostRequest<T1, T2>(string url, string user, T1 item) where T2 : class
        {
            var response = SendPostRequest(url, user, item);
            return response == null ? null : FromJson<T2>(response);
            /*if (response is string && response != "Non unique nonce")
                return response == null ? null : FromJson<T2>(response);
            else 
                return SendPostRequest<T1, T2>(url, user, item);
           
        }

        /// <summary>
        /// Send an object of type T1, @item, parsed as json string embedded with the 
        /// authentication token, that is build using @user and @token, 
        /// as an HTTP post request to server at address @url.
        /// This method reutens the server response as is.
        /// </summary>
        /// <typeparam name="T1">Type of the data object to send</typeparam>
        /// <param name="url">address of the server</param>
        /// <param name="user">username for authentication data</param>
        /// <param name="token">token for authentication data</param>
        /// <param name="item">the data item to send in the reuqest</param>
        /// <returns>the server response</returns>
        public string SendPostRequest<T1>(string url, string user, T1 item)
        {

            Random random = new Random();
            int nonce = random.Next(int.MinValue, int.MaxValue); ;//unique nonce
            string token = SimpleCtyptoLibrary.CreateToken(user, nonce, PrivateKey); //create new token with unique nonce
            var auth = new { user, nonce, token };
            JObject jsonItem = JObject.FromObject(item);
            jsonItem.Add("auth", JObject.FromObject(auth));
            StringContent content = new StringContent(jsonItem.ToString());

            //var auth = new { user, token };
            //JObject jsonItem = JObject.FromObject(item);
            //jsonItem.Add("auth", JObject.FromObject(auth));
            //StringContent content = new StringContent(jsonItem.ToString());


            using (var client = new HttpClient())
            {
                var result = client.PostAsync(url, content).Result;
                var responseContent = result?.Content?.ReadAsStringAsync().Result;
                if (responseContent is string && responseContent != "Non unique nonce")
                    return responseContent;
                else 
                    return SendPostRequest<T1>(url, user, item);

            }
        }

        public static string decrypt(string message, string privateKey)
        {
            RSACryptoServiceProvider rsaAlgo = new RSACryptoServiceProvider();
            rsaAlgo.ImportParameters(SimpleCtyptoLibrary.ExtractRSAPrivateKey(privateKey));
            byte[] encrypted = Convert.FromBase64String(message);
            StringBuilder decrypted = new StringBuilder();

            for (int i = 0; i < encrypted.Length; i += 128)
            {
                byte[] block = new byte[128];
                Array.Copy(encrypted, i, block, 0, Math.Min(encrypted.Length - i, 128));
                String decblock = Encoding.ASCII.GetString(rsaAlgo.Decrypt(block, false));
                decrypted.Append(decblock);
            }

            return decrypted.ToString();
        }

        /*
        public static string decrypt(string message, string privateKey)
        {
            RSACryptoServiceProvider rsaAlgo = new RSACryptoServiceProvider();
            rsaAlgo.ImportParameters(SimpleCtyptoLibrary.ExtractRSAPrivateKey(privateKey));
            Console.WriteLine(message);
            Console.ReadLine();
            byte[] encrypted = Convert.FromBase64String(message);
            StringBuilder decrypted = new StringBuilder();

            for (int i = 0; i < encrypted.Length; i += 128)
            {
                byte[] block = new byte[128];
                Array.Copy(encrypted, i, block, 0, Math.Min(encrypted.Length - i, 128));
                String decblock = Encoding.ASCII.GetString(rsaAlgo.Decrypt(block, false));
                decrypted.Append(decblock);
            }

            return decrypted.ToString();
        }
        

        public string SendPostRequestNonce<T1>(string url, string user, int nonce, T1 item)
        {



            string token = SimpleCtyptoLibrary.CreateToken(user, nonce, PrivateKey);
            var auth = new { user, nonce, token };
            JObject jsonItem = JObject.FromObject(item);
            jsonItem.Add("auth", JObject.FromObject(auth));
            StringContent content = new StringContent(jsonItem.ToString());
            using (var client = new HttpClient())
            {
                var result = client.PostAsync(url, content).Result;
                var responseContent = result?.Content?.ReadAsStringAsync().Result;

                return responseContent;



            }

        }

        private static T FromJson<T>(string response) where T : class
        {
            response = decrypt(response, PrivateKey);

            if (response == null)
            {
                return null;
            }
            try
            {
                return JsonConvert.DeserializeObject<T>(response, new JsonSerializerSettings
                {
                    Error = delegate {
                        throw new JsonException(response);
                    }
                });
            }
            catch
            {
                throw new MarketException(response);
            }
        }
    }
}*/
