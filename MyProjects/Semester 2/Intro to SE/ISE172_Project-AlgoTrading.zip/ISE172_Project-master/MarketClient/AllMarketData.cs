﻿using MarketClient.DataEntries;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketClient
{
    public class AllMarketData
    {
        public int id;
        public CommodityOffer info;
        public AllMarketData(int id, CommodityOffer info)
        {
            this.id = id;
            this.info = info;
        }
        public override String ToString()
        {
            String output = "Commodity ID: "+id+ "\n"+info.ToString();
            return output;
        }
    }
}
