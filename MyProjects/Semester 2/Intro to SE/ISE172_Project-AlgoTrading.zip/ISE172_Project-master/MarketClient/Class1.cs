﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MarketClient.DataEntries;
using MarketClient.Utils;
using MarketClient;
using BL;
using System.Security.Cryptography;

namespace MarketClient
{
    public class Class1 : IMarketClient
    {
        private const string Url = "http://ise172.ise.bgu.ac.il";
        private const string User = "user39";
        private const string PrivateKey = 
        @"-----BEGIN RSA PRIVATE KEY-----
        MIICXQIBAAKBgQDFVnV4cmYNmsxUxwmyZaiEQ8UP77yObHTxNlwDFmBAgS60svyr
        v8ogpSDCYtS11zBIUlZMgdiUmNblc1EzrhVvJgd7vAWD8d2hqK71FoifQYWP54gp
        5EAMsLSLKUIZNXDSuTD4xMwsCx/akU+nCMEiiuKBNKJFu0u38xY5V/fI7QIDAQAB
        AoGBAIXTKD7SddrsC33CrRTKVAm+W7l+/wQnEPczwhpl5khYUvBAIZHnso+I7Dpn
        A5F9qUSicdvYgqPjMnjQR1UgzW8tW6FvpVe0Y9d2B/ZfAkjaPdHX9MC8Q2omo3qU
        BSasN5ls7DyUbqdjqvOFsgtx1b/Y+Ym54Ggh8jMK0y1RuvMRAkEA0S7lNSQw/IlQ
        oB+AiBU/IsMBH1hSkqGDBMq/vtjULnmtqGsnXlWQb83KmAhUTbyl1GCMyAcn4wND
        zvbLv/WVgwJBAPGA4XsdGBqE1xIaM4URzQc+WjeMY8QmwsDe1+3tKNFuC8OrqJ18
        4DUID9TvZSPvlHmJAzgtV2LDsK9Xk4krTM8CQHQecCYbvQWyxAre8d6YzL9jOJBJ
        2yyCc9SJJ/+tJbvW18uSD/yRyugFeN0EYqf0fKl0HzI6pq2h9lZBMcGRdjkCQQCU
        pD+j9+9K+zIouSm2oJMx/yWmBOmu5DCAZ2g9z/eMl4/0GiaI8EBLQ7AC3mnA6YfY
        GgV6QSYE6u9HrL5o8davAkAzF9bt78+GsxoR3VPQlh7gtQvlVirNyxArbj7bPCS2
        WfMJyweydEvMfN4DgcoK8an3F7wkuM9KHNcXiWVYbx1G
        -----END RSA PRIVATE KEY-----";

        //private string token = SimpleCtyptoLibrary.CreateToken(User, PrivateKey);
        //SimpleHTTPClient SHC = new SimpleHTTPClient();

        public int SendBuyRequest(int price, int commodity, int amount)
        {

            BuySellRequest buy = new BuySellRequest(commodity, price, amount, "buy");
            string res = client.SendPostRequest(Url,User,PrivateKey,buy);
            try
            {
                return Int32.Parse(res);
            }
            catch(Exception e)
            {
                throw new Exception(res);
            }
            SimpleHTTPClient SHC = new SimpleHTTPClient();
            BuySellRequest request = new BuySellRequest(commodity, price, amount, "buy");
            /*var output = SHC.SendPostRequest(Url, User,PrivateKey, request);
            string s = decrypt(output, PrivateKey);
            try
            {
                return Int32.Parse(s);
            }
            catch (FormatException e)
            {
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("---"+s+"---");
                Console.ResetColor();
                throw new Exception(s);
            }
            */

        }

        public bool SendCancelBuySellRequest(int id)
        {
            SimpleHTTPClient SHC = new SimpleHTTPClient();
            CancelRequest request = new CancelRequest(id);
            string s = SHC.SendPostRequest(Url, User,PrivateKey, request);
            //string s = decrypt(output, PrivateKey);
            if (s.Equals("Ok"))
            {
                return true;
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine();
                Console.WriteLine("---"+s+"---");
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                Console.WriteLine("Returning to main menu (Enter new command)");
                Console.ResetColor();
                return false;
            }
        }

        public IMarketItemQuery SendQueryBuySellRequest(int id)
        {
            SimpleHTTPClient SHC = new SimpleHTTPClient();
            QuerySellBuyRequest request = new QuerySellBuyRequest(id);
            ItemQuery output = SHC.SendPostRequest<QuerySellBuyRequest, ItemQuery>(Url, User, PrivateKey, request);
            return output;
        }

        public IMarketCommodityOffer SendQueryMarketRequest(int commodity)
        {
            SimpleHTTPClient SHC = new SimpleHTTPClient();
            QueryMarketRequest request = new QueryMarketRequest(commodity);
            CommodityOffer output = SHC.SendPostRequest<QueryMarketRequest, CommodityOffer>(Url, User, PrivateKey, request);
            return output;
        }

        public IMarketUserData SendQueryUserRequest()
        {
            SimpleHTTPClient SHC = new SimpleHTTPClient();
            QueryUserRequest request = new QueryUserRequest();
            UserData output = SHC.SendPostRequest<QueryUserRequest,UserData>(Url, User, PrivateKey, request);
            return output;

        }

        public int SendSellRequest(int price, int commodity, int amount)
        {/*
            SimpleHTTPClient client = new SimpleHTTPClient();
            BuySellRequest request = new BuySellRequest(commodity, price, amount, "sell");
            request.amount = amount;
            request.price = price;
            string response = client.SendPostRequest(Url, User, request);
            try
            {
                return Int32.Parse(response);
            }
            catch(Exception e)
            {
                throw new Exception(response);
            }

            */
            SimpleHTTPClient SHC = new SimpleHTTPClient();
            BuySellRequest request = new BuySellRequest(commodity, price, amount, "sell");
            string s = SHC.SendPostRequest(Url, User,PrivateKey, request);
            //string s = decrypt(output, PrivateKey);
            try
            {
                return Int32.Parse(s);
            }
            catch (FormatException e)
            {
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("---" + s + "---");
                Console.ResetColor();
                //return Int32.Parse(output);
                throw new Exception(s);
            }
            
        }
        public AllMarketData[] SendQueryAllMarketRequest()
        {
            SimpleHTTPClient SHC = new SimpleHTTPClient();
            QueryAllMarket request = new QueryAllMarket();
            AllMarketData[] output = SHC.SendPostRequest<QueryAllMarket, AllMarketData[]>(Url, User, PrivateKey, request);
            return output;

        }
        public AllUserRequestsData[] SendQueryAllUserRequests()
        {
            SimpleHTTPClient SHC = new SimpleHTTPClient();
            QueryUserRequests request = new QueryUserRequests();
            AllUserRequestsData[] output = SHC.SendPostRequest<QueryUserRequests, AllUserRequestsData[]>(Url, User, PrivateKey, request);
            return output;

        }

        SimpleHTTPClient client = new SimpleHTTPClient();

        public List<int> getRequestID()
        {
            QueryUserRequest request = new QueryUserRequest();
            request.type = "queryUser";
            UserData req = client.SendPostRequest<QueryUserRequest, UserData>(Url, User, PrivateKey, request);
            List<int> IDreq = req.requests;
            return IDreq;
        }

        public static string decrypt(string message, string privateKey)
        {
            RSACryptoServiceProvider rsaAlgo = new RSACryptoServiceProvider();
            rsaAlgo.ImportParameters(SimpleCtyptoLibrary.ExtractRSAPrivateKey(privateKey));
            Console.WriteLine(message);
            Console.ReadLine();
            byte[] encrypted = Convert.FromBase64String(message);
            StringBuilder decrypted = new StringBuilder();

            for (int i = 0; i < encrypted.Length; i += 128)
            {
                byte[] block = new byte[128];
                Array.Copy(encrypted, i, block, 0, Math.Min(encrypted.Length - i, 128));
                String decblock = Encoding.ASCII.GetString(rsaAlgo.Decrypt(block, false));
                decrypted.Append(decblock);
            }

            return decrypted.ToString();
        }
    }
}
