﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketClient
{
    class QuerySellBuyRequest
    {
        public string type;
        public int id;

        public QuerySellBuyRequest(int id)
        {
            this.id = id;
            type = "queryBuySell";
        }
    }
}
