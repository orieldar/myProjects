﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketClient
{
    public class QueryMarketRequest
    {
        public string type;
        public int commodity;

        public QueryMarketRequest(int commodity)
        {
            this.commodity = commodity;
            type = "queryMarket";
        }
    }
}
