﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MarketClient;
using BL;
using NUnit.Framework;
using System.Security.Cryptography;
using System.Text;
using MarketClient.Utils;


namespace UnitTestProject1

{

    [TestClass]
    public class UnitTest1
    {
        
        /*
        //----Start Of MileStone2 Tests----//

        private Finder finder = new Finder();
        private IBL client = new IBL();

        [TestMethod]
        public void TestBuySuccess()
        {
            //NUnit.Framework.Assert.IsTrue(false);
            //return;
            //NUnit.Framework.Assert.IsTrue(true);
            //return;
            //double funds = finder.getUserFunds();

            int ReqID = 0;
            Boolean error = false;
            try
            {
                //if (funds > 10)
                ///   {
                //  NUnit.Framework.Assert.IsTrue(true);
                //return;
                ReqID = client.SendBuyRequest(10, 1, 2);

                //  }

            }
            catch (Exception)
            {
                error = true;
            }
            NUnit.Framework.Assert.IsTrue(!error);
            if (!error)
            {
                client.SendCancelBuySellRequest(ReqID);
            }

        }

        [TestMethod]
        public void TestbuyFailBadCommodity() //badCommodity
        {
            Boolean error = false;
            try
            {
                int ReqID = client.SendBuyRequest(10, 100, 2);
            }
            catch (Exception)
            {
                error = true;
            }
            NUnit.Framework.Assert.IsTrue(error);
        }

        [TestMethod]
        public void TestbuyFailBadPrice() //badCommodity
        {
            double funds = finder.getUserFunds();
            Boolean error = false;
            try
            {
                int ReqID = client.SendBuyRequest(2 * (int)funds, 1, 10);
            }
            catch (Exception)
            {
                error = true;
            }
            NUnit.Framework.Assert.IsTrue(error);
        }

        [TestMethod]
        public void TestSellSuccess()
        {
            int ReqID = 0;
            Boolean error = false;

            try
            {
                ReqID = client.SendSellRequest(15, 2, 1);
            }
            catch (Exception)
            {
                error = true;
            }
            NUnit.Framework.Assert.IsTrue(!error);
            if (!error)
            {
                client.SendCancelBuySellRequest(ReqID);
            }
        }

        [TestMethod]
        public void TestSellFailBadCommodity()
        {
            int ReqID = 0;
            Boolean error = false;
            try
            {
                ReqID = client.SendSellRequest(15, 110, 1);
            }
            catch (Exception)
            {
                error = true;
            }
            NUnit.Framework.Assert.IsTrue(error);
            if (!error)
            {
                client.SendCancelBuySellRequest(ReqID);
            }
        }

        [TestMethod]
        public void TestCancelSuccess()
        {
            double funds = finder.getUserFunds();
            int ReqID = 0;
            if (funds > 10)
            {
                ReqID = client.SendBuyRequest(10, 1, 2);
            }
            bool result = client.SendCancelBuySellRequest(ReqID);
            NUnit.Framework.Assert.IsTrue(result);
        }

        [TestMethod]
        public void TestCancelFail()
        {
            bool result = client.SendCancelBuySellRequest(-100);
            NUnit.Framework.Assert.IsTrue(!result);
        }

        //----End Of MileStone2 Tests----//


        //----Start Of MileStone3 Tests----//
        private IBL ibl = new IBL();
        private static readonly int MAX_COMMODITIES = 10;
        int rnd;
        Finder find = new Finder();
        MarketClient.Class1 C1 = new Class1();

        //Because we changed the requests to be encrypted, 
        //we would like to check if the encrypted code will 
        //be decrypted well to a legit string that the user can understand

        [TestMethod]
        public void TestBuyDecrypt()
        {
            Boolean wasError = false;
            int ReqID = 0;
            try
            {
                ReqID = C1.SendBuyRequest(find.CommodityAskPrice(7), 7, 1);
            }
            catch (Exception)
            {
                wasError = true;
            }
            NUnit.Framework.Assert.IsTrue(!wasError);
            /*
            Random random = new Random();
            rnd = (int)random.Next(0, MAX_COMMODITIES);
            double funds = find.getUserFunds();
            int price = find.CommodityAskPrice(rnd);
            int ReqID = 0;
            if(funds > price)
            {
                try
                {
                    ReqID = ibl.SendBuyRequest(price, rnd, 1);
                    //will continue only if no Exception
                    NUnit.Framework.Assert.IsTrue(true);
                }
                catch(Exception e)
                {
                    NUnit.Framework.Assert.IsTrue(false);
                }
            }
            
        }
        /*
        [TestMethod]
        public void TestSellDecrypt()
        {

        }

        [TestMethod]
        public void TestCancelDecrypt() 
        {

        }
        
        }*/

        private const string Url = "http://ise172.ise.bgu.ac.il";
        private const string User = "user39";
        private const string PrivateKey =
        @"-----BEGIN RSA PRIVATE KEY-----
        MIICXQIBAAKBgQDFVnV4cmYNmsxUxwmyZaiEQ8UP77yObHTxNlwDFmBAgS60svyr
        v8ogpSDCYtS11zBIUlZMgdiUmNblc1EzrhVvJgd7vAWD8d2hqK71FoifQYWP54gp
        5EAMsLSLKUIZNXDSuTD4xMwsCx/akU+nCMEiiuKBNKJFu0u38xY5V/fI7QIDAQAB
        AoGBAIXTKD7SddrsC33CrRTKVAm+W7l+/wQnEPczwhpl5khYUvBAIZHnso+I7Dpn
        A5F9qUSicdvYgqPjMnjQR1UgzW8tW6FvpVe0Y9d2B/ZfAkjaPdHX9MC8Q2omo3qU
        BSasN5ls7DyUbqdjqvOFsgtx1b/Y+Ym54Ggh8jMK0y1RuvMRAkEA0S7lNSQw/IlQ
        oB+AiBU/IsMBH1hSkqGDBMq/vtjULnmtqGsnXlWQb83KmAhUTbyl1GCMyAcn4wND
        zvbLv/WVgwJBAPGA4XsdGBqE1xIaM4URzQc+WjeMY8QmwsDe1+3tKNFuC8OrqJ18
        4DUID9TvZSPvlHmJAzgtV2LDsK9Xk4krTM8CQHQecCYbvQWyxAre8d6YzL9jOJBJ
        2yyCc9SJJ/+tJbvW18uSD/yRyugFeN0EYqf0fKl0HzI6pq2h9lZBMcGRdjkCQQCU
        pD+j9+9K+zIouSm2oJMx/yWmBOmu5DCAZ2g9z/eMl4/0GiaI8EBLQ7AC3mnA6YfY
        GgV6QSYE6u9HrL5o8davAkAzF9bt78+GsxoR3VPQlh7gtQvlVirNyxArbj7bPCS2
        WfMJyweydEvMfN4DgcoK8an3F7wkuM9KHNcXiWVYbx1G
        -----END RSA PRIVATE KEY-----";

        //Because we now get an encrypted response from the server, we would like to 
        //check if we decrypted it well to the right int / string

        [TestMethod]
        public void testBuy()
        {
            Boolean check = true; 
            Class1 c1 = new Class1();
            int ReqID = 0;
            //check successful buy and the response from the 
            //server was decrypted well to the Request number
            try
            {
                ReqID = c1.SendBuyRequest(10, 0, 1);
            }
            catch(Exception)
            {
                check = false;
            }
            if (check)
            {
                c1.SendCancelBuySellRequest(ReqID);
            }
            //check if the response from the server was 
            //decrypted well to the correct exception
            try
            {
                ReqID = c1.SendBuyRequest(10, 100, 1);
            }
            catch (Exception e)
            {
                if(!e.Message.Equals("Bad commodity"))
                {
                    check = false;
                }
            }
            NUnit.Framework.Assert.IsTrue(check);
        }

        [TestMethod]
        public void testSQL()
        {
            IBL ibl = new IBL();
            double[] prices = ibl.getSQL();
            Boolean check = true;
            for(int i = 0; i < 10; i++)
            {
                if (!(prices[i] >= prices[i + 20]) | !(prices[i + 10] <= prices[i + 20])){
                    check = false;
                }
            }
            NUnit.Framework.Assert.IsTrue(check);
        }

        [TestMethod]
        public void testAverageSQL()
        {
            Boolean check = true;
            IBL ibl = new IBL();
            for(int i = 0; i < 10; i++)
            {
                double[] averages = ibl.getSQLAverages(i);
                for(int j = 0; j < averages.Length; j++)
                {
                    if(averages[j] <= 0)
                    {
                        check = false;
                    }
                }
            }
            NUnit.Framework.Assert.IsTrue(check);
        }

        //tests the function that cancels the top (x) requests
        [TestMethod]
        public void testFinderCancelRequests()
        {
            Boolean check = true;
            Finder find = new Finder();
            IBL ibl = new IBL();
            ibl.SendBuyRequest(3, 1, 2); //adds a request so it wont be empty
            int NumOfReq = find.getUserRequestsAmount();
            find.cancelTopXRequests(NumOfReq); //cancels all request
            NumOfReq = find.getUserRequestsAmount();
            check = (NumOfReq == 0); //checks if it works
            NUnit.Framework.Assert.IsTrue(check);
        }
   
        [TestMethod]
        public void testFinderRequestAmount()
        {
            IBL ibl = new IBL();
            Finder find = new Finder();
            UserData IMD = (UserData)ibl.SendQueryUserRequest();
            Boolean check = false;
            if (find.getUserRequestsAmount() == IMD.requests.Count)
            {
                check = true;
            }
            NUnit.Framework.Assert.IsTrue(check);
        }
    }
}
