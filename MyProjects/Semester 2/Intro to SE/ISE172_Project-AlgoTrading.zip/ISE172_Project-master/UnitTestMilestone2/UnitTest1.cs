﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using BL;
using MarketClient;
using MarketClient.Utils;

namespace UnitTestMilestone2
{
    
    [TestClass]
    public class UnitTest1
    {
        private const string Url = "http://ise172.ise.bgu.ac.il";
        private const string User = "user39";
        private const string PrivateKey =
        "MIICXQIBAAKBgQDFVnV4cmYNmsxUxwmyZaiEQ8UP77yObHTxNlwDFmBAgS60svyrv8ogpSDCYtS11zBIUlZMgdiUmNblc1EzrhVvJgd7vAWD8d2hqK71FoifQYWP54gp5EAMsLSLKUIZNXDSuTD4xMwsCx/akU+nCMEiiuKBNKJFu0u38xY5V/fI7QIDAQABAoGBAIXTKD7SddrsC33CrRTKVAm+W7l+/wQnEPczwhpl5khYUvBAIZHnso+I7DpnA5F9qUSicdvYgqPjMnjQR1UgzW8tW6FvpVe0Y9d2B/ZfAkjaPdHX9MC8Q2omo3qUBSasN5ls7DyUbqdjqvOFsgtx1b/Y+Ym54Ggh8jMK0y1RuvMRAkEA0S7lNSQw/IlQoB+AiBU/IsMBH1hSkqGDBMq/vtjULnmtqGsnXlWQb83KmAhUTbyl1GCMyAcn4wNDzvbLv/WVgwJBAPGA4XsdGBqE1xIaM4URzQc+WjeMY8QmwsDe1+3tKNFuC8OrqJ184DUID9TvZSPvlHmJAzgtV2LDsK9Xk4krTM8CQHQecCYbvQWyxAre8d6YzL9jOJBJ2yyCc9SJJ/+tJbvW18uSD/yRyugFeN0EYqf0fKl0HzI6pq2h9lZBMcGRdjkCQQCUpD+j9+9K+zIouSm2oJMx/yWmBOmu5DCAZ2g9z/eMl4/0GiaI8EBLQ7AC3mnA6YfYGgV6QSYE6u9HrL5o8davAkAzF9bt78+GsxoR3VPQlh7gtQvlVirNyxArbj7bPCS2WfMJyweydEvMfN4DgcoK8an3F7wkuM9KHNcXiWVYbx1G";

        MarketClient.Class2 finder = new Class2();
        private IBL client = new IBL();

        [TestMethod]
        public void TestBuySuccess()
        {
            double funds = finder.getUserFunds();
            int ReqID = 0;
            Boolean error = false;
            try
            {
                if(funds > 10) {
                    ReqID = client.SendBuyRequest(10, 1, 2);
                }
                
            }
            catch (Exception)
            {
                error = true;
            }
            NUnit.Framework.Assert.IsTrue(!error);
            if (!error)
            {
                client.SendCancelBuySellRequest(ReqID);
            }
           
        }

        [TestMethod]
        public void TestbuyFailBadCommodity() //badCommodity
        {
            Boolean error = false;
            try
            {
                int ReqID = client.SendBuyRequest(10, 100, 2);
            }
            catch (Exception)
            {
                error = true;
            }
            NUnit.Framework.Assert.IsTrue(error);
        }

        [TestMethod]
        public void TestbuyFailBadPrice() //badCommodity
        {
            double funds = finder.getUserFunds();
            Boolean error = false;
            try
            {
                int ReqID = client.SendBuyRequest(2 * (int)funds, 1, 10);
            }
            catch (Exception)
            {
                error = true;
            }
            NUnit.Framework.Assert.IsTrue(error);
        }

        [TestMethod]
        public void TestSellSuccess()
        {
            int ReqID = 0;
            Boolean error = false;
            try
            {
                ReqID = client.SendSellRequest(15, 0, 1);
            }
            catch (Exception)
            {
                error = true;
            }
            NUnit.Framework.Assert.IsTrue(!error);
            if (!error)
            {
                client.SendCancelBuySellRequest(ReqID);
            }
        }

        [TestMethod]
        public void TestSellFailBadCommodity()
        {
            int ReqID = 0;
            Boolean error = false;
            try
            {
                ReqID = client.SendSellRequest(15, 110, 1);
            }
            catch (Exception)
            {
                error = true;
            }
            NUnit.Framework.Assert.IsTrue(error);
            if (!error)
            {
                client.SendCancelBuySellRequest(ReqID);
            }
        }

        [TestMethod]
        public void TestCancelSuccess()
        {
            double funds = finder.getUserFunds();
            int ReqID = 0;
            if (funds > 10)
            {
                ReqID = client.SendBuyRequest(10, 1, 2);
            }
            bool result = client.SendCancelBuySellRequest(ReqID);
            NUnit.Framework.Assert.IsTrue(result);
        }

        [TestMethod]
        public void TestCancelFail()
        {
            bool result = client.SendCancelBuySellRequest(-100);
            NUnit.Framework.Assert.IsTrue(!result);
        }

    }
}
