﻿using System;
using System.Windows.Controls;
using System.Windows.Media;
using LiveCharts;
using LiveCharts.Wpf;
using BL;


namespace PLwpf
{
    public partial class Graphs: UserControl
    {
        

        public Graphs()
        {
            InitializeComponent();

            SeriesCollection = new SeriesCollection
            {
               
                
            };
            
            Labels = new[] { "0", "1", "2", "3", "4","5","6","7","8","9","10" };
            YFormatter = value => value.ToString("C");

             IBL ibl = new IBL();
            double[] Com = ibl.getSQL();

            ChartValues<double> maxValues = new ChartValues<double>();
            for (int i = 0; i < 10; i++)
                maxValues.Add(Com[i]);

            ChartValues<double> minValues = new ChartValues<double>();
            for (int i = 10; i < 20; i++)
                minValues.Add(Com[i]);

            ChartValues<double> avgValues = new ChartValues<double>();
            for (int i = 20; i < 30; i++)
                avgValues.Add(Com[i]);



            //modifying the series collection will animate and update the chart
               SeriesCollection.Add(
                   new LineSeries
                   {
                       Title = "MAX ASK PRICE",
                       Values = maxValues,
                   });

               SeriesCollection.Add(
                    new LineSeries
                    {
                        Title = "MIN ASK PRICE",
                        Values = minValues,
                    });

               SeriesCollection.Add(
                     new LineSeries
                     {
                         Title = "AVERAGE ASK PRICE",
                         Values = avgValues,
                     });
           

            //modifying any series values will also animate and update the chart
            // SeriesCollection[3].Values.Add(5d);

            DataContext = this;
        }

        public SeriesCollection SeriesCollection { get; set; }
        public string[] Labels { get; set; }
        public Func<double, string> YFormatter { get; set; }

    }
}