﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PLwpf
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        Boolean first;

        public Window1()
        {
            InitializeComponent();
            first = true;
        }

        private void textChat_TextChanged(object sender, TextChangedEventArgs e)
        {

        }


        public string findMatch(string str, string clientName)
        {

            string[,] KnowledgeBase = new string[23, 2] {
        { "what is your name","My name is Algo Bot"},
        { "how are you", "I am great thanks for asking" },
        { "hi","Hi there! " + clientName,},
        { "hello","Hi there how can I help?",},
        { "yes", "well thats good to know" },
        { "how are you","I'm doing fine " + clientName + "thanks for asking"},
        { "who are you","I'm an a.i program."},
        { "can you help me" , "I hope so, I will try"},
        { "are you intelligent smart","Well, I try to Be."},
        { "are you real","I hope so"},
        { "great","good"},
        { "good","good? feels more like excellent!"},
        { "what is the time ",DateTime.Now.ToString("h:mm: ss tt")},
        { "how old are you age born ", "Thats a good question, I'm not quite sure..."},
        { "where are you from country city ", "some might say a place called the Internet"},
        {"what is the sell option", "You can sell your commodities there" },
        {"what is the buy option", "You can buy commodities there" },
        {"what is the cancel option", "Cancels and refunds any commodities or funds invested in a specific request which is still pending." },
        {"what is the Query option", "You can get various information about the Market there" },
        {"what is the history option", "Shows history and logs for the users tansactions" },
        {"what is the AMA", "Runs an Autonomous Market Agent (AMA), which intelligently decides when to buy/sell stocks. " },
        {"what is the set Rules option", "The user can define basic rules for buying/selling a stock" },
        {"what is the print option", "You can print the current text box" },

        };



            string result = "";
            
            for (int i = 0; i < KnowledgeBase.GetUpperBound(0) + 1; ++i)
            {
               

                if (KnowledgeBase[i, 0].Contains(str))
                {
                    result = KnowledgeBase[i, 1];
                    break;
                }

                if (str.Contains(KnowledgeBase[i, 0]))
                {
                    result = KnowledgeBase[i, 1];
                    break;
                }
        
            }
            return result;
        }


        public string[] GetWords(string input)
        {
            MatchCollection matches = Regex.Matches(input, @"\b[\w']*\b");

            var words = from m in matches.Cast<Match>()
                        where !string.IsNullOrEmpty(m.Value)
                        select TrimSuffix(m.Value);

            return words.ToArray();
        }

        public string TrimSuffix(string word)
        {
            int apostropheLocation = word.IndexOf('\'');
            if (apostropheLocation != -1)
            {
                word = word.Substring(0, apostropheLocation);
            }

            return word;
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            Boolean send = true;


            char[] charsToTrim = { ',', '.', '?', ' ' };
            string clientName = "";


            while (send)
            {

                textChat.Text = (">>");
                string sInput = myText.Text;


                sInput = sInput.ToLower().TrimEnd(charsToTrim);
                string sResponse = findMatch(sInput, clientName);
                if (first)
                {

                    clientName = sInput.TrimEnd(charsToTrim);
                    textChat.Text = textChat.Text + "Hello " + clientName + "!";
                    first = false;
                    send = false;
                }
                else if ((sInput.Equals("bye") || sInput.Equals("bio")))
                {
                    textChat.Text = textChat.Text + ("It was nice talking to you user,see you next time!");
                    this.Close();
                    send = false;
                }
                else if (sResponse.Length == 0)
                {
                    textChat.Text = textChat.Text + ("I'm not sure if i understand what you are talking about, try and be more specific");
                    send = false;
                }
                else
                {
                    textChat.Text = textChat.Text + (sResponse);
                    send = false;
                }

            }


        }
    }
}
