﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using BL;
using System.Timers;
using MarketClient.Utils;
using log4net;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace PLwpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private bool isEnterClicked;
        private bool buyIsClicked;
        private bool sellIsClicked;
        private bool cancelIsClicked;
        private bool querySOBIsClicked;
        private bool queryUserIsClicked;
        private bool queryMarketIsClicked;
        private bool AMAIsClicked;
        private bool setRulesIsClicked;
        private bool rbBuyIsChecked;
        private bool rbSellIsChecked;
        private bool historyIsClicked;
        private bool queryAllMarketIsClicked;
        private bool queryAllUserIsCLicked;
        private int AMAcounter;
        private static readonly int MAX_COMMODITIES = 10;
        private IBL client = new IBL();

        private int comID;
        private int price;
        private int amount;
        private int requestID;


        public MainWindow()
        {

            InitializeComponent();
            ClearScreen();

        }

        private void Sell_Click(object sender, RoutedEventArgs e)
        {
            ClearScreen();
            textBlock1.Visibility = System.Windows.Visibility.Visible;
            textBox1.Visibility = System.Windows.Visibility.Visible;
            textBlock2.Visibility = System.Windows.Visibility.Visible;
            textBox2.Visibility = System.Windows.Visibility.Visible;
            textBlock3.Visibility = System.Windows.Visibility.Visible;
            textBox3.Visibility = System.Windows.Visibility.Visible;
            enter.Visibility = System.Windows.Visibility.Visible;
            commandText.Visibility = System.Windows.Visibility.Visible;
            enter.Visibility = System.Windows.Visibility.Visible;
            sellIsClicked = true;
            commandText.Text = "Sell:";
            textBlock1.Text = "Commodity ID:";
            textBlock2.Text = "Price:";
            textBlock3.Text = "Amount:";

        }

        private void Buy_Click(object sender, RoutedEventArgs e)
        {
            ClearScreen();
            commandText.Visibility = System.Windows.Visibility.Visible;
            textBlock1.Visibility = System.Windows.Visibility.Visible;
            textBox1.Visibility = System.Windows.Visibility.Visible;
            textBlock2.Visibility = System.Windows.Visibility.Visible;
            textBox2.Visibility = System.Windows.Visibility.Visible;
            textBlock3.Visibility = System.Windows.Visibility.Visible;
            textBox3.Visibility = System.Windows.Visibility.Visible;
            enter.Visibility = System.Windows.Visibility.Visible;
            commandText.Visibility = System.Windows.Visibility.Visible;
            enter.Visibility = System.Windows.Visibility.Visible;
            buyIsClicked = true;

            commandText.Text = "Buy:";
            textBlock1.Text = "Commodity ID:";
            textBlock2.Text = "Price:";
            textBlock3.Text = "Amount:";

        }


        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            ClearScreen();
            cancelIsClicked = true;
            commandText.Visibility = System.Windows.Visibility.Visible;
            enter.Visibility = System.Windows.Visibility.Visible;
            commandText.Text = "Cancel:";
            textBlock1.Visibility = System.Windows.Visibility.Visible;
            textBox1.Visibility = System.Windows.Visibility.Visible;
            textBlock1.Text = "Request ID:";
        }


        private void QuerySellBuy_Click(object sender, RoutedEventArgs e)
        {
            ClearScreen();
            querySOBIsClicked = true;
            commandText.Visibility = System.Windows.Visibility.Visible;
            enter.Visibility = System.Windows.Visibility.Visible;
            commandText.Text = "Query Sell or Buy:";
            textBlock1.Visibility = System.Windows.Visibility.Visible;
            textBox1.Visibility = System.Windows.Visibility.Visible;
            textBlock1.Text = "Request ID:";
        }

        private void QueryUser_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ClearScreen();
                queryUserIsClicked = true;
                commandText.Visibility = System.Windows.Visibility.Visible;
                commandText.Text = "Query User:";
                textBox.Text = (client.SendQueryUserRequest().ToString());
            }
            catch (Exception exce) //Exception from the server
            {
                MessageBox.Show("Error: Try Again");
            }
        }

        private void QueryMarket_Click(object sender, RoutedEventArgs e)
        {
            ClearScreen();
            queryMarketIsClicked = true;
            commandText.Visibility = System.Windows.Visibility.Visible;
            enter.Visibility = System.Windows.Visibility.Visible;
            commandText.Text = "Query Market:";
            textBlock1.Visibility = System.Windows.Visibility.Visible;
            textBox1.Visibility = System.Windows.Visibility.Visible;
            textBlock1.Text = "Commodity ID:";
        }
        private void ClearScreen()
        {
            textBlock1.Visibility = System.Windows.Visibility.Hidden;
            textBox1.Visibility = System.Windows.Visibility.Hidden;
            textBlock2.Visibility = System.Windows.Visibility.Hidden;
            textBox2.Visibility = System.Windows.Visibility.Hidden;
            textBlock3.Visibility = System.Windows.Visibility.Hidden;
            textBox3.Visibility = System.Windows.Visibility.Hidden;
            enter.Visibility = System.Windows.Visibility.Hidden;
            commandText.Visibility = System.Windows.Visibility.Hidden;
            radioButtonBuy.Visibility = System.Windows.Visibility.Hidden;
            radioButtonSell.Visibility = System.Windows.Visibility.Hidden;

            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";


            isEnterClicked = false;
            buyIsClicked = false;
            sellIsClicked = false;
            cancelIsClicked = false;
            querySOBIsClicked = false;
            queryUserIsClicked = false;
            queryMarketIsClicked = false;
            AMAIsClicked = false;
            setRulesIsClicked = false;
            rbBuyIsChecked = false;
            rbSellIsChecked = false;
            historyIsClicked = false;
            queryAllMarketIsClicked = false;
            queryAllUserIsCLicked = false;

        }

        private void MainFrame_Navigated(object sender, NavigationEventArgs e)
        {

        }

        private void enter_Click(object sender, RoutedEventArgs e)
        {
            ILog History = LogManager.GetLogger("MyFileAppender");
            ILog myLog = LogManager.GetLogger("MyAppender");
            if (buyIsClicked)
            {
                string error = "";
                Boolean wasError = false;
                try
                {
                    comID = Int32.Parse(textBox1.Text);
                    price = Int32.Parse(textBox2.Text);
                    amount = Int32.Parse(textBox3.Text);
                    myLog.Debug("Send a buy request with commodity: " + comID + ", price: " + price + ", and amount: " + amount + ".");
                }
                catch (FormatException exc)
                {
                    error = exc.Message;
                    wasError = true;
                    MessageBox.Show(exc.Message + "\n Try again");
                }
                catch (OverflowException exc) //Int too big
                {
                    error = exc.Message;
                    wasError = true;
                    MessageBox.Show(exc.Message);
                }
                int ReqID = 0;
                if (!wasError)
                {
                    try
                    {
                        ReqID = client.SendBuyRequest(price, comID, amount);
                        textBox.Text = ("Request ID: " + ReqID);
                    }
                    catch (Exception exce) //Exception from the server
                    {
                        error = exce.Message;
                        wasError = true;
                        //MessageBox.Show("Error: invalid input. Try Again");
                        MessageBox.Show(error + "\nTry Again");
                    }
                }
                if (!wasError)
                {
                    History.Info("Buy Request succeeded for commodity: " + comID + ", price: " + price + ", amount: " + amount + ". Request ID: " + ReqID);
                    myLog.Info("Buy Request succeeded for commodity: " + comID + ", price: " + price + ", amount: " + amount + ". Request ID: " + ReqID);
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    myLog.Error("Buy Request failed. " + error);
                    Console.ResetColor();
                }
            }

            if (sellIsClicked)
            {
                string error = "";
                Boolean wasError = false;
                try
                {
                    comID = Int32.Parse(textBox1.Text);
                    price = Int32.Parse(textBox2.Text);
                    amount = Int32.Parse(textBox3.Text);
                    myLog.Debug("Send a sell request with commodity: " + comID + ", price: " + price + ", and amount: " + amount + ".");
                }
                catch (FormatException exc)
                {
                    error = exc.Message;
                    wasError = true;
                    MessageBox.Show(exc.Message + "\n Try again");
                }
                catch (OverflowException exc) //Int too big
                {
                    error = exc.Message;
                    wasError = true;
                    MessageBox.Show(exc.Message);
                }
                int ReqID = 0;
                if (!wasError)
                {
                    try
                    {
                        ReqID = client.SendSellRequest(price, comID, amount);
                        textBox.Text = ("Request ID: " + ReqID);
                    }
                    catch (Exception exce) //Exception from the server
                    {
                        error = exce.Message;
                        wasError = true;
                        //MessageBox.Show("Error: invalid input. Try Again"); 
                        MessageBox.Show(error + "\nTry Again");
                    }
                }
                if (!wasError)
                {
                    History.Info("Sell Request succeeded for commodity: " + comID + ", price: " + price + ", amount: " + amount + ". Request ID: " + ReqID);
                    myLog.Info("Sell Request succeeded for commodity: " + comID + ", price: " + price + ", amount: " + amount + ". Request ID: " + ReqID);
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    myLog.Error("Sell Request failed. " + error);
                    Console.ResetColor();
                }
            }

            if (cancelIsClicked)
            {
                string error = "";
                Boolean wasError = false;
                try
                {
                    requestID = Int32.Parse(textBox1.Text);
                    myLog.Debug("Send a cancel request with request ID: " + requestID + ".");


                }
                catch (FormatException exc)
                {
                    error = exc.Message;
                    wasError = true;
                    MessageBox.Show(exc.Message + "\n Try again");
                }
                catch (OverflowException exc) //Int too big
                {
                    error = exc.Message;
                    wasError = true;
                    MessageBox.Show(exc.Message);
                }
                if (!wasError)
                {
                    try
                    {
                        bool tmp = client.SendCancelBuySellRequest(requestID);
                        if (tmp)
                        {
                            History.Info("Request NO. " + requestID + " canceled succesfuly");
                            myLog.Info("Request NO. " + requestID + " canceled succesfuly");
                            textBox.Text = "Succesful";
                        }
                        else
                        {
                            wasError = true;
                            textBox.Text = "Unsuccesful";
                        }


                    }
                    catch (Exception exce) //Exception from the server
                    {
                        wasError = true;
                        error = exce.Message;
                        MessageBox.Show("Error: Try Again");
                    }
                }
                if (wasError)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    myLog.Error("Cancelation of Request NO. " + requestID + " was unsuccesful. " + error);
                    Console.ResetColor();
                }
            }

            if (querySOBIsClicked)
            {
                Boolean wasError = false;
                try
                {
                    requestID = Int32.Parse(textBox1.Text);

                }
                catch (FormatException exc)
                {
                    wasError = true;
                    MessageBox.Show(exc.Message + "\n Try again");
                }
                catch (OverflowException exc) //Int too big
                {
                    wasError = true;
                    MessageBox.Show(exc.Message);
                }
                if (!wasError)
                {
                    try
                    {
                        textBox.Text = client.SendQueryBuySellRequest(requestID).ToString();

                    }
                    catch (MarketException exce) //Exception from the server
                    {
                        MessageBox.Show(exce.Message + "Make sure the Id is your's. Try Again");
                    }
                }
            }



            if (queryMarketIsClicked)
            {
                Boolean wasError = false;
                try
                {
                    comID = Int32.Parse(textBox1.Text);

                }
                catch (FormatException exc)
                {
                    wasError = true;
                    MessageBox.Show(exc.Message + "\n Try again");
                }
                catch (OverflowException exc) //Int too big
                {
                    wasError = true;
                    MessageBox.Show(exc.Message);
                }
                if (!wasError)
                {
                    try
                    {
                        textBox.Text = (client.SendQueryMarketRequest(comID).ToString());

                    }
                    catch (MarketException exce) //Exception from the server
                    {
                        MessageBox.Show(exce.Message + "Make sure the Id is your's. Try Again");
                    }
                }
            }

            if (setRulesIsClicked)
            {
                Boolean wasError = false;
                int buyOrSell = 0;
                try
                {
                    comID = Int32.Parse(textBox1.Text);
                    price = Int32.Parse(textBox2.Text);
                    amount = Int32.Parse(textBox3.Text);


                    if (rbBuyIsChecked)
                        buyOrSell = 1;
                    if (rbSellIsChecked)
                        buyOrSell = -1;
                    if (buyOrSell == 0)
                        MessageBox.Show("Please choose to Sell or Buy");
                }
                catch (FormatException exc)
                {
                    wasError = true;
                    MessageBox.Show(exc.Message + "\n Try again");
                }
                catch (OverflowException exc) //Int too big
                {
                    wasError = true;
                    MessageBox.Show(exc.Message);
                }
                if (!wasError)
                {
                    try
                    {
                        Agent.setAgentRules(comID, price, amount, buyOrSell);
                        textBox.Text = "New Agent Rules Set";
                    }
                    catch (Exception exce) //Exception from the server
                    {
                        MessageBox.Show("Error: Try Again");
                    }
                }
            }



        }

        private void AMA_Click(object sender, RoutedEventArgs e)
        {
            IBL client = new IBL(); //for adding sql properties into agent
            double[] historyFromSQL = client.getSQL();
            AMAcounter++;
            if (AMAcounter == 1)
            {
                AMAIsClicked = true;
                Agent.runAgent(historyFromSQL);
                AMA.Foreground = Brushes.LimeGreen;
                textBox.Text = "Autonomous Market Agent Running";
            }
            else if (AMAcounter % 2 == 0)
            {
                AMAIsClicked = false;
                Agent.toggleAgent(false);
                AMA.Foreground = Brushes.DarkRed;
                textBox.Text = "Autonomous Market Agent Stopped";
            }
            else if (AMAcounter % 2 == 1)
            {
                AMAIsClicked = true;
                Agent.toggleAgent(true);
                Agent.updateHistoryTable(historyFromSQL);
                AMA.Foreground = Brushes.LimeGreen;
                textBox.Text = "Autonomous Market Agent Running";
            }
        }

        private void setRules_Click(object sender, RoutedEventArgs e)
        {
            setRulesIsClicked = true;
            textBlock1.Visibility = System.Windows.Visibility.Visible;
            textBox1.Visibility = System.Windows.Visibility.Visible;
            textBlock2.Visibility = System.Windows.Visibility.Visible;
            textBox2.Visibility = System.Windows.Visibility.Visible;
            textBlock3.Visibility = System.Windows.Visibility.Visible;
            textBox3.Visibility = System.Windows.Visibility.Visible;
            enter.Visibility = System.Windows.Visibility.Visible;
            commandText.Visibility = System.Windows.Visibility.Visible;
            enter.Visibility = System.Windows.Visibility.Visible;
            radioButtonBuy.Visibility = System.Windows.Visibility.Visible;
            radioButtonSell.Visibility = System.Windows.Visibility.Visible;
            commandText.Text = "Set AMA Rules";
            textBlock1.Text = "Commodity ID:";
            textBlock2.Text = "Price:";
            textBlock3.Text = "Amount:";

        }

        private void radioButtonSell_Checked(object sender, RoutedEventArgs e)
        {
            rbBuyIsChecked = false;
            rbSellIsChecked = true;

        }

        private void radioButtonBuy_Checked(object sender, RoutedEventArgs e)
        {
            rbSellIsChecked = false;
            rbBuyIsChecked = true;
        }

        private MarketClient.Class1 i = new MarketClient.Class1();

        private void History_Click(object sender, RoutedEventArgs e)
        {
            ClearScreen();
            historyIsClicked = true;
            commandText.Text = "History:";
            commandText.Visibility = System.Windows.Visibility.Visible;
            string fileName = "history.log";
            FileInfo f = new FileInfo(fileName);
            string curr = f.FullName;
            if (File.Exists(curr))
            {
                textBox.Text = File.ReadAllText(curr);
                textBox.ScrollToEnd();
            }
            /*bool b = false;
            textBox.Text = "";
            string[] lines = System.IO.File.ReadAllLines("history.log");
            int[] idA = i.getRequestID().ToArray();
            for (int i = 0; i < lines.Length; i++)
            {

                b = true;
                string[] tokens = lines[i].Split('.');
                if (tokens[1].Equals("cancel"))
                {
                    textBox.Text = textBox.Text + "date: " + tokens[0] + "   " + ", cancel " + ", id: " + tokens[5] + ", status: " + tokens[6] + " date " + tokens[7];
                }
                else
                {
                    bool a = false;
                    for (int j = 0; j < idA.Length; j++)
                    {


                        if (tokens[5].Equals(idA[j].ToString()))
                        {

                            a = true;
                        }
                    }
                    if (a == true)
                    {
                        textBox.Text = textBox.Text + "date: " + tokens[0] + "   ,type: " + tokens[1] + ", price " + tokens[2] + ", amount " + tokens[3] + ", commodity " + tokens[4] + ", id: " + tokens[5] + ", status: " + "  active ";
                    }
                    else
                    {
                        textBox.Text = textBox.Text + "date: " + tokens[0] + "   ,type:" + tokens[1] + ", price " + tokens[2] + ", amount" + tokens[3] + ", commodity" + tokens[4] + ", id:" + tokens[5] + ", status: " + "   NOT active  ";
                    }

                }
            }
            if (!b)
            {
                textBox.Text = "no history yet";
            }*/
        }

        private void queryAllMarket_Click(object sender, RoutedEventArgs e)
        {
            textBox.Text = "";
            queryAllMarketIsClicked = true;
            commandText.Visibility = System.Windows.Visibility.Visible;
            commandText.Text = "Query All Market Requests:";
            for (int i = 0; i < MAX_COMMODITIES; i++)
                textBox.Text += (client.SendQueryAllMarketRequest()[i].ToString()) + " \n" + " \n";
        }

        private void queryAllUser_Click(object sender, RoutedEventArgs e)
        {
            textBox.Text = "";
            queryAllUserIsCLicked = true;
            commandText.Visibility = System.Windows.Visibility.Visible;
            commandText.Text = "Query All User Requests:";
            Object[] allUserRequests = client.SendQueryAllUserRequests();
            for (int i = 0; i < allUserRequests.Length; i++)
                textBox.Text += (allUserRequests[i].ToString()) + "\n" + "\n";
        }

        private void textBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void pdfButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                System.IO.FileStream fs = new FileStream(System.IO.Directory.GetCurrentDirectory() + "\\" + "Printable Version.pdf", FileMode.Create);
                Document document = new Document(PageSize.A4, 25, 25, 30, 30);
                PdfWriter writer = PdfWriter.GetInstance(document, fs);
                // Add meta information to the document
                document.AddAuthor("User39");
                document.AddCreator("Printable PDF document");
                document.AddKeywords("Algo-Trading");
                document.AddSubject("Information from the Algo-Trading software");
                document.AddTitle(commandText.Text);
                // Open the document to enable you to write to the document
                document.Open();
                document.Add(iTextSharp.text.Image.GetInstance(Directory.GetParent(Directory.GetCurrentDirectory()).Parent.FullName + "\\" + "TinyHeading.png"));
                document.Add(new iTextSharp.text.Paragraph(commandText.Text, FontFactory.GetFont("Arial", 18, Font.BOLD)));
                document.Add(new iTextSharp.text.Paragraph(" "));
                document.Add(new iTextSharp.text.Paragraph(textBox.Text, FontFactory.GetFont("Arial", 16)));
                // Close the document
                document.Close();
                // Close the writer instance
                writer.Close();
                // close open filehandles
                fs.Close();

                System.Diagnostics.Process.Start(System.IO.Directory.GetCurrentDirectory() + "\\" + "Printable Version.pdf");
            }
            catch (Exception)
            {

            }
        }

        private void helpButton_Click(object sender, RoutedEventArgs e)
        {
            Window1 chat = new Window1();
            chat.Show();

        }

        private void Graphs_Click(object sender, RoutedEventArgs e)
        {
          graphWindow graphW = new graphWindow();
          graphW.Show();
          Graphs g = new Graphs();
          graphW.Content = g;

        }
    }
}



