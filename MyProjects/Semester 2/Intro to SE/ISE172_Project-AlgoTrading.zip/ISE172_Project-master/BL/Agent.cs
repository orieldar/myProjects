﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using BL;
using MarketClient.Utils;
using log4net;
using MarketClient;
using MarketClient.DataEntries;


namespace BL
{
    public class Agent
    {
        /// <summary>
        /// in this class every element that contains "V2" at the end, is a version of the agent that uses the new buying
        /// agent, using the history of the last X transactions to decide whether or not to buy or sell a certain commodity
        /// </summary>
        private static Finder finder;
        private static System.Timers.Timer aTimer;
        private static readonly int MAX_COMMODITIES = 10;
        private static int[][] userRules = new int[MAX_COMMODITIES][]; //will hold the user rules for each commodities (if they exist)
        private static double[] historySQLTable;
        private static int counter;
        public static void runAgent() //older agent
        {
            finder = new Finder();
            AutonomousMarketAgent();
        }
        public static void runAgent(double[] _historySQLTable) //new agent, using SQL history table for deciding when to buy and sell
        {
            historySQLTable = _historySQLTable;
            finder = new Finder();
            AutonomousMarketAgentV2();
            counter = 0; //will count how many rounds the agent ran. when enough runs were made, update the history SQL table
        }
        public static void updateHistoryTable(double[]_historySQLTable) //update history table. will happen whenever the user disables and enables the agent again or after every 60 agent runs
        {
            historySQLTable = _historySQLTable;
            counter = 0;
        }
        private static void AutonomousMarketAgent()
        {
            aTimer = new System.Timers.Timer(10000);
            aTimer.Elapsed += actualAgent;
            aTimer.AutoReset = true;
            aTimer.Enabled = true;
        }
        private static void AutonomousMarketAgentV2()
        {
            aTimer = new System.Timers.Timer(10000);
            aTimer.Elapsed += actualAgentV2;
            aTimer.AutoReset = true;
            aTimer.Enabled = true;
        }

        public static void setAgentRules(int commodity, int price, int amount, int buyOrSell) //set uesr predefined rules
        {
            if (commodity >= MAX_COMMODITIES | commodity < 0)
                throw new FormatException();
            if (price < 0)
                throw new FormatException();
            if (amount < 0)
                throw new FormatException();
            if (buyOrSell != 1 && buyOrSell != -1)
                throw new FormatException();
            userRules[commodity] = new int[3];
            userRules[commodity][0] = price;
            userRules[commodity][1] = amount;
            userRules[commodity][2] = buyOrSell;
        }
        private static void actualAgentV2(Object source, ElapsedEventArgs e)
        {
            IBL client = new IBL();
            counter++; //add another 1 to the amount of runs the agent has made
            if (counter > 60) //after every X runs, update the SQL table (if one run is 10 second, after every 10 minutes)
            {
                updateHistoryTable(client.getSQL());
                counter = 0; //reset counter
            }
            //loggers
            ILog History = LogManager.GetLogger("MyFileAppender");
            ILog myLog = LogManager.GetLogger("MyAppender");
            Object[] allMarketRequest = client.SendQueryAllMarketRequest(); //to have fewer requests to the server, we will hold here the values for the entire market
            int rnd = (new Random()).Next(0, MAX_COMMODITIES); //rerolls a random commodity id between 0 and MAX_COMMODITIES
            int ask = ((AllMarketData[])allMarketRequest)[rnd].info.ask; //current ask price
            int bid = ((AllMarketData[])allMarketRequest)[rnd].info.bid; //current bid price
            double askPrice = historySQLTable[rnd + 20]+1;
            double bidPrice = historySQLTable[rnd + 20];
            int buyAmount = 2;
            Boolean UserRun = false;
            if (userRules[rnd] != null) //this sets the rules for the user run.
            {
                if (userRules[rnd][2] == 1) //->buy
                    askPrice = userRules[rnd][0];
                else //userRules[rnd][2]==-1 ->sell
                    bidPrice = userRules[rnd][0];
                buyAmount = userRules[rnd][1];
                UserRun = true;
            }
            int userRequestsAmount = finder.getUserRequestsAmount();
        Command: //this is where the agent's actual process happens. the agent will return to "Command" if he just finished a user's rules run and still hasnt finished his own
            int ReqId = 0; //for logging purposes. will hold the request ID that returns from the server and add it to the log
            Boolean wasError = false; //if error add to log
            string error = "";
            if ( userRequestsAmount <= 20) //makes sure we dont have too many pending requests
            {
                try
                {
                    if (ask < askPrice & finder.getUserCommodity(rnd) < 15) //if we have under 15 of that commodity
                    {
                        if (finder.getUserFunds() > 1000 & (ask <= 5 | ask < bid)) //if the rules match buy 3 of that commodity
                        {
                            ReqId = client.SendBuyRequest(ask, rnd, buyAmount);
                            Console.WriteLine("Request ID: " + ReqId);
                            Console.WriteLine("bought " + 3 + " of " + rnd + " for " + ask);
                            if (UserRun)
                            {
                                myLog.Info("User's AMA: Request ID: " + ReqId + " bought " + 3 + " of " + rnd + " for " + bid);
                                History.Info("User's AMA: Request ID: " + ReqId + " bought " + 3 + " of " + rnd + " for " + bid);
                            }
                            else
                            {
                                myLog.Info("AMA: Request ID: " + ReqId + " bought " + 3 + " of " + rnd + " for " + bid);
                                History.Info("AMA: Request ID: " + ReqId + " bought " + 3 + " of " + rnd + " for " + bid);
                            }
                        }
                        else if (finder.getUserFunds() > 1000) //if less rules are matched buy buyAmount of that commodity
                        {
                            ReqId = client.SendBuyRequest(ask, rnd, buyAmount);
                            Console.WriteLine("Request ID: " + ReqId);
                            Console.WriteLine("bought " + buyAmount + " of " + rnd + " for " + ask);
                            if (UserRun)
                            {
                                myLog.Info("User's AMA: Request ID: " + ReqId + " bought " + buyAmount + " of " + rnd + " for " + bid);
                                History.Info("User's AMA: Request ID: " + ReqId + " bought " + buyAmount + " of " + rnd + " for " + bid);
                            }
                            else
                            {
                                myLog.Info("AMA: Request ID: " + ReqId + " bought " + buyAmount + " of " + rnd + " for " + bid);
                                History.Info("AMA: Request ID: " + ReqId + " bought " + buyAmount + " of " + rnd + " for " + bid);
                            }
                        }
                        else //not enough funds
                        {
                            wasError = true;
                            error = "ask is " + ask + ", but user has " + finder.getUserFunds() + " funds.";
                            Console.WriteLine("ask is " + ask + ", but user has " + finder.getUserFunds() + " funds.");
                            Console.WriteLine("Request ID: " + client.SendBuyRequest(ask, rnd, buyAmount));
                            Console.WriteLine("Bought " + buyAmount + " of " + rnd + " for " + ask);

                        }
                    }
                    else if (bid >= bidPrice) //if we want to sell
                    {

                        if (finder.getUserCommodity(rnd) > 2 & (bid >= ask | bid > 17)) //if rules match sell all but 2 of that commodity
                        {
                            int sold = finder.getUserCommodity(rnd) - 2;
                            ReqId = client.SendSellRequest(bid, rnd, sold);
                            Console.WriteLine("Request ID: " + ReqId);
                            Console.WriteLine("sold " + sold + " of " + rnd + " for " + bid);
                            if (UserRun)
                            {
                                myLog.Info("User's AMA: Request ID: " + ReqId + " sold " + sold + " of " + rnd + " for " + bid);
                                History.Info("User's AMA: Request ID: " + ReqId + " sold " + sold + " of " + rnd + " for " + bid);
                            }
                            else
                            {
                                myLog.Info("AMA: Request ID: " + ReqId + " sold " + sold + " of " + rnd + " for " + bid);
                                History.Info("AMA: Request ID: " + ReqId + " sold " + sold + " of " + rnd + " for " + bid);
                            }
                        }
                        else if (finder.getUserCommodity(rnd) > 1) //if less rules are matched, sell buyAmount of that commodity
                        {
                            ReqId = client.SendSellRequest(bid, rnd, buyAmount);
                            Console.WriteLine("Request ID: " + ReqId);
                            Console.WriteLine("sold " + buyAmount + " of " + rnd + " for " + bid);
                            if (UserRun)
                            {
                                myLog.Info("User's AMA: Request ID: " + ReqId + " sold " + buyAmount + " of " + rnd + " for " + bid);
                                History.Info("User's AMA: Request ID: " + ReqId + " sold " + buyAmount + " of " + rnd + " for " + bid);
                            }
                            else
                            {
                                myLog.Info("AMA: Request ID: " + ReqId + " sold " + buyAmount + " of " + rnd + " for " + bid);
                                History.Info("AMA: Request ID: " + ReqId + " sold " + buyAmount + " of " + rnd + " for " + bid);
                            }
                        }
                        else //not enough commodities
                        {
                            wasError = true;
                            error = "bid is " + bid + ", but not enough commodities to sell: " + finder.getUserCommodity(rnd);
                            Console.WriteLine("bid is " + bid + ", but not enough commodities to sell: " + finder.getUserCommodity(rnd));
                            Console.WriteLine("Request ID: " + client.SendSellRequest(bid, rnd, buyAmount));
                            Console.WriteLine("Sold " + buyAmount + " of " + rnd + " for " + bid);
                        }
                    }
                    else //do nothing
                    {
                        wasError = true;
                        error = "nothing happened, for commodity " + rnd + ", the bid is " + bid + ", ask is " + ask;
                        Console.WriteLine("Nothing happened, for commodity " + rnd + ", the bid is " + bid + ", ask is " + ask);
                    }
                    if (wasError) //add error to log
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        myLog.Error("AMA: " + error);
                        Console.ResetColor();
                    }
                    if (UserRun) //goto Command again, without the user rules (with the agent's predefined rules)
                    {
                        UserRun = false;
                        askPrice = historySQLTable[rnd + 20]+1;
                        bidPrice = historySQLTable[rnd + 20];
                        goto Command;
                    }
                }
                catch (Exception)
                {
                    //void
                }
            }
            
            else //if more than 20 requests are currently running, cancel the 3 oldest requests 
            {
                string tmp = "";
                error = "";
                wasError = false;
                try
                {
                    tmp = finder.cancelTopXRequests(3); // will hold the canceled requests string
                    if (tmp != "")
                    {
                        History.Info("AMA: Request NO. " + tmp + " canceled succesfuly");
                        myLog.Info("AMA: Request NO. " + tmp + " canceled succesfuly");
                    }
                    else
                    {
                        wasError = true;
                    }
                }
                catch (Exception exce) //Exception from the server
                {
                    wasError = true;
                }
                if (wasError)
                {
                    myLog.Error("AMA: Cancelation of last 3 requests was unsuccesful. " + error);
                }       
            }
            
        }
        //DISCONTINUED:--------------------------------------------------------------------------------
        //DISCONTINUED:--------------------------------------------------------------------------------
        //DISCONTINUED:--------------------------------------------------------------------------------
        private static void actualAgent(Object source, ElapsedEventArgs e) //DISCONTINUED. no longer in use.
        {
            ILog History = LogManager.GetLogger("MyFileAppender");
            ILog myLog = LogManager.GetLogger("MyAppender");
            IBL client = new IBL();
            Object[] allMarketRequest = client.SendQueryAllMarketRequest();
            int rnd = (new Random()).Next(0, MAX_COMMODITIES);
            int ask = ((AllMarketData[])allMarketRequest)[rnd].info.ask;
            int bid = ((AllMarketData[])allMarketRequest)[rnd].info.bid;
            int askPrice = 10;
            int bidPrice = 11;
            int buyAmount = 2;
            Boolean UserRun = false;
            if (userRules[rnd] != null)
            {
                if (userRules[rnd][2] == 1) //->buy
                    askPrice = userRules[rnd][0];
                else //userRules[rnd][2]==-1 ->sell
                    bidPrice = userRules[rnd][0];
                buyAmount = userRules[rnd][1];
                UserRun = true;
            }
        Command:
            int ReqId = 0;
            Boolean wasError = false;
            string error = "";
            if (allMarketRequest.Length <= 40)
            {
                int NoOfCom = finder.getUserCommodity(rnd);
                double NoOfFunds = finder.getUserFunds();
                try
                {
                    if (ask < askPrice & NoOfCom < 15)
                    {
                        if (NoOfFunds > 100 & (ask <= 5 | ask < bid))
                        {
                            ReqId = client.SendBuyRequest(ask, rnd, buyAmount);
                            Console.WriteLine("Request ID: " + ReqId);
                            Console.WriteLine("bought " + 3 + " of " + rnd + " for " + ask);
                            if (UserRun)
                            {
                                myLog.Info("User's AMA: Request ID: " + ReqId + " bought " + 3 + " of " + rnd + " for " + bid);
                                History.Info("User's AMA: Request ID: " + ReqId + " bought " + 3 + " of " + rnd + " for " + bid);
                            }
                            else
                            {
                                myLog.Info("AMA: Request ID: " + ReqId + " bought " + 3 + " of " + rnd + " for " + bid);
                                History.Info("AMA: Request ID: " + ReqId + " bought " + 3 + " of " + rnd + " for " + bid);
                            }
                        }
                        if (NoOfFunds > 100 & NoOfCom < 20)
                        {
                            ReqId = client.SendBuyRequest(ask, rnd, buyAmount);
                            Console.WriteLine("Request ID: " + ReqId);
                            Console.WriteLine("bought " + buyAmount + " of " + rnd + " for " + ask);
                            if (UserRun)
                            {
                                myLog.Info("User's AMA: Request ID: " + ReqId + " bought " + buyAmount + " of " + rnd + " for " + bid);
                                History.Info("User's AMA: Request ID: " + ReqId + " bought " + buyAmount + " of " + rnd + " for " + bid);
                            }
                            else
                            {
                                myLog.Info("AMA: Request ID: " + ReqId + " bought " + buyAmount + " of " + rnd + " for " + bid);
                                History.Info("AMA: Request ID: " + ReqId + " bought " + buyAmount + " of " + rnd + " for " + bid);
                            }
                        }
                        else
                        {
                            wasError = true;
                            error = "ask is " + ask + ", but user has " + finder.getUserFunds() + " funds.";
                            Console.WriteLine("ask is " + ask + ", but user has " + finder.getUserFunds() + " funds.");
                            Console.WriteLine("Request ID: " + client.SendBuyRequest(ask, rnd, buyAmount));
                            Console.WriteLine("Bought " + buyAmount + " of " + rnd + " for " + ask);

                        }
                    }
                    if (bid >= bidPrice)
                    {

                        if (NoOfCom > 2 & (bid >= ask | bid > 17))
                        {
                            int sold = finder.getUserCommodity(rnd) - 2;
                            ReqId = client.SendSellRequest(bid, rnd, sold);
                            Console.WriteLine("Request ID: " + ReqId);
                            Console.WriteLine("sold " + sold + " of " + rnd + " for " + bid);
                            if (UserRun)
                            {
                                myLog.Info("User's AMA: Request ID: " + ReqId + " sold " + sold + " of " + rnd + " for " + bid);
                                History.Info("User's AMA: Request ID: " + ReqId + " sold " + sold + " of " + rnd + " for " + bid);
                            }
                            else
                            {
                                myLog.Info("AMA: Request ID: " + ReqId + " sold " + sold + " of " + rnd + " for " + bid);
                                History.Info("AMA: Request ID: " + ReqId + " sold " + sold + " of " + rnd + " for " + bid);
                            }
                        }
                        else if (NoOfCom > 1)
                        {
                            ReqId = client.SendSellRequest(bid, rnd, buyAmount);
                            Console.WriteLine("Request ID: " + ReqId);
                            Console.WriteLine("sold " + buyAmount + " of " + rnd + " for " + bid);
                            if (UserRun)
                            {
                                myLog.Info("User's AMA: Request ID: " + ReqId + " sold " + buyAmount + " of " + rnd + " for " + bid);
                                History.Info("User's AMA: Request ID: " + ReqId + " sold " + buyAmount + " of " + rnd + " for " + bid);
                            }
                            else
                            {
                                myLog.Info("AMA: Request ID: " + ReqId + " sold " + buyAmount + " of " + rnd + " for " + bid);
                                History.Info("AMA: Request ID: " + ReqId + " sold " + buyAmount + " of " + rnd + " for " + bid);
                            }
                        }
                        else
                        {
                            wasError = true;
                            error = "bid is " + bid + ", but not enough commodities to sell: " + finder.getUserCommodity(rnd);
                            Console.WriteLine("bid is " + bid + ", but not enough commodities to sell: " + finder.getUserCommodity(rnd));
                            Console.WriteLine("Request ID: " + client.SendSellRequest(bid, rnd, buyAmount));
                            Console.WriteLine("Sold " + buyAmount + " of " + rnd + " for " + bid);
                        }
                    }
                    else
                    {
                        myLog.Debug("nothing happened, for commodity " + rnd + ", the bid is " + bid + ", ask is " + ask);
                        Console.WriteLine("Nothing happened, for commodity " + rnd + ", the bid is " + bid + ", ask is " + ask);
                    }
                    if (wasError)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        myLog.Error("AMA: " + error);
                        Console.ResetColor();
                    }
                    if (UserRun)
                    {
                        UserRun = false;
                        askPrice = 10;
                        bidPrice = 12;
                        goto Command;
                    }
                }
                catch (Exception)
                {
                    goto Command;
                }
            }
        }

        public static void toggleAgent(Boolean toggle) //to turn off the agent
        {
            aTimer.Enabled = toggle;
        }

    }
}
