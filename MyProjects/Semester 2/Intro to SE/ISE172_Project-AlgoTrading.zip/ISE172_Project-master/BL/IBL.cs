﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MarketClient.DataEntries;
using MarketClient.Utils;
using MarketClient;
using System.Data.SqlClient;
using System.IO;

namespace BL
{
    public class IBL : IMarketClient
    {
        private const string Url = "http://ise172.ise.bgu.ac.il";
        private const string User = "user39";
        private const string PrivateKey = @"-----BEGIN RSA PRIVATE KEY-----
        MIICXQIBAAKBgQDFVnV4cmYNmsxUxwmyZaiEQ8UP77yObHTxNlwDFmBAgS60svyr
        v8ogpSDCYtS11zBIUlZMgdiUmNblc1EzrhVvJgd7vAWD8d2hqK71FoifQYWP54gp
        5EAMsLSLKUIZNXDSuTD4xMwsCx/akU+nCMEiiuKBNKJFu0u38xY5V/fI7QIDAQAB
        AoGBAIXTKD7SddrsC33CrRTKVAm+W7l+/wQnEPczwhpl5khYUvBAIZHnso+I7Dpn
        A5F9qUSicdvYgqPjMnjQR1UgzW8tW6FvpVe0Y9d2B/ZfAkjaPdHX9MC8Q2omo3qU
        BSasN5ls7DyUbqdjqvOFsgtx1b/Y+Ym54Ggh8jMK0y1RuvMRAkEA0S7lNSQw/IlQ
        oB+AiBU/IsMBH1hSkqGDBMq/vtjULnmtqGsnXlWQb83KmAhUTbyl1GCMyAcn4wND
        zvbLv/WVgwJBAPGA4XsdGBqE1xIaM4URzQc+WjeMY8QmwsDe1+3tKNFuC8OrqJ18
        4DUID9TvZSPvlHmJAzgtV2LDsK9Xk4krTM8CQHQecCYbvQWyxAre8d6YzL9jOJBJ
        2yyCc9SJJ/+tJbvW18uSD/yRyugFeN0EYqf0fKl0HzI6pq2h9lZBMcGRdjkCQQCU
        pD+j9+9K+zIouSm2oJMx/yWmBOmu5DCAZ2g9z/eMl4/0GiaI8EBLQ7AC3mnA6YfY
        GgV6QSYE6u9HrL5o8davAkAzF9bt78+GsxoR3VPQlh7gtQvlVirNyxArbj7bPCS2
        WfMJyweydEvMfN4DgcoK8an3F7wkuM9KHNcXiWVYbx1G
        -----END RSA PRIVATE KEY-----";
        private static readonly int MAX_COMMODITIES = 10;
        public static readonly int ITEMS_TO_CHECK = 100; //sql table looks at 100 items

        //private string token = SimpleCtyptoLibrary.CreateToken(User, PrivateKey);

        public int SendBuyRequest(int price, int commodity, int amount)
        {
            MarketClient.Class1 output = new Class1();
            return output.SendBuyRequest(price, commodity, amount);
        }

        public bool SendCancelBuySellRequest(int id)
        {
            MarketClient.Class1 output = new Class1();
            return output.SendCancelBuySellRequest(id);
        }

        public IMarketItemQuery SendQueryBuySellRequest(int id)
        {
            MarketClient.Class1 output = new Class1();
            return output.SendQueryBuySellRequest(id);
        }

        public IMarketCommodityOffer SendQueryMarketRequest(int commodity)
        {
            MarketClient.Class1 output = new Class1();
            return output.SendQueryMarketRequest(commodity);
        }

        public IMarketUserData SendQueryUserRequest()
        {
            MarketClient.Class1 output = new Class1();
            return output.SendQueryUserRequest();
        }

        public int SendSellRequest(int price, int commodity, int amount)
        {
            MarketClient.Class1 output = new Class1();
            return output.SendSellRequest(price, commodity, amount);
        }
        public AllMarketData[] SendQueryAllMarketRequest()
        {
            MarketClient.Class1 output = new Class1();
            return output.SendQueryAllMarketRequest();
        }
        public AllUserRequestsData[] SendQueryAllUserRequests()
        {
            MarketClient.Class1 output = new Class1();
            return output.SendQueryAllUserRequests();
        }
        /// <summary>
        /// getSQL will return an array of doubles with the following information:
        /// first 10 (index 0-9) cells hold the max price according to last ITEMS_TO_CHECK transactions for each commodity
        /// next 10 (index 10-19) cells hold the min price according to last ITEMS_TO_CHECK transactions for each commodity
        /// last 10 (index 20-29) cells hold the average price according to the last ITEMS_TO_CHECK transactions for each commodity
        /// </summary>
        public double[] getSQL() //create local SQL table with pre-defined variables
        {
            double[] output = new double[30];
            for(int i = 0; i < 30; i++)
            {
                
                output[i] = -1; //temp value for comparison
            }
            FileStream fileStream = File.Open("Answers.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamWriter writer = new StreamWriter(fileStream);
            string connectionString = @"Data Source=ise172.ise.bgu.ac.il;Initial Catalog=history;User ID=labuser;Password=wonsawheightfly";
            SqlConnection myConnection = new SqlConnection(connectionString);
            try
            {
                myConnection.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            /*DateTime localDate = DateTime.Now;
            Console.WriteLine(localDate.ToString("dd-MMM-yy ")); FOR TESTING PURPOSES */
            for (int i = 0; i < MAX_COMMODITIES; i++)
            {
                String command = "SELECT TOP "+ITEMS_TO_CHECK+" [Price] FROM [items] WHERE Commodity="+i+" ORDER BY Timestamp DESC"; //select first ITEMS_TO_CHECK items in descending order from [items]
                SqlCommand myCommand = new SqlCommand(command, myConnection);
                SqlDataReader reader = myCommand.ExecuteReader();
                reader.Read();
                double average=0; //will hold average price for this commodity
                for (int j = 0; j < ITEMS_TO_CHECK; j++) //runs across the ITEMS_TO_CHECK items in this commodity's sql values
                {
                    double curItemPrice=Double.Parse(reader["Price"].ToString());
                    average = average + curItemPrice;
                    //update min and max values if needed:
                    if (output[i+10]==-1|curItemPrice < output[i + 10])
                        output[i + 10] = curItemPrice;
                    if (curItemPrice > output[i])
                        output[i] = curItemPrice;
                    reader.Read();
                }
                average = average / ITEMS_TO_CHECK;
                output[i + 20] = average;
                reader.Close();
                
            }
            writer.Flush();
            writer.Close();
            return output;
        }
        /// <summary>
        /// this function gets a commodity ID, and returns an array of doubles with the size 10
        /// each cell in the array (0 is the first cell), contains the average number for the last 10 transactions
        /// (cell 1 contains the average for the 10 transactions after that)
        /// overall, this function returns information about the last 100 averages
        /// </summary>
        /// <param name="commodity"> which commodity you want to find the averages for</param>
        /// <returns></returns>
        public double[] getSQLAverages(int commodity)
        {
            double[] output = new double[10];
            for (int i = 0; i < 10; i++)
            {

                output[i] = -1; //temp value for comparison
            }
            FileStream fileStream = File.Open("Answers.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);
            StreamWriter writer = new StreamWriter(fileStream);
            string connectionString = @"Data Source=ise172.ise.bgu.ac.il;Initial Catalog=history;User ID=labuser;Password=wonsawheightfly";
            SqlConnection myConnection = new SqlConnection(connectionString);
            try
            {
                myConnection.Open();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
            String command = "SELECT TOP " + ITEMS_TO_CHECK + " [Price] FROM [items] WHERE Commodity=" + commodity + " ORDER BY Timestamp DESC"; //select first ITEMS_TO_CHECK items in descending order from [items]
            SqlCommand myCommand = new SqlCommand(command, myConnection);
            SqlDataReader reader = myCommand.ExecuteReader();
            reader.Read();
            double average = 0; //will hold average price for every 10 transactions
            for (int i = 0; i < ITEMS_TO_CHECK; i++) //runs across the ITEMS_TO_CHECK items in this commodity's sql values
            {
                double curItemPrice = Double.Parse(reader["Price"].ToString());
                average = average + curItemPrice;
                reader.Read();
                if (i != 0 & i % 10 == 0) //finished another 100 items
                {
                    average = average / 10;
                    output[i / 10-1] = average;
                }
            }
            average = average / 10; //adds the last average to the array
            output[9] = average;
            reader.Close();
            writer.Flush();
            writer.Close();
            return output;
        }

    }
}
