﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MarketClient.DataEntries;
using MarketClient.Utils;
using MarketClient;

namespace BL
{
    public class Finder
    {
        public int CommodityBidPrice(int commodity)
        {
            MarketClient.Class2 finder = new Class2();
            return finder.CommodityBidPrice(commodity);
        }
        public int CommodityAskPrice(int commodity)
        {
            MarketClient.Class2 finder = new Class2();
            return finder.CommodityAskPrice(commodity);
        }
        public int getUserCommodity(int commodity)
        {
            MarketClient.Class2 finder = new Class2();
            return finder.getUserCommodity(commodity);
        }
        public double getUserFunds()
        {
            MarketClient.Class2 finder = new Class2();
            return finder.getUserFunds();
        }

        public string cancelTopXRequests(int x) //returns a string of all the requests deleted
        {
            MarketClient.Class2 finder = new Class2();
            return finder.cancelTopXRequests(x);
        }
        public int getUserRequestsAmount()
        {
            MarketClient.Class2 finder = new Class2();
            return finder.getAmountOfRequests();
        }
    }
}
