﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using BL;
using MarketClient.Utils;
using log4net;
using System.IO;


namespace PL
{
    class Program
    {
        ILog myLog = LogManager.GetLogger("MyFileAppender");
        private static readonly int MAX_COMMODITIES = 10;
        public static void MainMenu()
        {
            PrintMenu();
        MainMenu:
            IBL client = new IBL();
            Agent.runAgent();
            string s = Console.ReadLine();
            while (s != "0")
            {
                switch (s) //select option
                {
                    case "0": //exit
                        break;

                    case "1": //buy
                        int comID;
                        int price;
                        int amount;
                        try
                        {
                            Console.WriteLine("Enter commodity ID and then 'Enter'");
                            comID = Int32.Parse(Console.ReadLine());
                            Console.WriteLine("Enter price and then 'Enter'");
                            price = Int32.Parse(Console.ReadLine());
                            Console.WriteLine("Enter amount and then 'Enter'");
                            amount = Int32.Parse(Console.ReadLine());
                        }
                        catch (FormatException e) //wrong input
                        {
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("---invalid input---");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Invalid input. returning to main menu (Enter new command)");
                            Console.ResetColor();
                            goto MainMenu;
                        }
                        catch (OverflowException o) //for int too big
                        {
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("---Invalid input---");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Invalid input. Returning to main menu (Enter new command)");
                            Console.ResetColor();
                            goto MainMenu;
                        }
                        try
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("Request ID: " + client.SendBuyRequest(price, comID, amount));
                            Console.ResetColor();
                        }
                        catch (FormatException e) //for exceptions from the server

                        {
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Returning to main menu (Enter new command)");
                            Console.ResetColor();
                            goto MainMenu;
                        }
                        break;


                    case "2": //sell
                        try
                        {
                            Console.WriteLine("Enter commodity ID and then 'Enter'");
                            comID = Int32.Parse(Console.ReadLine());
                            Console.WriteLine("Enter price and then 'Enter'");
                            price = Int32.Parse(Console.ReadLine());
                            Console.WriteLine("Enter amount and then 'Enter'");
                            amount = Int32.Parse(Console.ReadLine());
                        }
                        catch (FormatException e) //wrong input
                        {
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("---invalid input---");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Invalid input. returning to main menu (Enter new command)");
                            Console.ResetColor();
                            goto MainMenu;
                        }
                        catch (OverflowException) //Int too big
                        {
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("---Invalid input---");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Invalid input. Returning to main menu (Enter new command)");
                            Console.ResetColor();
                            goto MainMenu;
                        }
                        
                        try
                            {

                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("Request ID: " + client.SendSellRequest(price, comID, amount));
                                Console.ResetColor();
                            }
                            catch (FormatException e) //Exception from the server
                        {
                                Console.WriteLine();
                                Console.ForegroundColor = ConsoleColor.DarkCyan;
                                Console.WriteLine("Returning to main menu (Enter new command)");
                                Console.ResetColor();
                                goto MainMenu;
                            }
                            break;
                        try
                        {

                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("Request ID: " + client.SendSellRequest(price, comID, amount));
                            Console.ResetColor();
                        }
                        catch (FormatException e) //exceptions from the server
                        {
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("returning to main menu (Enter new command)");
                            Console.ResetColor();
                            goto MainMenu;
                        }
                        break;


                    case "3": //cancel
                        Console.WriteLine("Enter ID and then 'Enter'");
                        int cancelID = -1;
                        try
                        {
                            cancelID = Int32.Parse(Console.ReadLine());
                        }
                        catch (FormatException e) //wrong input
                        {
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("---invalid input---");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Invalid input. returning to main menu (Enter new command)");
                            Console.ResetColor();
                            goto MainMenu;
                        }
                        catch (OverflowException o) //int too big
                        {
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("---Invalid input---");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Invalid input. Returning to main menu (Enter new command)");
                            Console.ResetColor();
                            goto MainMenu;
                        }
                        bool tmp = client.SendCancelBuySellRequest(cancelID);
                        if (tmp) //if unsuccessful the operation will print the necessary message
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("Successful.");
                            Console.ResetColor();
                        }
                        break;


                    case "4": //query sell/buy
                        Console.WriteLine("Enter Request ID and then 'Enter'");
                        int QueryBuySellID = -1;
                        try
                        {
                            QueryBuySellID = Int32.Parse(Console.ReadLine());
                        }
                        catch (FormatException e) //wrong input
                        {
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("---invalid input---");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Invalid input. returning to main menu (Enter new command)");
                            Console.ResetColor();
                            goto MainMenu;
                        }
                        catch (OverflowException o) //int too big
                        {
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("---Invalid input---");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Invalid input. Returning to main menu (Enter new command)");
                            Console.ResetColor();
                            goto MainMenu;
                        }
                        try
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine(client.SendQueryBuySellRequest(QueryBuySellID).ToString());
                            Console.ResetColor();
                        }
                        catch (MarketException e) //exception from the server
                        
                        {
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("---ID Not Found---");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Please make sure the ID is yours. Returning to main menu (Enter new command)");
                            Console.ResetColor();
                            goto MainMenu;
                        }
                        break;


                    case "5": //query user
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine(client.SendQueryUserRequest().ToString());
                        Console.ResetColor();
                        break;


                    case "6": //query market
                        Console.WriteLine("Enter Commodity ID and then 'Enter'");
                        int QueryMarketID = -1;
                        try
                        {
                            QueryMarketID = Int32.Parse(Console.ReadLine());
                        }
                        catch (FormatException e) //wrong input
                        {
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Invalid input");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Returning to main menu (Enter new command)");
                            Console.ResetColor();
                            goto MainMenu;
                        }
                        catch (OverflowException) //Int too big
                        {
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("---Invalid input---");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Invalid input. Returning to main menu (Enter new command)");
                            Console.ResetColor();
                            goto MainMenu;
                        }
                        try
                        {
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine(client.SendQueryMarketRequest(QueryMarketID).ToString());
                            Console.ResetColor();
                        }
                        
                        catch (MarketException e) //exception from the server 
                        
                        {
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("---ID Not Found---");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Please make sure the ID is yours. Returning to main menu (Enter new command)");
                            Console.ResetColor();
                            goto MainMenu;
                        }
                        break;


                    case "7": //print Menu
                        PrintMenu();
                        break;

                    case "8": //clear console and print Menu
                        Console.Clear();
                        PrintMenu();
                        break;

                    case "9": //define agent
                        int agentID;
                        int agentPrice;
                        int agentAmount;
                        int agentBuyOrSell;
                        try
                        {
                            Console.WriteLine("Enter commodity ID and then 'Enter'");
                            agentID = Int32.Parse(Console.ReadLine());
                            Console.WriteLine("Enter price and then 'Enter'");
                            agentPrice = Int32.Parse(Console.ReadLine());
                            Console.WriteLine("Enter amount and then 'Enter'");
                            agentAmount = Int32.Parse(Console.ReadLine());
                            Console.WriteLine("Enter '1' to buy " + agentAmount + " of " + agentID + " when price drops below " + agentPrice + ", and '-1' to sell when the price goes above " + agentPrice);
                            agentBuyOrSell = Int32.Parse(Console.ReadLine());
                        }
                        catch (FormatException e)
                        {
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("---Invalid input---");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Invalid input. Returning to main menu (Enter new command)");
                            Console.ResetColor();
                            goto MainMenu;
                        }
                        catch (OverflowException) //Int too big
                        {
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("---Invalid input---");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Invalid input. Returning to main menu (Enter new command)");
                            Console.ResetColor();
                            goto MainMenu;
                        }
                        try
                        {
                            Agent.setAgentRules(agentID, agentPrice, agentAmount, agentBuyOrSell);
                            Console.ForegroundColor = ConsoleColor.Green;
                            Console.WriteLine("Agent rules:");
                            Console.Write("If the price for commidity "+agentID+", is ");
                            if (agentBuyOrSell == 1)
                                Console.Write("below " + agentPrice+", buy ");
                            else
                                Console.Write("above " + agentPrice+", sell ");
                            Console.Write(agentAmount + " items of that commodity");
                            Console.WriteLine();
                            Console.ResetColor();
                        }
                        catch (FormatException e) //Exception from agent
                        {
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("---Invalid input---");
                            Console.WriteLine();
                            Console.ForegroundColor = ConsoleColor.DarkCyan;
                            Console.WriteLine("Invalid input. Returning to main menu (Enter new command)");
                            Console.ResetColor();
                            goto MainMenu;
                        }
                        break;

                    case "10": //query all market requests
                        Console.ForegroundColor = ConsoleColor.Green;
                        Object[] allMarketRequest = client.SendQueryAllMarketRequest();
                        for(int i=0;i<MAX_COMMODITIES;i++)
                            Console.WriteLine(allMarketRequest[i].ToString());
                        Console.ResetColor();
                        break;
                    case "11": //query all user requests
                        Console.ForegroundColor = ConsoleColor.Green;
                        Object[] allUserRequests = client.SendQueryAllUserRequests();
                        for (int i = 0; i < allUserRequests.Length; i++)
                            Console.WriteLine(allUserRequests[i].ToString());
                        Console.ResetColor();
                        break;
                    case "a": //toggle off agent -- for testing purposes
                        Agent.toggleAgent(false);
                        break;
                    case "b": //run SQL tests - for testing purposes - ignore this section
                        double[] DELETEME = client.getSQL();
                        for (int i = 0; i < 30; i++)
                            Console.WriteLine("cell: " + i + " value:" + DELETEME[i]);
                        for (int j = 0; j < 10; j++)
                        {
                            DELETEME = client.getSQLAverages(j);
                            for (int i = 0; i < 10; i++)
                                Console.WriteLine("NOW cell: " + i + " value:" + DELETEME[i]);
                        }
                        break;
                    default:
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Invalid input. (Enter new command)");
                        Console.ResetColor();
                        break;

                      

                }
            
                //end of MainMenu options
                s = Console.ReadLine();
            }
        }
        
        public static int ToInt(string s)
        {
            int output = 0;
            int multi = 1;
            while(s.Length != 0)
            {
                output = output + (s[s.Length - 1] - 60) * multi;
                multi = multi * 10;
                s = s.Substring(0, s.Length - 1);
            }
            return output;
        }

        public static void PrintMenu()
        {
            
            Console.WriteLine("ALGO-TRADING");
            //Console.BackgroundColor = ConsoleColor.DarkRed;
            Console.ForegroundColor = ConsoleColor.DarkCyan;

            Console.WriteLine("Press on the number of the function    ");
            Console.WriteLine("You would like to use and then 'Enter':");
            Console.ResetColor();
            //Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("Buy            - ");
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("1");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Blue;
            //Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Write("Sell           - ");
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("2");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Blue;
            //Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Write("Cancel         - ");
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("3");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Blue;
            //Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Write("Query sell/buy - ");
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("4");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Blue;
            //Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Write("Query user     - ");
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("5");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Blue;
            //Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Write("Query market   - ");
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("6");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Blue;
            //Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Write("Re-Print Menu  - ");
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("7");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Blue;
            //Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Write("Clear Screen   - ");
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("8");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Blue;
            //Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Write("Agent Rules    - ");
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("9");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Blue;
            //Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Write("All Market     - ");
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("10");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Blue;
            //Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.Write("All User       - ");
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("11");
            Console.ResetColor();
            //Console.BackgroundColor = ConsoleColor.DarkBlue;
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.Write("Exit           - ");
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("0");
            Console.ResetColor();
           

        }
        static void Main(string[] args)
        {
            ILog myLog = LogManager.GetLogger("MyFileAppender");
            myLog.Info("system works");
            string fileName = "history.log";
            FileInfo f = new FileInfo(fileName);
            string curr = f.FullName;
            string history;
            if (File.Exists(curr))
            {
                history = File.ReadAllText(curr);
                
            }
            MainMenu();
            Console.ReadLine();

        }
    }
}