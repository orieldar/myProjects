import java.util.Comparator;
public class xComparator implements Comparator {
	/*
	Compares its two arguments for order according to the X axis.
	
	Returns a negative integer, zero, or a positive integer
	as the first argument is less than, equal to, or greater than the second.
	*/
	public xComparator() {
		super();
	}

	public int compare(Object o1, Object o2) {	
		return ((Container)o1).getData(true) - ((Container)o2).getData(true);
	}
}

