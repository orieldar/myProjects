import java.util.Comparator;
public class yComparator implements Comparator {
	/*
	Compares its two arguments for order according to the Y axis.
	
	Returns a negative integer, zero, or a positive integer
	as the first argument is less than, equal to, or greater than the second.
	*/
	public yComparator() {
		super();
	}

	public int compare(Object o1, Object o2) {	
		return ((Container)o1).getData(false) - ((Container)o2).getData(false);
	}
}
