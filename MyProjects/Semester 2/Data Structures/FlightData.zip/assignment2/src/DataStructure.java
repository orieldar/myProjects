import java.util.Arrays;
public class DataStructure implements DT {
	
	private Container firstX;//Field of the first Container on the X axis
	private Container lastX;//Field of the last Container on the X axis
	private Container firstY;//Field of the first Container on the Y axis
	private Container lastY;//Field of the last Container on the Y axis
	private int numContainers;//Field that counts the number of Containers in the DataStructure
	

	//////////////// DON'T DELETE THIS CONSTRUCTOR ////////////////
	public DataStructure()//DataStructure Constructor
	{
		firstX =null;
		firstY = null;
		lastX =null;
		lastY = null;
		numContainers = 0;
	}
	public Container getFirst(boolean axis){//Method that returns the first Container according to the axis
		if(axis)
			return firstX;
		else
			return firstY;
	}
	public Container getLast(boolean axis){//Method that returns the last Container according to the axis
		if(axis)
			return lastX;
		else
			return lastY;
	}
	
	public void setFirst(Container first, boolean axis){//Method that sets the first Container according to the axis
		if(axis)
			firstX = first;
		else
			firstY = first;
	}
	public void setLast(Container last, boolean axis){//Method that sets the last Container according to the axis
		if(axis)
			lastX = last;
		else
			lastY = last;
	}
	public void addPoint(Point point) {//Method that adds a point to the DataStructure
		Container add = new Container(point);
		if(numContainers==0){//When the data structure is empty, set the first and last fields to the only Container
			firstX = add;
			lastX = add;
			firstY = add;
			lastY = add;
		}
		else {//If not, add the container and set the fields according to the axis.
			addPoint(add, true);
			addPoint(add, false);
		}
		numContainers++;//Add a container to the number of containers
	}
	
	private void addPoint(Container add, boolean axis){//Method that adds the container and sets the relevant fields.
		Container curr = getFirst(axis);//We will use a temporary container to run through all the containers
		boolean insert = false;
		for(int i=0; i<=numContainers  & !insert; i++){//We will run through the containers, and add the container where it belongs on the axis
			if(curr == null){//If curr is null, then the container is last on its axis.
				if(axis == true){
					lastX.setNext(add, axis);//We will set the fields accordingly
					add.setPrev(lastX, axis);
					lastX = add;
					insert = true;
				}
				else{
					lastY.setNext(add, axis);
					add.setPrev(lastY, axis);
					lastY = add;
					insert = true;
				}
			}
			else{//
				if((!insert)&&(curr.getData(axis)>add.getData(axis))){//covers the case where the containers place is somewhere in the middle
					add.setPrev(curr.getPrev(axis), axis);//here we will set all the fields accordingly
					add.setNext(curr, axis);
					curr.setPrev(add, axis);
					if(add.getPrev(axis)!=null)
						(add.getPrev(axis)).setNext(add, axis);
					else//covers the case where the containers place is first
						setFirst(add, axis);
					insert = true;
				}
				curr = curr.getNext(axis);//advance to the next container on the axis.
			}
		}
	}
	@Override
	public Point[] getPointsInRangeRegAxis(int min, int max, Boolean axis) {//Method that gets points in range sorted by axis
		if((min==max)||(numContainers == 0))
			return new Point[0];
		int counter = 0;//We will first count the number of points, to create the wanted array.
		Container start = getFirst(axis);
		Container finish = getLast(axis);
		boolean startCheck = false;
		boolean finishCheck = false;
		while((!startCheck)|(!finishCheck)){
			if((start.getData(axis))>=min)//We will run from the first container forward until we reach the min
				startCheck = true;
			else{
				start = start.getNext(axis);
				counter++;
			}
			if((finish.getData(axis))<=max)//We will run from the last container backwards until we reach the max
				finishCheck = true;
			else{
				finish = finish.getPrev(axis);
				counter++;
			}
			if(counter>=numContainers)//We will return an empty array if there aren't any points in the range.
				return new Point[0];
			}
		Point[] result = new Point[numContainers-counter];//Create a new array with the number of points.
		for(int i=0; i<result.length; i++){//We will copy all of the points into the array according to the axis
			result[i] = start.getData();
			start = start.getNext(axis);
		}
		return result;
	}

	@Override
	public Point[] getPointsInRangeOppAxis(int min, int max, Boolean axis) {//Method that gets points in range sorted by opposite axis
		if(min==max)
			return new Point[0];
		int counter = 0;
		Container curr = this.getFirst(!axis);
		for(int i=0; i<numContainers; i ++){//First we will count how many containers are in range
			if((curr.getData(axis)>=min)&(curr.getData(axis)<=max))
				counter++;
			curr = curr.getNext(!axis);
		}
		Point[] result = new Point[counter];//We will then create an array
		curr = this.getFirst(!axis);
		int index = 0;
		for(int i=0; i<numContainers; i++){//And add the relevant Containers according to the opposite axis
			if((curr.getData(axis)>=min)&(curr.getData(axis)<=max)){
				result[index] = curr.getData();
				index++;
			}
			curr = curr.getNext(!axis);	
		}
		return result;
	}

	@Override
	public double getDensity() {//Returns the density according to the formula given
		return numContainers/((lastX.getData(true)-firstX.getData(true))*(lastY.getData(false)-firstY.getData(false)));
	}

	@Override
	public void narrowRange(int min, int max, Boolean axis) {//Method that Narrows the DataSructure to a Specific Range
		if(min==max){
			firstX =null;
			firstY = null;
			lastX =null;
			lastY = null;
			numContainers = 0;
		}
		else{
			Container start = getFirst(axis);
			Container finish = getLast(axis);
			boolean startCheck = false;
			boolean finishCheck = false;
			while((!startCheck)|(!finishCheck)){//We will run from the first container forward until we reach the min
				if((start.getData(axis))>=min)
					startCheck = true;
				else{//if the container isn't in our range, then we will "delete" it by setting the relevant fields.
					if(start.getNext(!axis)!=null){
						start.getNext(!axis).setPrev(start.getPrev(!axis), !axis);
						if(start.getPrev(!axis)!=null)
							start.getPrev(!axis).setNext(start.getNext(!axis), !axis);
						else
							setFirst(start, !axis);
					}
					start = start.getNext(axis);//we will set the first container accordingly
					start.setPrev(null, axis);
					setFirst(start, axis);
					numContainers--;//and reduce the number of containers
				}
				if((finish.getData(axis))<=max)//We will run from the last container back until we reach the max
					finishCheck = true;
				else{//if the container isn't in our range, then we will "delete" it by setting the relevant fields.
					if(finish.getPrev(!axis)!=null)
						finish.getPrev(!axis).setNext(finish.getNext(!axis), !axis);
					if(finish.getNext(!axis)!=null)
						finish.getNext(!axis).setPrev(finish.getPrev(!axis), !axis);
					else
						setLast(finish, !axis);
					finish = finish.getPrev(axis);//we will set the last container accordingly
					finish.setNext(null, axis);
					setLast(finish, axis);
					numContainers--;//and reduce the number of containers;
				}
			}
		}
	}

	@Override
	public Boolean getLargestAxis() {//Returns the Largest Axis by comparing the first and last in each axis
		if((lastX.getData(true)-firstX.getData(true))>(lastY.getData(false)-firstY.getData(false)))
			return true;
		else
			return false;
	}

	@Override
	public Container getMedian(Boolean axis) {//Returns the median of the DataStructure
		Container curr = this.getFirst(axis);
		for(int i=0; i<(numContainers/2); i++)
			curr=curr.getNext(axis);
		return curr;
	}

	@Override
	public Point[] nearestPairInStrip(Container container, double width,
			Boolean axis) {//Method that returns the nearest points in a Strip
		int counter=0;//first we will count the number of containers in the strip
		boolean checkL = false;
		boolean checkR = false;
		Point[] result = new Point[2];//Create the array that we will return
		double min = distance(getFirst(axis).getData(), getLast(axis).getData());
		result[0] = getFirst(axis).getData();//And initialise it with our first and last points
		result[1] = getLast(axis).getData();
		Container right = container.getNext(axis);//We will start from the container and advance to the two directions accordingly
		Container left = container.getPrev(axis);
		while(!checkL & !checkR){
			if((right.getData(axis)-container.getData(axis)) > Math.ceil(width/2))//We will check if the current container is in the strip or not
				checkR = true;
			else
				counter++;//We will add to the counter if the container is in the strip
			if((container.getData(axis)-left.getData(axis)) > Math.floor(width/2))//We will check if the current container is in the strip or not
				checkL = true;
			else
				counter++;//We will add to the counter if the container is in the strip
			
			if(right.getNext(axis) == null)//We will check if we aren't on the last Container on the axis
				checkR = true;
			else
				right = right.getNext(axis);//And precede to the next container
			if(left.getPrev(axis) == null)//We will check if we aren't on the first Container on the axis
				checkL = true;
			else
				left = left.getPrev(axis);//And precede to the previous container
			}
		if(numContainers>(counter*Math.log(counter))){//We will then check what is smaller "N or BlogB"
			Container[] strip = new Container[counter];// if BlogB is smaller (B the number of Containers in the Strip)
			for(int i=0; i<strip.length; i++){
				left = left.getNext(axis);
				strip[i] = left;
				}
			if(axis)//We will then sort according to the opposite Axis
				Arrays.sort(strip, new yComparator());
			else
				Arrays.sort(strip, new xComparator());
			for(int i=0; i<(strip.length-1); i++){
				boolean check = false;
				for(int j=i+1; j<=7 & !check; j++){//We will then check according to our algorithm
					if(distance(strip[i].getData(), strip[j].getData())<min){//The closest distance between each 7 close points
						result[0] = strip[i].getData();//And add them to our result Array if they are the new Min
						result[1] = strip[j].getData();
						min = distance(strip[i].getData(), strip[j].getData());
					}
					if(j==(strip.length-1))
						check = true;
					}
				}
			}
		else{// //If N(number of Containers) then we will add all of the containers in the strip to the array,sorted by the opposite axis.
			Point[] strip = getPointsInRangeOppAxis((int)(Math.ceil(container.getData(axis)-(width/2))), (int)(Math.floor(container.getData(axis)+ (width/2))), axis);
			for(int i=0; i<(strip.length-1); i++){
				boolean check = false;
				for(int j=i+1; j<=7 & !check; j++){//Then we will check according to our algorithm
					if(distance(strip[i], strip[j])<min){//The closest distance between each 7 close points
						result[0] = strip[i];
						result[1] = strip[j];
						min = distance(strip[i], strip[j]);
					}
					if(j==(strip.length-1))
						check = true;
					}
			}
		}
		return result;//And return the final result;
	}
	
	private double distance(Point a1, Point a2){//A function that calculates the distance between two points
		int yRange = a1.getY() - a2.getY();
		int xRange = a1.getX() - a2.getX();
		return Math.sqrt((yRange*yRange) + (xRange*xRange));
	}

	

	@Override
	public Point[] nearestPair() {//Method that returns the nearest pair of points
		if(numContainers==0)
			return new Point[0];
		boolean axis = this.getLargestAxis();//First we find the bigger axis
		if(numContainers<2)//if there aren't two points return null
			return null;
		if(numContainers==2)//if there are only two points return them
			return new Point[]{firstX.getData(), lastX.getData()};
		if(numContainers==3){//if there are three points calculate the minimum distance and return the relevant points
			Point p1 = firstX.getData();
			Point p2 = firstX.getNext(true).getData();
			Point p3 = lastX.getData();
			double min = distance(p1, p2);
			Point[] res = new Point[]{p1, p2};
			if(distance(p1, p3)<min){
				min = distance(p1, p3);
				res[0] = p1;
				res[1] = p3;
			}
			if(distance(p2, p3)<min){
				min = distance(p2, p3);
				res[0] = p2;
				res[1] = p3;
			}
			return res;
		}
		Container med = this.getMedian(axis);//Else find the median
		Container curr = this.getFirst(axis);
		DataStructure left = new DataStructure();//And split the data structure into two new data structures, left and right
		DataStructure right = new DataStructure();
		for(int i=0; i<numContainers; i++){
			if(curr.getData(axis)<med.getData(axis))
				left.addPoint(curr.getData());
			else
				right.addPoint(curr.getData());
			curr = curr.getNext(axis);
		}
		Point[] dl = left.nearestPair();//Recursively find the nearest pair in each new data structure
		Point[] dr = right.nearestPair();
		double minDis = Math.min(distance(dl[0],dl[1]), distance(dr[0], dr[1]));//Finds the min distance between dl and dr
		Point[] dm = this.nearestPairInStrip(med, (int)minDis*2, axis);//Check if in the strip there are two points that there distance is smaller than MinDis
		if(distance(dm[0], dm[1])<minDis)//Return the points with the smallest distance found
			return dm;
		else
			if(distance(dl[0],dl[1]) >= distance(dr[0], dr[1]))
				return dr;
			else
				return dl;
		
	}

	public String toString(){ //Method that shows the data structure as a String
		Container currX = firstX;
		Container currY = firstY;
		String st = new String();
		while(currX!=null){
			st = st + currX.toString();
			currX= currX.getNext(true);
		}
		st = st + " \n Y: \n";
		while(currY!=null){
			st = st + currY.toString();
			currY= currY.getNext(false);
		}
		st = st + "\n" + numContainers;
		return st;
		}
	//TODO: add members, methods, etc.
	
}

