
//Don't change the class name
public class Container {
	private Point data;//Don't delete or change this field;
	private Container nextX;//Field of the next Container on the X axis
	private Container nextY;//Field of the next Container on the Y axis
	private Container prevX;//Field of the previous Container on the X axis
	private Container prevY;//Field of the previous Container on the Y axis
	
	
	public Container(Point data, Container nextX, Container nextY, Container prevX, Container prevY){//Container constructor
	    this.data = data;
	    this.nextX = nextX;
	    this.nextY = nextY;
	    this.prevX = prevX;
	    this.prevY = prevY;
	}
	
	public Container(Point data){//Container constructor with data only
	    this(data, null, null, null, null);
	}
	//Don't delete or change this function
	public Point getData()//Method that returns the containers data
	{
		return data;
	}
	public int getData(boolean axis)//Method that Returns data according to the axis
	{
		if(axis)
			return data.getX();
		else
			return data.getY();
	}
	
	public void setData(Point data){//Method that sets the containers data
		this.data = data;
	}
	
	public void setNext(Container next, boolean axis){//Method that sets the next container according to the axis.
		if(axis)
			this.nextX = next;
		else
			this.nextY = next;
	}
	public void setPrev(Container prev, boolean axis){//Method that sets the previous container according to the axis.
		if(axis)
			this.prevX = prev;
		else
			this.prevY = prev;
	}
	
	public Container getNext(boolean axis){//Method that returns the next container according to the axis.
		if(axis)
			return nextX;
		else
			return nextY;
	}
	
	public Container getPrev(boolean axis){//Method that returns the previous container according to the axis.
		if(axis)
			return prevX;
		else
			return prevY;
	}
		
	public String toString(){ 
		return data.toString();
	}
}

