import java.util.ArrayList;

//SUBMIT
public class BNode implements BNodeInterface {

	// ///////////////////BEGIN DO NOT CHANGE ///////////////////
	// ///////////////////BEGIN DO NOT CHANGE ///////////////////
	// ///////////////////BEGIN DO NOT CHANGE ///////////////////
	private final int t;
	private int numOfBlocks;
	private boolean isLeaf;
	private ArrayList<Block> blocksList;
	private ArrayList<BNode> childrenList;

	/**
	 * Constructor for creating a node with a single child.<br>
	 * Useful for creating a new root.
	 */
	public BNode(int t, BNode firstChild) {
		this(t, false, 0);
		this.childrenList.add(firstChild);
	}

	/**
	 * Constructor for creating a <b>leaf</b> node with a single block.
	 */
	public BNode(int t, Block firstBlock) {
		this(t, true, 1);
		this.blocksList.add(firstBlock);
	}

	public BNode(int t, boolean isLeaf, int numOfBlocks) {
		this.t = t;
		this.isLeaf = isLeaf;
		this.numOfBlocks = numOfBlocks;
		this.blocksList = new ArrayList<Block>();
		this.childrenList = new ArrayList<BNode>();
	}

	// For testing purposes.
	public BNode(int t, int numOfBlocks, boolean isLeaf,
			ArrayList<Block> blocksList, ArrayList<BNode> childrenList) {
		this.t = t;
		this.numOfBlocks = numOfBlocks;
		this.isLeaf = isLeaf;
		this.blocksList = blocksList;
		this.childrenList = childrenList;
	}

	@Override
	public int getT() {
		return t;
	}

	@Override
	public int getNumOfBlocks() {
		return numOfBlocks;
	}

	@Override
	public boolean isLeaf() {
		return isLeaf;
	}

	@Override
	public ArrayList<Block> getBlocksList() {
		return blocksList;
	}

	@Override
	public ArrayList<BNode> getChildrenList() {
		return childrenList;
	}

	@Override
	public boolean isFull() {
		return numOfBlocks == 2 * t - 1;
	}

	@Override
	public boolean isMinSize() {
		return numOfBlocks == t - 1;
	}
	
	@Override
	public boolean isEmpty() {
		return numOfBlocks == 0;
	}
	
	@Override
	public int getBlockKeyAt(int indx) {
		return blocksList.get(indx).getKey();
	}
	
	@Override
	public Block getBlockAt(int indx) {
		return blocksList.get(indx);
	}

	@Override
	public BNode getChildAt(int indx) {
		return childrenList.get(indx);
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((blocksList == null) ? 0 : blocksList.hashCode());
		result = prime * result
				+ ((childrenList == null) ? 0 : childrenList.hashCode());
		result = prime * result + (isLeaf ? 1231 : 1237);
		result = prime * result + numOfBlocks;
		result = prime * result + t;
		return result;
	}

	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BNode other = (BNode) obj;
		if (blocksList == null) {
			if (other.blocksList != null)
				return false;
		} else if (!blocksList.equals(other.blocksList))
			return false;
		if (childrenList == null) {
			if (other.childrenList != null)
				return false;
		} else if (!childrenList.equals(other.childrenList))
			return false;
		if (isLeaf != other.isLeaf)
			return false;
		if (numOfBlocks != other.numOfBlocks)
			return false;
		if (t != other.t)
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "BNode [t=" + t + ", numOfBlocks=" + numOfBlocks + ", isLeaf="
				+ isLeaf + ", blocksList=" + blocksList + ", childrenList="
				+ childrenList + "]";
	}

	// ///////////////////DO NOT CHANGE END///////////////////
	// ///////////////////DO NOT CHANGE END///////////////////
	// ///////////////////DO NOT CHANGE END///////////////////
	
	
	
	@Override
	public Block search(int key) {//Search for a block by key
		int i = 0;
		int n = blocksList.size();
		while((i < n)&&(key>(blocksList.get(i)).getKey()))//Run through the blocks until the searched key is smaller than current key.
			i++;
		if((i < n)&&(key==(blocksList.get(i)).getKey()))//If the key is found, return it.
				return blocksList.get(i);
		if(isLeaf)//If the node is a leaf return null, as there are no more nodes to search
			return null;
		else
			return childrenList.get(i).search(key);//Search recursively the relevant child
	}

	@Override
	public void insertNonFull(Block d) {//Insert Block to node
		int i=0;
		if(isLeaf()){//Insert block when node is a leaf
			while((i < numOfBlocks)&&(this.getBlockKeyAt(i) < d.getKey()))
				i++;
			blocksList.add(i, d);
			numOfBlocks++;
		}
		else{
			while((i < numOfBlocks)&&(this.getBlockKeyAt(i) < d.getKey()))
				i++;
			if((this.childrenList.get(i) != null) && (this.childrenList.get(i).isFull())){//If child is full, spit the node.
				splitChild(i);
				if(d.getKey()>getBlockAt(i).getKey())
					i++;
			}
			getChildAt(i).insertNonFull(d);	//Insert block recursively to the relevant child
		}	
	}
	
	public void splitChild(int childIndex){//Splits the child in to two nodes
		BNode child = childrenList.get(childIndex);
		BNode newChild = new BNode (t, child.isLeaf, t-1);
		for (int i = 0; i <= (t-1); i++){
			if(i<(t-1)){
				newChild.blocksList.add(child.getBlockAt(t));
				child.blocksList.remove(t);
			}
			if(!child.isLeaf){
				newChild.childrenList.add(child.getChildAt(t));
				child.childrenList.remove(t);
			}
		}
		blocksList.add(childIndex, (child.blocksList).get(t-1));//Updates the fields accordingly
		child.blocksList.remove(t-1);
		childrenList.add(childIndex+1, newChild);
		numOfBlocks++;
		(child.numOfBlocks) = t-1;
		
	}
	

	@Override
	public void delete(int key) {//Delete block by key
		BNode next;
		if(isLeaf()){ //If node is a leaf 
			deleteFromLeaf(key);
		}
		else{
			int i=0;
			while((i < numOfBlocks)&&(this.getBlockKeyAt(i) < key))
				i++;
			if((i<numOfBlocks)&&(key == getBlockKeyAt(i))){ // Key is found and is not a leaf
				next = getChildAt(i);
				if((next!=null)&(!next.isMinSize())){ //Left has more keys than minimum
					Block shift = next.getMaxKeyBlock();//Shift Relevantly
					blocksList.remove(i);
					blocksList.add(i, shift);
					next.delete(shift.getKey());
				}
				else{
					next = getChildAt(i+1);
					if((next!=null)&(!next.isMinSize())){ //Right has more keys than minimum
						Block shift = next.getMinKeyBlock();//Shift Relevantly
						blocksList.remove(i);
						blocksList.add(i, shift);
						next.delete(shift.getKey());
					}
					else{ //*Both Children have t-1 keys
						next = getChildAt(i);
						mergeWithRightSibling(i);//Merge with right sibling
						next.delete(key);
					}
				}
			}
			else{ //** Key is the next node
				next = getChildAt(i);
				while(next.isMinSize()) // We make sure the next node is not minimal
					variationMinimal(i);
				next.delete(key);
			}
		
	}
	}
	private void deleteFromLeaf(int key){ //delete Block from leaf by key
		boolean deleted = false;
		Block curr;
		for(int i=0;i < numOfBlocks & !deleted; i++){
			curr = blocksList.get(i);
			if(curr.getKey() == key){
				blocksList.remove(i);//update relevant fields
				deleted = true;
				numOfBlocks--;
			}
		}
	}
	private void variationMinimal (int childIndx){ //Check if the next node is minimal
		if(childHasNonMinimalRightSibling(childIndx)) //We have a non minimal right so we can shift
			shiftFromRightSibling(childIndx);
		else{
			if(childHasNonMinimalLeftSibling(childIndx)) //We have a non minimal left so we can shift
				shiftFromLeftSibling(childIndx);
			else{ // Both siblings are minimal so we merge
				if(childIndx<(childrenList.size()-1)) 
					mergeWithRightSibling(childIndx);
				else
					mergeWithLeftSibling(childIndx);	
			}
		}
	}
	private void shiftFromRightSibling (int childIndx){//Node shift from Right Sibling	
		BNode child = childrenList.get(childIndx);
		BNode rightSib = childrenList.get(childIndx+1);
		Block shift = rightSib.getMinKeyBlock();
		child.insertNonFull(blocksList.get(childIndx));
		blocksList.set(childIndx, shift);
		rightSib.delete(shift.getKey());
	}
	
	private void shiftFromLeftSibling (int childIndx){	//Node shift from Left Sibling
		BNode child = childrenList.get(childIndx);
		BNode leftSib = childrenList.get(childIndx-1);
		Block shift = leftSib.getMaxKeyBlock();
		child.insertNonFull(blocksList.get(childIndx-1));
		blocksList.set(childIndx-1, shift);
		leftSib.delete(shift.getKey());
	}
	private void mergeWithRightSibling (int childIndx){//Node Merge with Right Sibling
		BNode child = childrenList.get(childIndx);
		BNode sibling = childrenList.get(childIndx+1);
		child.blocksList.add(blocksList.get(childIndx));
		blocksList.remove(childIndx);
		numOfBlocks--;
		child.numOfBlocks++;
		for(int i=0; i < sibling.numOfBlocks; i++){
			child.blocksList.add(sibling.blocksList.get(i));
			child.numOfBlocks++;
			if(!sibling.isLeaf)
				child.childrenList.add(sibling.childrenList.get(i));
		}
		if(!sibling.isLeaf)
			child.childrenList.add(sibling.childrenList.get(sibling.numOfBlocks));
		childrenList.remove(childIndx+1);
		
	}
	private void mergeWithLeftSibling(int childIndx){//Node Merge with Left Sibling
		BNode child = childrenList.get(childIndx);
		BNode sibling = childrenList.get(childIndx-1);
		child.blocksList.add(0, blocksList.get(childIndx-1));
		blocksList.remove(childIndx-1);
		numOfBlocks--;
		child.numOfBlocks++;
		for(int i=0; i < sibling.numOfBlocks; i++){
			child.blocksList.add(i, sibling.blocksList.get(i));
			child.numOfBlocks++;
			if(!sibling.isLeaf)
				child.childrenList.add(i, sibling.childrenList.get(i));
		}
		if(!sibling.isLeaf)
			child.childrenList.add(sibling.numOfBlocks, sibling.childrenList.get(sibling.numOfBlocks));
		childrenList.remove(childIndx-1);
		
	}
	private boolean childHasNonMinimalLeftSibling(int childIndx){//Check if left sibling is Minimal
		if(childIndx==0)
			return false;
		BNode leftSib = childrenList.get(childIndx-1);
		if(leftSib.numOfBlocks==0)
			return false;
		return (leftSib !=null)&&(!leftSib.isMinSize());
	}
	
	private boolean childHasNonMinimalRightSibling(int childIndx){//Check if right sibling is Minimal
		if(childIndx>=(childrenList.size()-1))
			return false;
		BNode rightSib = childrenList.get(childIndx+1);
		if(rightSib.numOfBlocks==0)
			return false;
		return (rightSib != null)&&(!rightSib.isMinSize());
	}

	
	private Block getMinKeyBlock(){// Get minimum key in Block
		if(isLeaf())
			return blocksList.get(0);
		if(childrenList.get(0)==null)
			return blocksList.get(0);
		else{
			return childrenList.get(0).getMinKeyBlock();
		}
	}

	private Block getMaxKeyBlock(){ // Get maximum key in Block
		if (isLeaf())
			return blocksList.get(numOfBlocks-1);
		if(childrenList.get(numOfBlocks)==null)
			return blocksList.get(numOfBlocks-1);
		else{
			return childrenList.get(numOfBlocks).getMaxKeyBlock();
		}
	}

	@Override
	public MerkleBNode createHashNode() { // Creates Merkle B-tree node
		if (isLeaf){ 
			ArrayList<byte[]> toHash = new ArrayList<byte[]>(); 
			for (int i=0;i<numOfBlocks;i=i++) 
				toHash.add(getBlockAt(i).getData());
			byte[] toIns= HashUtils.sha1Hash(toHash); 
			MerkleBNode ans = new MerkleBNode(toIns); 
			return ans;
		}
		else{ 
			ArrayList<byte[]> toHash = new ArrayList<byte[]>(); 
			ArrayList<MerkleBNode> childrenBList =new ArrayList<MerkleBNode>();
			for (int j=0;j<numOfBlocks;j=j++){ 
				MerkleBNode child=getChildAt(j).createHashNode(); 
				toHash.add(child.getHashValue());
				toHash.add(getBlockAt(j).getData());
				childrenBList.add(child);
			}
			MerkleBNode child=getChildAt(numOfBlocks).createHashNode(); 
			toHash.add(child.getHashValue()); 
			childrenBList.add(child); 
			byte[] toIns= HashUtils.sha1Hash(toHash); 
			MerkleBNode ans = new MerkleBNode(toIns, isLeaf, childrenBList);
			return ans;
		}
			
	}

}
