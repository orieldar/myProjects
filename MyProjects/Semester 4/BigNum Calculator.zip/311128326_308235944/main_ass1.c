#include <stdio.h>
#include <malloc.h>
#include <stdlib.h>



int sp=0;
int i;


typedef struct bignum {
    int negative;
    long number_of_digits;
    char* digit;

} bignum;


extern void addBigNums (bignum* num1, bignum* num2);
extern void multBigNums (bignum* num1, bignum* num2, bignum* result, bignum* tmp2);
extern void divBigNums(bignum* num1, bignum* num2, bignum* result, bignum* factor);
extern void subBigNums (bignum* num1, bignum* num2, int flag);

bignum stack[1024];


bignum* pop(){
  sp = sp-1;
  return &(stack[sp]);
}


void initStack(bignum* sta) {
    for (i = 0; i < 1024; i++) {
        sta[i].digit = (char *) malloc(1000000);
        sta[i].number_of_digits = 0;
        sta[i].negative = 0;
    }
}

    int leftBigger(bignum *num1, bignum *num2) {
        int zeroes1 = 0;
        int zeroes2 = 0;

        if (num1->number_of_digits < num2->number_of_digits)
            return 0;
        else if (num1->number_of_digits > num2->number_of_digits)
            return 1;

        while (num1->digit[zeroes1] == '0')
            zeroes1++;

        while (num2->digit[zeroes2] == '0')
            zeroes2++;

        if (num1->number_of_digits == num2->number_of_digits) {
            for (i = 0; i < num1->number_of_digits; i++) {
                if (num1->digit[i + zeroes1] > num2->digit[i + zeroes2])
                    return 1;
                if (num1->digit[i + zeroes1] < num2->digit[i + zeroes2])
                    return 0;
            }
        }

        return 2;
    }

    int main(void) {
        initStack(stack);
        char c;
        int numFlag = 0;
        int j;
        bignum *num;
        bignum *num1;
        bignum *num2;
        bignum *result;
        bignum *factor;
        bignum *tmp2;
        factor = malloc(sizeof(bignum));
        //FILE *input = fopen("input.txt", "r");
        FILE *input = stdin;
        FILE *output = stdout;
        int counter = 0;
        c = fgetc(input);

        while (c != 'q') {
            num = &(stack[sp]);
            switch (c) {

                case '*':
                    if (numFlag) {
                        sp++;
                        if ((num->number_of_digits == 1) && (num->digit[0] == '0'))
                            num->negative = 2;
                    }
                    numFlag = 0;
                    num1 = pop();
                    num2 = pop();
                    result = malloc(sizeof(result));
                    result->negative = 2;
                    result->number_of_digits = 1;

                    tmp2 = malloc(sizeof(tmp2));
                    tmp2->negative = 2;
                    tmp2->number_of_digits = 1;

                    if (leftBigger(num2, num1)) {
                        (*result).digit = (char *) malloc((num2->number_of_digits) * 10000000);
                        (*tmp2).digit = (char *) malloc((num2->number_of_digits) * 10000000);
                        (*num2).digit = (char *) realloc((*num2).digit, (*num2).number_of_digits * 10000000);
                        result->digit[0] = '0';
                        tmp2->digit[0] = '0';
                        multBigNums(num2, num1, result, tmp2);
                    } else {
                        (*num1).digit = (char *) realloc((*num1).digit, (*num1).number_of_digits * 10000000);
                        (*result).digit = (char *) malloc((num1->number_of_digits) * 10000000);
                        (*tmp2).digit = (char *) malloc((num1->number_of_digits) * 10000000);
                        result->digit[0] = '0';
                        tmp2->digit[0] = '0';
                        multBigNums(num1, num2, result, tmp2);
                    }

                    num2->negative = result->negative;
                    num2->number_of_digits = result->number_of_digits;
                    num2->digit = result->digit;
                    (*num1).digit = (char *) malloc(1000000);
                    (*num1).number_of_digits = 0;
                    (*num1).negative = 0;
                    sp++;
                    break;

                case '+':
                    if (numFlag) {
                        sp++;
                        if ((num->number_of_digits == 1) && (num->digit[0] == '0'))
                            num->negative = 2;
                    }
                    numFlag = 0;
                    num2 = pop();
                    num1 = pop();
                    (*num1).digit = (char *) realloc((*num1).digit, (*num1).number_of_digits + 10);
                    (*num2).digit = (char *) realloc((*num2).digit, (*num1).number_of_digits + 10);
                    if ((num1->negative == 0) && (num2->negative == 1)) {
                        num2->negative = 0; //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                        goto MINUS;
                    }
                    if ((num1->negative == 1) && (num2->negative == 0)) {
                        if (leftBigger(num1, num2)) {
                            subBigNums(num1, num2, 0);
                            free((*num2).digit);
                        } else {
                            subBigNums(num2, num1, 0);
                            free((*num1).digit);
                            (*num1).digit = (*num2).digit;
                            (*num1).number_of_digits = (*num2).number_of_digits;
                            (*num1).negative = num2->negative;
                            (*num2).digit = (char *) malloc(1000000);
                            (*num2).number_of_digits = 0;
                            (*num2).negative = 0;
                        }
                    }

                PLUS: //jmp
                    if (((num1->negative == 1) && (num2->negative == 1)) ||
                        ((num1->negative == 0) && (num2->negative == 0))) {
                        if ((*num1).number_of_digits > (*num2).number_of_digits) {
                            addBigNums(num1, num2);
                            free((*num2).digit);
                        } else {
                            addBigNums(num2, num1);
                            free((*num1).digit);
                            (*num1).digit = (*num2).digit;
                            (*num1).number_of_digits = (*num2).number_of_digits;
                        }
                    }
                    (*num2).digit = (char *) malloc((*num2).number_of_digits * 10000000);
                    (*num2).number_of_digits = 0;
                    (*num2).negative = 0;
                    sp++;
                    break;

                case '-':
                    if (numFlag) {
                        sp++;
                        if ((num->number_of_digits == 1) && (num->digit[0] == '0'))
                            num->negative = 2;
                    }
                    numFlag = 0;
                    num2 = pop();
                    num1 = pop();
                    (*num1).digit = (char *) realloc((*num1).digit, (*num1).number_of_digits + 10);
                    (*num2).digit = (char *) realloc((*num2).digit, (*num2).number_of_digits + 10);
                MINUS: //jmp
                    if (num1->negative == 1) {
                        if (num2->negative == 1) {
                            if (leftBigger(num2, num1)) {
                                subBigNums(num2, num1, 0);
                                free((*num1).digit);
                                (*num1).digit = (*num2).digit;
                                (*num1).number_of_digits = (*num2).number_of_digits;
                                (*num1).negative = 0;
                            } else {
                                subBigNums(num1, num2, 1); //switch: -(A-B)
                                free((*num2).digit);
                            }

                        } else {
                            num2->negative = 1;
                            goto PLUS; //add and then add minus
                        }
                    } else {
                        if (num2->negative == 1) {
                            num2->negative = 0; //!!!!!!!!!!!!!!!!!!
                            goto PLUS;
                        } else {
                            if (leftBigger(num2, num1)) {
                                subBigNums(num2, num1, 1);//switch: -(A-B)
                                free((*num1).digit);
                                (*num1).digit = (*num2).digit;
                                (*num1).number_of_digits = (*num2).number_of_digits;
                                (*num1).negative = (*num2).negative;
                            } else {
                                subBigNums(num1, num2, 0);
                                free((*num2).digit);
                            }
                        }
                    }
                    (*num2).digit = (char *) malloc(1000000);
                    (*num2).number_of_digits = 0;
                    (*num2).negative = 0;
                    sp++;
                    break;

                case '/':
                    if (numFlag) {
                        sp++;
                        if ((num->number_of_digits == 1) && (num->digit[0] == '0'))
                            num->negative = 2;
                    }
                    numFlag = 0;
                    num2 = pop();
                    num1 = pop();
                    if (leftBigger(num1, num2) == 0) {
                        num1->digit[0] = '0';
                        num1->number_of_digits = 1;
                        num1->negative = 2;
                    } else {
                      //  (*num2).digit = (char *) realloc((*num2).digit, (*num1).number_of_digits * 1000000);
                        result = malloc(sizeof(result));
                        result->digit = (char *) malloc(num1->number_of_digits * 1000000);
                        result->digit[0] = '0';
                        result->number_of_digits = 1;
                        result->negative = 2;
                        factor->digit = (char *) malloc(num1->number_of_digits * 1000000);
                        factor->digit[0] = '1';
                        factor->number_of_digits = 1;
                        divBigNums(num1, num2, result, factor);
                        free(num1->digit);
                        num1->digit = result->digit;
                        num1->number_of_digits = result->number_of_digits;
                        num1->negative = result->negative;
                        free((factor->digit));

                        if (num1->negative == 2)
                            printf("DIVIDED BY ZERO!\n");
                    }
                    free(num2->digit);
                    (*num2).number_of_digits = 0;
                    (*num2).negative = 0;
                    (*num2).digit = (char *) malloc(1000000);
                    //free(result);
                    sp++;

                    break;

                case 'c':
                    numFlag = 0;
                    for (i = 0; i < 1024; i++) {
                        free(stack[i].digit);
                        stack[i].digit = (char *) malloc(1000000);
                        stack[i].number_of_digits = 0;
                        stack[i].negative = 0;
                    }
                    sp = 0;
                    break;

                case 'p':
                    if (numFlag) {
                        sp++;
                        if ((num->number_of_digits == 1) && (num->digit[0] == '0'))
                            num->negative = 2;
                    }
                    numFlag = 0;
                    //putchar('\n');
                    //printf("PRINT : %s num of digits: %d \n", stack[sp - 1].digit, stack[sp - 1].number_of_digits)
                    if(stack[sp - 1].negative ==2){
                        fprintf(output,"%c", '0');
                            fprintf(output,"%c", '\n');
                    }
                    else {
                        if (stack[sp - 1].negative == 1)
                            putchar('-');
                        i = 0;
                        while (stack[sp - 1].digit[i] == 48)
                            i++;
                        for (j = 0; j < stack[sp - 1].number_of_digits; j++)
                            fprintf(output,"%c", stack[sp - 1].digit[i + j]);
                            fprintf(output,"%c", '\n');
                    }
                    break;

                default:
                    if ((c <= 32) && (numFlag)) {
                        if((num->number_of_digits==1)&&(num->digit[0] == '0'))
                            num->negative=2;
                        sp++;
                        numFlag = 0;
                    } else if (((c <= '9') && (c >= '0')) || (c == '_')) {
                        numFlag = 1;
                        if (c == '_')
                            num->negative = 1;
                        else {
                            (*num).number_of_digits++;
                            counter++;
                            (*num).digit[((*num).number_of_digits) - 1] = c;
                            if (counter == 1000000) {
                                (*num).digit = (char *) realloc((*num).digit, (*num).number_of_digits + 1000000);
                                counter = 0;
                            }
                        }
                    }
            }
            c = fgetc(input);
        }
        free(factor);
        for (i = 0; i < 1024; i++)
            free(stack[i].digit);

        return 1;

    }

