
public class Grade {
	//fields
	private Course course;
	private int grade;
	
	public Grade(Course course, int grade){
		if(course==null)	//We will first check if the course given is valid
			throw new IllegalArgumentException("Course not vailid");
		if(grade<0 | grade>100)//Then we will check that the grade is valid
			throw new IllegalArgumentException("Grade not vailid");
		
		this.course=course;
		this.grade=grade;
			
	}

	public int getGrade() {//We will return the grade
		return grade;
	}

	public int setGrade(int grade) {
		if(grade<0 | grade>100)//Then we will check that the grade is valid
			throw new IllegalArgumentException("Grade not vailid");
		int prevGrade=this.grade; //We will set the new grade and return the previous Grade
		this.grade=grade;
		return prevGrade;
	}

	public Course getCourse() {//We will return the course
		return course;
	}
	
	public String toString(){// We will convert the data into a String
		String CourseGrade= new String("The grade for: " + course + " is: " + grade); 
		return CourseGrade;
	}
	
	public boolean equals(Object other){
		if(!(other instanceof Grade) ) // First we will check if other is a Grade
			return false;
		boolean isEqual =false;
		Grade otherGrade = (Grade)other;// We will cast Grade as a link since we have checked it's instance
		if(course.equals(otherGrade.getCourse()) & grade==otherGrade.getGrade())//If the grades are the same for the same courses, then the grades are equal.
			isEqual = true;
		return isEqual;
	}
	
	public int computeFinalGrade(){
		return course.computeFinalGrade(grade);//We will return the final grade as calculated, Depends on the type of course.
	}
}
