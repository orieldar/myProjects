
public class StudentGradeAverageComparator implements Comparator {//This class implements comparator

	@Override
	public int compare(Object obj1, Object obj2) {
			if(!(obj1 instanceof Student  ) | !(obj2 instanceof Student  ) ) // First we will check if obj1 and obj2 are Student
				throw new ClassCastException();
			Student studentA= (Student)obj1;//We will cast the objects, since we know they are instances of students.
			Student studentB= (Student)obj2;
			double result= studentB.calculateAverage()-studentA.calculateAverage();//We will then subtract between the averages and return the result as an integer.
			if(result>0)
				return 1;
			if(result<0)
				return -1;
				return 0;
	}

}
