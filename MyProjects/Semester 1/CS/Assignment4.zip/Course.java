
public class Course {
	//fields
	private String courseName;
	private int courseNumber;
	private int credit;
	
	public Course(String name, int number, int credit){
		if(name==null)	//We will first check if the name given is valid
			throw new IllegalArgumentException("Name not vailid");
		for(int i=0;i<name.length();i=i+1){
			if (!Character.isLetterOrDigit(name.charAt(i)) && !Character.isSpaceChar(name.charAt(i)) )//Using Character functions; we will check that the name is valid.
				throw new IllegalArgumentException("Characters of name are not valid");
			}
			if(name.length()==0)//We will check that the string name isn't empty 
				throw new IllegalArgumentException("String name cannot be empty");
			if(number<=0)	//We will check that the course number is valid.
				throw new IllegalArgumentException("Course Number not valid");
			if(credit<=0)	//We will check that the credit given is valid.
				throw new IllegalArgumentException("Credit not valid");
			
				courseName=name;	// After we checked that the variables are valid, we will initialise our fields.
				courseNumber=number;
				this.credit=credit;	
	}

	public String getCourseName(){//We will return the Course name
		return courseName;
	}

	public int getCourseNumber(){//We will return the Course number
		return courseNumber;
	}

	public int getCourseCredit(){//We will return the Course's credit
		return credit;
	}

	public String toString(){//We will convert the data into a string
		String CourseData= new String("Course name is: " + courseName + " ,Course number is: " + courseNumber); 
		return CourseData;
	}

	public boolean equals(Object other){//We will check if two courses are equal
		if(!(other instanceof Course) ) // First we will check if other is a course
			return false;
		boolean isEqual =false;
		Course otherCourse = (Course)other;
		if(courseNumber==otherCourse.getCourseNumber())
			isEqual = true;
		return isEqual;
	}

	public int computeFinalGrade(int grade){
		if(grade<0 | grade>100)
			throw new IllegalArgumentException("Grade not valid");
		return grade;
	}
}
