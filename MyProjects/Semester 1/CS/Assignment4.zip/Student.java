import java.util.Iterator;

public class Student {
	//fields
	private String firstName;
	private String lastName;
	private int studentId;
	private LinkedList courseList;
	private LinkedList gradeList;
	private static final int CREDITS_NEEDED=120;
	
	public Student(String firstName, String lastName, int id) {
		if(firstName==null | lastName==null)	//We will first check if the name given is valid
			throw new IllegalArgumentException("Name not vailid");
		if(firstName.isEmpty() | lastName.isEmpty())	
			throw new IllegalArgumentException("Name not vailid");
		for(int i=0;i<firstName.length();i=i+1){
			if (!Character.isLetter(firstName.charAt(i)) && !Character.isSpaceChar(firstName.charAt(i)) )//Using Character functions; we will check that the First name is valid.
				throw new IllegalArgumentException("Characters of First name are not valid");
		}
		for(int i=0;i<lastName.length();i=i+1){
			if (!Character.isLetter(lastName.charAt(i)) && !Character.isSpaceChar(lastName.charAt(i)) )//Using Character functions; we will check that the Last name is valid.
				throw new IllegalArgumentException("Characters of Last name are not valid");
		}
		if(id<=0)	//We will check that the Id number is valid.
			throw new IllegalArgumentException("Id Number not valid");
		
		this.firstName=firstName;//We will initialise the fields after we have checked the variables
		this.lastName=lastName;
		studentId=id;
		courseList = new LinkedList();
		gradeList = new LinkedList();
	}

	public String getFirstName() { //We will return the First name
		return firstName;
	}

	public String getLastName() { //We will return the Last name
		return lastName;
	}

	public int getId() { //We will return the Student's Id
		return studentId;
	}

	public boolean isRegisteredTo(Course course){ //First we will check if the Course List is empty, if it is then the student isn't registered to any course.
		if(courseList.isEmpty())
			return false;
		if (courseList.contains(course))//If it isn't we will check the Course List contains the course
			return true;
		return false;
	}

	public boolean registerTo(Course course){//We will check first if the student is already registered to the course
		if(isRegisteredTo(course))
			return false;
		else{
			courseList.add(course);//If he isn't we will add the course to his course list
			return true;
		}
	}

	public double calculateAverage(){//We will calculate the students average grade
		double average=0;
		double totalCredits=0;
		double totalGrade=0;
		if(gradeList.isEmpty())//If the student has no grades, then his average is 0.
			return average;
		
		for(Object A : gradeList){//We will add each grade in the student's grades list, multiplied by the credits
			Grade tempGrade= (Grade) A;
			totalCredits= totalCredits + tempGrade.getCourse().getCourseCredit();
			totalGrade= totalGrade + (tempGrade.getGrade() * tempGrade.getCourse().getCourseCredit());
		}
		average= totalGrade/totalCredits; // then we will dived by the total credits to get the average grade.
		return average;
	}

	public boolean addGrade(Course course, int grade){
		if(! isRegisteredTo(course))//First we will check if the student is registered to the specific course
		return false;
		for(Object A : gradeList){//If he is we will check if he already has a grade in that course
			Grade tempGrade= (Grade) A;
			if (tempGrade.getCourse()== course)
				return false;
		}
		Grade tempGrade= new Grade(course,grade);//If he doesn't, then we will add the grade to the student's grade list
		gradeList.add(tempGrade);
		return true;
	}
			

	public int setGrade(Course course, int grade){
		for(Object A : gradeList){//If the student already has a grade in the course, we will set a new grade and return the previous one.
			Grade tempGrade= (Grade) A;
			if (tempGrade.getCourse()== course)
				return tempGrade.setGrade(grade);
		}
		throw new IllegalArgumentException("Student doesn't take course");//If he doesn't take the course, we will throw an illegal Argument Exception.
	}

	public String toString(){//We will convert the student's basic info into a string
		String studentInfo= new String("Student name is: " + firstName + " " + lastName+ ". Id is: " + studentId  ); 
		return studentInfo;
	}

	public boolean equals(Object other){
		if(!(other instanceof Student) ) // First we will check if other is a Student
			return false;
		Student otherStudent=(Student)other;// if he is we will cast other to student and check if the students' Id's are identical.
		if(studentId==otherStudent.getId())
		return true;
		else{
			return false;
		}
	}

	public int getTotalCreditRequired(){//We will return the credits required to finish the degree
		return CREDITS_NEEDED;
	}
	
	public double computeFinalGrade(){
		int totalCredits=0;
		for(Object temp : gradeList){//We will go over the Student's grade List, and check if he has enough credit to finish the Degree.
			Grade tempGrade= (Grade) temp;
			totalCredits= totalCredits + tempGrade.getCourse().getCourseCredit();
		}
		if (totalCredits<CREDITS_NEEDED)//If he doesn't we will return -1
			return -1;
		FinalGradeComparator fgComparator= new FinalGradeComparator();//We will use the Final Grade Comparator to sort our student's Grade list
		gradeList.sortBy(fgComparator);
		double totalfinalCredits=0;
		double totalfinalGrades=0;
		while(totalfinalCredits<CREDITS_NEEDED){//Then we will Calculate the highest Final Grade average until we cover the number of Credits needed.
		for(Object temp : gradeList){//
			Grade tempGrade= (Grade) temp;
				totalfinalGrades=totalfinalGrades + (tempGrade.computeFinalGrade() )* (tempGrade.getCourse().getCourseCredit());
				totalfinalCredits=totalfinalCredits + (tempGrade.getCourse().getCourseCredit());
			}
		}
		return 	totalfinalGrades/totalfinalCredits; 
		

	}
}
