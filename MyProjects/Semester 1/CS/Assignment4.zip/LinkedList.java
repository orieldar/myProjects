import java.util.Iterator;

public class LinkedList implements List {
	private Link first;
	private Link last;

	public LinkedList(){
		first = null;
		last = null;
	}
	
	public void sortBy(Comparator comp){
		nullCheck(comp);//We will check that the Comparator isn't null
		if(first!=null){//if the first link isn't null, meaning the linked list isn't empty
			for(Link prev=first; prev.getNext()!=null;prev=prev.getNext()){//We will use the bubble sorting method to sort our List
				for(Link curr=prev.getNext(); curr!=null;curr=curr.getNext()){
					Object prevData= prev.getData();
					Object currData= curr.getData();
					if(comp.compare(prevData, currData)>0){//We will compare the Links data using the comparator
						Object tempData=prevData;//Then we will swap between the data according to the condition above
						prev.setData(currData);
						curr.setData(tempData);
					}
				}
			}
		}
	}
	
	public String toString() {//We will turn our Linked list to a String using an Iterator
		String output= "{" ;
		Iterator stringIterator= iterator();
		while(stringIterator.hasNext()){
			output=output + stringIterator.next();
			if(stringIterator.hasNext())
				output=output+ ", ";
		}
		output= output+ "}";
		return output;
		}
	
	public boolean equals(Object other) {  //We will check if the Object other equals the LinkedList
		if(!(other instanceof LinkedList) ) // First we will check if other is a LinkedList
			return false;
		LinkedList otherLinkedList = (LinkedList) other;
		if ( size() != otherLinkedList.size())//Then we will check if the sizes are the same
			return false;
		int size= size();
		Link currThis= first;
		for(int i=0; i<size ; i=i+1){// Next we will check if each link in LinkedList is equal to the corresponding link in other
			Link currOther= new Link(otherLinkedList.get(i));
			if (!(currThis.equals(currOther)))
				return false;
			else{
				currThis=currThis.getNext();		
			}
		}
		return true;
	}

	public void add(int index, Object element) {
		rangeCheck(index);
		nullCheck(element);
		if(index == 0) {
			first = new Link(element, first) ;
			if(last == null)
				last = first ;
		} else {
			Link prev = null ;
			Link curr = first ;
			for(int i=0; i<index; i=i+1) {
				prev = curr ;
				curr = curr.getNext() ;
			}
			Link toAdd = new Link(element, curr);
			prev.setNext(toAdd);
			if(index == size())
				last = toAdd;
		}
	}

	public void add(Object element) {
		nullCheck(element);
		if(isEmpty()){
			first = new Link(element);
			last = first;
		}
		else {
			Link newLast = new Link(element);
			last.setNext(newLast);
			last = newLast;
		}
	}

	@Override
	public int size() {
		int size=0;
		if(isEmpty())//We will first check if the list is empty, if it is it's size is 0.
			return size;
		size=1;//If it isn't, then there is at least one link in the list, so we will start the size from 1.
		Link curr = first;
		Link next = curr.getNext();
		while (curr!=last){//We will go through our links an count them until the last link.
			curr = next;
			next = curr.getNext();
			size=size+1;
		}
		return size;		
		}
	
	@Override
	public boolean contains(Object element) {
		Iterator containsIterator= iterator();//We will use an iterator to check if the List contains the element
		while(containsIterator.hasNext()){
			if(containsIterator.next().equals(element))//The iterator  will check if the element equals to each links data
				return true;//if it equals one of them it will return true
		}
		return false;
	}
	
	
	
	@Override
	public boolean isEmpty() {//If the first link is null, then the list is Empty
		return first==null;
	}

	@Override
	public Object get(int index) {
		rangeCheck(index);//First we will check that the index is valid
		Link curr = first;
		Link next = curr.getNext();
		boolean found= false;
		for(int i=0; i<size() & !found; i=i+1){ //Then we will run through the links, counting them, until we match the desired index.
			if(i==index)
				found=true;
			else{
				if(curr!=last){
				curr=next;
				next=curr.getNext();
				}
			}
		}
		return curr.getData();//We will return the data of the desired index's link	
	}

	@Override
	public Object set(int index, Object element) {
		nullCheck(element);
		rangeCheck (index);
		Link curr = first;
		Link next = curr.getNext();
		Object prevData = null;
		boolean found= false;
		for(int i=0; i<size() & !found; i=i+1){ //Then we will run through the links, counting them, until we match the desired index.
			if(i==index){
				prevData= curr.setData(element);
				found=true;
			}
			else{
				if(curr!=last){
				curr=next;
				next=curr.getNext();
				}
			}
		}
		//We will return the data of the desired index's link
		return prevData;	
	}

	@Override
	public Iterator iterator() {//We will return a LinkedListiterator 
		return new LinkedListIterator(first);
	}

	// throws an exception if the given index is not in range
	private void rangeCheck(int index) {
		if(index < 0 || index >= size())
	        throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size());
	}
	
	// throws an exception if the given element is null
	private void nullCheck(Object element){
		if (element == null)
			throw new NullPointerException();
	}
}
