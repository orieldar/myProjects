
public class StudentNameComparator implements Comparator { //This class implements comparator

	@Override
	public int compare(Object obj1, Object obj2) {
		if(!(obj1 instanceof Student  ) | !(obj2 instanceof Student  ) ) // First we will check if obj1 and obj2 are Student
			throw new ClassCastException();
		Student studentA= (Student)obj1;
		Student studentB= (Student)obj2;
		int result=(studentA.getLastName().compareTo((studentB.getLastName()))); //We will compare the last names first.
		if(result==0)//If the last names are Identical, we will compare by the first names.
			return (studentA.getFirstName().compareTo((studentB.getFirstName())));
		else
			return result
					;

	}

}
