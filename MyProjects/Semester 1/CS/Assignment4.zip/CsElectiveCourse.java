
public class CsElectiveCourse extends ElectiveCourse { // This class extends ElectiveCourse

	public CsElectiveCourse(String name, int number, int credit) {//We will initialise the fields
		super(name,number,credit);
	}
	
	public int computeFinalGrade(int grade){//We will calculate the Final Grade with the bonus
			if(grade<0 | grade>100)//We will check if the grade is valid
				throw new IllegalArgumentException("Grade not valid");
			if(grade<56)//If the grade doesn't pass, then we don't include the bonus
				return grade;
			int bonusGrade= grade/10;//If it does we will return with the bonus
			int newGrade= grade + bonusGrade +5;
			if(newGrade>=100)
				return 100;
			else 
				return newGrade;
		}

}
