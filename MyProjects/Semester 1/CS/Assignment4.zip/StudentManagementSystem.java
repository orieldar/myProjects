import java.util.Iterator;

public class StudentManagementSystem {
	//fields
	private LinkedList Courses;
	private LinkedList Students;
	private int numStudents;
	private int numCourses;
	
	public StudentManagementSystem() {//We will initialise the fields
		Courses= new LinkedList();
		Students = new LinkedList();
		numStudents=0;
		numCourses=0;
	}
	
	public boolean addStudent(Student student){//We will add the student to the system
		for(Object A: Students)//First we will check if the student already exists
			if(student.equals((Student)A))
				return false;
		Students.add(student);//If he doesn't we will add him to our list
		numStudents= numStudents+1; // We will add a student to our total number of students
		return true;
	}
	
	public boolean addCourse(Course course){
		for(Object A: Courses)//First we will check if the course already exists
			if(course.equals((Course)A))
				return false;
		Courses.add(course);//If it doesn't we will add it to our list
		numCourses=numCourses+1; //We will add a course to our total number of courses
		return true;
	}
	
	public boolean register(Student student, Course course){
		boolean studentExists=false;
		boolean courseExists=false;
		for(Object A: Students)//First we will check if the student exists
			if((student.equals((Student)A))& !studentExists)
				studentExists=true;
		if( !studentExists)
			return false;
		for(Object A: Courses)//Then we will check if the course exists
			if((course.equals((Course)A)) & !courseExists)
				courseExists=true;
		if( !courseExists)
			return false;
		if(student.isRegisteredTo(course))//We will check if the student is already registered to the course
			return false;
		student.registerTo(course);//If he isn't we will register him, and add the course to his courses list
		return true;
	}
	
	public boolean addGradeToStudent(Student student, Course course, int grade){
		if( !student.isRegisteredTo(course))
				return false;
		boolean studentExists=false;
		boolean courseExists=false;
		for(Object A: Students)//First we will check if the student exists
			if((student.equals((Student)A))& !studentExists)
				studentExists=true;
		if( !studentExists)
			return false;
		for(Object A: Courses)//Then we will check if the course exists
			if((course.equals((Course)A)) & !courseExists)
				courseExists=true;
		if( !courseExists)
			return false;
		
		student.addGrade(course, grade);//If they do we will add the grade of the specific course to the student grades
		return true;
		
	}
	
	public LinkedList getFirstKStudents(Comparator comp, int k){
		if(k>numStudents | k<0)//First we will check if k is Legal 
			throw new IllegalArgumentException("Number of students invalid");
		if(comp==null)//We will check if the Comparator isn't null
			throw new IllegalArgumentException("Invalid Comperator");
		Students.sortBy(comp);//We will sort the Student List using SortBy
		LinkedList sortedK = new LinkedList();// We will make an new sorted LinkList
		for(int i=0;i<k;i=i+1)
			sortedK.add(Students.get(i));//We will add k links to the list and return it as asked for
		return sortedK;
		}
	
	public double computeFinalGrade(Student student){
		boolean studentExists=false;
		for(Object A: Students)//First we will check if the student exists
			if((student.equals((Student)A))& !studentExists)
				studentExists=true;
		if( !studentExists)
			return -1;
		return student.computeFinalGrade();//If he does we will return the student's Final Grade
	}

	public int getNumberOfStudents() {//We will return the number of students
		return numStudents;
	}

	public int getNumberOfCourses() {//We will return the number of courses
		return numCourses;
	}
}
