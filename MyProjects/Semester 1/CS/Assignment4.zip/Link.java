public class Link {
	private Object data;
	private Link next;
	
	public Link(Object data, Link next){
		this.data = data;
		this.next = next;
	}
	public Link(Object data){
		this(data, null);
	}
	public Object getData(){
		return data;
	}
	public Link getNext(){
		return next; 
	}
	public void setNext(Link next){
		this.next = next;
	}
	public Object setData(Object data){
		Object tmp = this.data;
		this.data = data; 
		return tmp;
	}
	
	public String toString(){ 
		return data.toString();
	}
	
	public boolean equals(Object other) { //We will check if the two objects are equal using this method.
			boolean isEqual = true;
			if (! (other instanceof Link))//First we will check if both objects are of the same instance type (Link)
				isEqual = false;
			else {
				Link otherLink = (Link) other;//If they are, we will cast other to Link
				if (data == null){//we will check if both links are null, they are equal.
					if (otherLink.data != null){
							isEqual = false;
						}	
				}	
				else{
					isEqual = data.equals(otherLink.getData());//If they aren't then we will check their data to be equal
					}
				}
			return isEqual;
			}
}



