
public class EngineeringStudent extends Student { //// This class extends Student
	private static final int CREDITS_NEEDED=160;//We will override the field, to change the credits needed
	
	public EngineeringStudent(String firstName, String lastName, int id) {//We will initialise the fields
		super(firstName,lastName,id);
	}
	
	public int getTotalCreditRequired(){
		return CREDITS_NEEDED;
	}

}
