
public class FinalGradeComparator implements Comparator {//This class implements comparator

	@Override
	public int compare(Object obj1, Object obj2) {
		if(!(obj1 instanceof Grade  ) | !(obj2 instanceof Grade  ) ) // First we will check if obj1 and obj2 are Grades
			throw new ClassCastException();
		Grade GradeA= (Grade)obj1;//We will cast the objects, since we know they are instances of Grades.
		Grade GradeB= (Grade)obj2;
		int result=GradeB.computeFinalGrade()-GradeA.computeFinalGrade() ;//We will then subtract between the final Grades and return the result as an integer.
		return result;
	}
}


