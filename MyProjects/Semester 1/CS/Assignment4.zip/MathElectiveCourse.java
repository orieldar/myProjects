
public class MathElectiveCourse extends ElectiveCourse { // This class extends ElectiveCourse


	public MathElectiveCourse(String name, int number, int credit){ //We will initialise the fields
		super(name,number,credit);
	}
	
	public int computeFinalGrade(int grade){//We will calculate the Final Grade with the bonus
			if(grade<0 | grade>100)//We will check if the grade is valid
				throw new IllegalArgumentException("Grade not valid");
			if(grade<56)//If the grade doesn't pass, then we don't include the bonus
				return grade;
			int newGrade= grade+5;//If it does we will return with the bonus
			if(newGrade>=100)
				return 100;
			else 
				return newGrade;
		}
}
