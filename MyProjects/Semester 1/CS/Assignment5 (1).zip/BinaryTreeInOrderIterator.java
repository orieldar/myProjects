import java.util.Iterator;
import java.util.NoSuchElementException;

public class BinaryTreeInOrderIterator implements Iterator{
	private Stack stack;
 
	public BinaryTreeInOrderIterator(BinaryNode root) {
		stack = new StackAsDynamicArray();
		stackLeftRoots(root);
		
	}
	
	private void stackLeftRoots(BinaryNode root){
		while(root!= null){
			stack.push(root);
			root=root.left;
		}
		
	}
 
	public boolean hasNext() {
		boolean output= !(stack.isEmpty());
		return output;
	}
 
	public Object next() {
		BinaryNode currNode =(BinaryNode)stack.pop();
		if (currNode.right!=null)
			stackLeftRoots(currNode.right);
		return currNode.data;
	}
	
	public void remove() {
		throw new UnsupportedOperationException();
	}
}
