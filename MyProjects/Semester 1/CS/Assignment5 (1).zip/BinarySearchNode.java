import java.util.Comparator;
import java.util.Iterator;

public class BinarySearchNode extends BinaryNode{

	private Comparator treeComparator;
	
	public BinarySearchNode(Object data, Comparator myComparator) {
		super(data);
		this.treeComparator = myComparator;
	}
	
	// assume otherTreeRoot.size()>0
	public BinarySearchNode(BinarySearchNode otherTreeRoot, Iterator otherTreeIterator) {
		super("dummy");
		treeComparator = otherTreeRoot.getComparator();
		buildPerfectTree(otherTreeRoot.size());
		fillTheNodes(this, otherTreeIterator);
	}
	
	// element is an Entry with one "dummy" field
	public Object findData(Object element){
		if (treeComparator.compare(data, element) > 0){
			if (left != null )
				return ((BinarySearchNode)left).findData(element);
			else
				return null;
		}
		else if(treeComparator.compare(data, element) < 0){
			if (right != null )
				return ((BinarySearchNode)right).findData(element);
			else
				return null;
		}
		else 
			return this.data;
	}
	
	public Object findMin(){
		BinaryNode currNode = this;
		while (currNode.left != null){
			currNode = currNode.left;
		}
		return currNode.data;
	}
	
	
	// Complete the following methods:
	
	private void buildPerfectTree(int size){
		Queue q = new QueueAsLinkedList();
		int n=1;
		this.data= "dummy";
		q.enqueue(this);
		while (n<size){
			BinarySearchNode nextNode= (BinarySearchNode)q.dequeue();
			BinarySearchNode leftDummyNode = new BinarySearchNode(data,this.treeComparator);
			nextNode.left=leftDummyNode;
			n=n+1;
			q.enqueue(leftDummyNode);
			if(n<size){
				BinarySearchNode rightDummyNode = new BinarySearchNode(data,this.treeComparator);
				nextNode.right=rightDummyNode;
				n=n+1;
				q.enqueue(rightDummyNode);
			}
		}
	}
	
	private void fillTheNodes(BinarySearchNode root, Iterator treeIterator){
		if(left != null){
			((BinarySearchNode) left).fillTheNodes(root,treeIterator);
			}
			if(treeIterator.hasNext())
				data=treeIterator.next();
			if(right != null){
				((BinarySearchNode)right).fillTheNodes(root, treeIterator);
			}
			
		}
	

	public Comparator getComparator(){
		return this.treeComparator;
	}

	public void insert(Object toInsert) {
		if (toInsert == null) 
			throw new NullPointerException();
		if(!this.contains(toInsert)){
			BinarySearchNode newNode = new BinarySearchNode(toInsert,this.treeComparator);
			if(treeComparator.compare(newNode.data, this.data)>0)
				if(this.right==null)
					right=newNode;
				else
					right.insert(toInsert);
			else
				if(treeComparator.compare(newNode.data, this.data)<0)
					if(this.left==null)
						left=newNode;
					else
						left.insert(toInsert);
		}
			   	 
	}
	
	public boolean contains(Object element) {
		if(treeComparator.compare(element, this.data)==0)
			return true;
		if(treeComparator.compare(element, this.data)>0){
			if(this.right==null)
				return false;	
			else
				return right.contains(element);
		}
		else{
			if(treeComparator.compare(element, this.data)<0)
				if(this.left==null)
					return false;
				else
					return left.contains(element);
		}		
		return false;
	}

	
	public BinaryNode remove(Object toRemove){
		if (toRemove == null) 
			throw new NullPointerException();
		
			if(treeComparator.compare(toRemove, this.data)<0){
				if(left!=null)
				left=((BinarySearchNode)left).remove(toRemove);
			}
			else{
				if(treeComparator.compare(toRemove, this.data)>0){
					if(right!=null)
						right=((BinarySearchNode)right).remove(toRemove);
				}
				
			else{
				if(left==null | right==null){
					if (left==null)
						return right;
					if(right==null)
						return left;
				}
			
				else{
					this.data=((BinarySearchNode)left).findMin();
					left=((BinarySearchNode) left).remove(this.data);
				}
			}
			}
			
		return this;
	}
}
		




