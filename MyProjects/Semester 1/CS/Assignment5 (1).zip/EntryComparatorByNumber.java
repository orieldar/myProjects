import java.util.Comparator;

public class EntryComparatorByNumber implements Comparator{

	public int compare(Object o1, Object o2) {
		if(!(o1 instanceof PhoneEntry  ) | !(o2 instanceof PhoneEntry) ) // First we will check if ob1 and ob2 are PhoneEntries
			throw new ClassCastException();
		PhoneEntry PE1=(PhoneEntry)o1;//We will cast the object as we have checked their instance
		PhoneEntry PE2=(PhoneEntry)o2;
		Integer result= PE1.getNumber() - PE2.getNumber();//We will return the result between the numbers
		return result.intValue();
		
	}

}
