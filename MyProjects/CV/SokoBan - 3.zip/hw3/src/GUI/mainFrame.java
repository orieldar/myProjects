package GUI;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.Timer;

import GameObjects.Board;
import levelLoader.*;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Image;
import java.awt.Color;
import java.io.*;
import java.awt.Font;
import javax.swing.JTextField;
import java.awt.Point;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class mainFrame extends JFrame implements ActionListener {

	private Board board;
	private final JLabel label = new JLabel("");
	private JTextField txtLevel;
	private JTextField txtCounter;
	private JButton btnNewGame;
	private JButton btnLevels;
	private JButton restartButton;
	private JButton levelsbutton;
	private int numLevels;
	private int thislevel;
	private Timer timer;
	private Timer timer2;
	private int animCounter;
	private JTextField txtChooseLevel;
	private JLabel hasWon;
	private JTextField undoInstructions;

	public static void main(String[] args) throws IOException {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mainFrame frame = new mainFrame(0);
					frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					frame.setVisible(true);

				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public mainFrame(int level) {
		thislevel = level;
		setLocation(new Point(180, 90));//Center location
		LevelLoader levelLoader = new LevelLoader();
		try {
			levelLoader.load("levels.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
		Cell[][] currentLevel = levelLoader.get(level);
		numLevels = levelLoader.getLevelsCount();
		int width = currentLevel.length;
		int height = currentLevel[0].length;
		setIconImage(Toolkit.getDefaultToolkit().getImage("resources\\spidywon.png"));
		setTitle("Sokoban");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1000, 512);
		setResizable(false);
		getContentPane().setLayout(null);
		btnNewGame = new JButton("");//Launch button
		btnLevels = new JButton("");//Launch button
		
		restartButton = new JButton("");//Game button
		restartButton.setBackground(Color.WHITE);
		restartButton.setBorder(null);
		restartButton.setVisible(false);
		restartButton.setBounds(770, 50, 200, 40);
		ImageIcon icon;
		icon = new ImageIcon("resources\\Resart.png");
		Image img = icon.getImage();
		Image newimg = img.getScaledInstance(200, 40, java.awt.Image.SCALE_SMOOTH);
		icon = new ImageIcon(newimg);
		
		txtChooseLevel = new JTextField();//Level choose
		txtChooseLevel.setBorder(null);
		txtChooseLevel.setFont(new Font("Sitka Small", Font.PLAIN, 13));
		txtChooseLevel.setForeground(Color.WHITE);
		txtChooseLevel.setOpaque(false);
		txtChooseLevel.setVisible(false);
		hasWon = new JLabel("");
		hasWon.setVisible(false);
		
		undoInstructions = new JTextField();//Undo
		undoInstructions.setEnabled(false);
		undoInstructions.setOpaque(false);
		undoInstructions.setBorder(null);
		undoInstructions.setForeground(Color.WHITE);
		undoInstructions.setFont(new Font("Segoe Print", Font.PLAIN, 16));
		undoInstructions.setVisible(false);
		undoInstructions.setText("To Undo Move: Press U");
		undoInstructions.setBounds(314, -3, 223, 33);
		getContentPane().add(undoInstructions);
		undoInstructions.setColumns(10);
		
		hasWon.setIcon(new ImageIcon("resources\\gamewon1.png"));
		hasWon.setBounds(229, 30, 478, 400);
		getContentPane().add(hasWon);
		
		txtLevel = new JTextField();//Current level
		txtLevel.setBounds(110, 0, 180, 33);
		getContentPane().add(txtLevel);
		txtLevel.setFocusable(false);
		txtLevel.setRequestFocusEnabled(false);
		txtLevel.setBorder(null);
		txtLevel.setFont(new Font("Segoe Print", Font.BOLD, 18));
		txtLevel.setForeground(Color.WHITE);
		txtLevel.setBackground(Color.BLACK);
		txtLevel.setVisible(false);
		txtLevel.setOpaque(false);
		txtLevel.setText("Level");
		txtLevel.setColumns(10);
		
		txtChooseLevel.setIgnoreRepaint(true);//Choosing level
		txtChooseLevel.setText("Choose Level:");
		txtChooseLevel.setBounds(813, 144, 137, 20);
		getContentPane().add(txtChooseLevel);
		txtChooseLevel.setColumns(10);
		
		txtCounter = new JTextField();//Level counter
		txtCounter.setBounds(635, 0, 180, 33);
		getContentPane().add(txtCounter);
		txtCounter.setFocusTraversalKeysEnabled(false);
		txtCounter.setFocusable(false);
		txtCounter.setBorder(null);
		txtCounter.setForeground(Color.WHITE);
		txtCounter.setBackground(Color.BLACK);
		txtCounter.setFont(new Font("Segoe Print", Font.BOLD, 18));
		txtCounter.setText("Counter");
		txtCounter.setColumns(10);
		txtCounter.setOpaque(false);
		txtCounter.setVisible(false);
		
		board = new Board(level, height, width);
		board.setBounds(110, 30, 650, 430);
		getContentPane().add(board);
		board.addKeyListener(board);
		board.setFocusable(true);
		board.setVisible(false);
		board.setBackground(Color.BLACK);
		
		JComboBox levelcomboBox = new JComboBox();//Box showing all the available levels
		levelcomboBox.setMaximumRowCount(5);
		levelcomboBox.setModel(new DefaultComboBoxModel());
		levelcomboBox.setAutoscrolls(true);
		levelcomboBox.setBounds(550, 379, 200, 20);
		getContentPane().add(levelcomboBox);
		for (int i = 0; i < numLevels; i++)
			levelcomboBox.addItem("Level " + i);
		levelcomboBox.setVisible(false);
		levelcomboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				mainFrame frame = new mainFrame(levelcomboBox.getSelectedIndex());
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
				dispose();
				frame.btnNewGame.doClick();

			}
		});
		
		btnLevels.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				levelcomboBox.setVisible(true);
			}
		});
		
		levelsbutton = new JButton("");//Launch button
		levelsbutton.setContentAreaFilled(false);
		levelsbutton.setBorderPainted(false);
		levelsbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtChooseLevel.setVisible(true);
				txtChooseLevel.setEditable(false);
				levelcomboBox.setVisible(true);
				board.setFocusable(true);
				board.requestFocusInWindow();

			}
		});
		
		levelsbutton.setIcon(new ImageIcon("resources\\LEVELSimg.png"));
		levelsbutton.setBounds(770, 101, 200, 40);
		levelsbutton.setVisible(false);
		getContentPane().add(levelsbutton);
		ImageIcon icon2;
		icon2 = new ImageIcon("resources\\LEVELSimg.png");
		Image img2 = icon2.getImage();
		Image newimg2 = img2.getScaledInstance(200, 40, java.awt.Image.SCALE_SMOOTH);
		icon2 = new ImageIcon(newimg2);
		levelsbutton.setIcon(icon2);
		levelsbutton.setOpaque(false);
		
		restartButton.setIcon(icon);//Restart button
		restartButton.setBorderPainted(false);
		restartButton.setContentAreaFilled(false);
		restartButton.setFocusPainted(false);
		restartButton.setOpaque(false);
		getContentPane().add(restartButton);
		restartButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				mainFrame frame = new mainFrame(thislevel);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
				dispose();
				frame.btnNewGame.doClick();
				levelcomboBox.setBounds(760, 161, 200, 20);

			}
		});
		
		btnNewGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				label.setIcon(new ImageIcon("resources\\rsz_starswallpaper.jpg"));
				btnNewGame.setVisible(false);
				btnLevels.setVisible(false);
				board.setVisible(true);
				txtLevel.setText("Level: " + board.getLevel());
				txtLevel.setVisible(true);
				txtCounter.setText("0");
				txtCounter.setVisible(true);
				restartButton.setVisible(true);
				levelsbutton.setVisible(true);
				undoInstructions.setVisible(true);
				undoInstructions.setEditable(false);
				levelcomboBox.setBounds(770, 161, 200, 20);
			}
		});
		
		btnLevels.setIcon(new ImageIcon("resources\\rsz_levelsbutton.jpg"));//Adding levels JButton
		btnLevels.setBounds(540, 308, 213, 60);
		getContentPane().add(btnLevels);
		
		btnNewGame.setIcon(new ImageIcon("resources\\newGamebtn.jpg"));//Adding new game JButton
		btnNewGame.setBounds(229, 308, 213, 60);
		getContentPane().add(btnNewGame);
		
		timer = new Timer(200, this);//Timer used until the user wins the game
		timer.start();
		timer2 = new Timer(400, this);//Timer used to activate animations when the game is won
		
		label.setBounds(0, 0, 1000, 483);//Wallpaper
		label.setIcon(new ImageIcon("resources\\spiderman_wallpaper.jpg"));
		getContentPane().add(label);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == timer) {
			txtCounter.setText("Score:" + board.getSteps());//User's current steps count
			if (board.checkHasWon()) {
				hasWon.setVisible(true);
				timer2.start();
				timer.stop();
			}
		}
		if (e.getSource() == timer2) {
			animCounter++;
			if (animCounter % 2 == 0)
				hasWon.setIcon(new ImageIcon("resources\\gamewon1.png"));
			else
				hasWon.setIcon(new ImageIcon("resources\\gamewon2.png"));
			hasWon.repaint();//Repaints the frame when a game is won
		}
	}

	public static String readFile(String fileName) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(fileName));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append("\n");
				line = br.readLine();
			}
			return sb.toString();
		} finally {
			br.close();
		}
	}
}