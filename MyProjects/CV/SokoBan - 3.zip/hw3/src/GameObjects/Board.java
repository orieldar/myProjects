package GameObjects;

import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Stack;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import GUI.mainFrame;
import levelLoader.Cell;
import levelLoader.LevelLoader;

public class Board extends JPanel implements KeyListener {

	private Player player;
	private LevelLoader levelLoader;
	private Cell[][] currentLevel;
	private int levelNumber;
	private JLabel[][] cells;
	private int width;
	private int height;
	private int numOfStorage;
	private int boxInStorage;
	private boolean hasWon;
	private JLabel c;
	private int steps;
	private Stack<KeyEvent> moveUndoStack;
	private Stack<Boolean> boxUndoStack;

	public Board(int levelNum, int height, int width) {//Board constructor
		setLayout(new GridLayout(height, width));//Layout using the levels' measurements
		moveUndoStack = new Stack();
		boxUndoStack = new Stack();
		levelLoader = new LevelLoader();
		try {

			levelLoader.load("levels.txt");
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (levelNum > levelLoader.getLevelsCount())
			throw new IllegalArgumentException("No such Level");
		currentLevel = levelLoader.get(levelNum);
		this.width = width;
		this.height = height;
		levelNumber = levelNum;
		cells = new JLabel[width][height];
		for (int i = 0; i < height; i++)//Making cells in the label for the current level
			for (int j = 0; j < width; j++) {
				c = new JLabel();
				initializeCell(currentLevel, j, i, c);
			}

		for (int x = 0; x < width; x++)
			for (int y = 0; y < height; y++) {
				if (currentLevel[x][y].hasPlayer()) {
					player = new Player(currentLevel, x, y);
				}
			}
	}

	public void keyTyped(KeyEvent e) {

	}

	public void keyPressed(KeyEvent e) {
		if (!hasWon) {
			if (e.getKeyCode() == KeyEvent.VK_UP) {//Everytime the user moves the player up
				if (player.canMoveUp()) {
					moveUndoStack.push(e);//The move is pushed into a stack in order to undo the move later if wanted
					boolean box = (currentLevel[player.getX()][player.getY() - 1].hasBox());
					boxUndoStack.push(box);//Pushes true into the stack if a box was moved by the player, else pushes false
					currentLevel = player.moveUp();
					colorCell(currentLevel, player.getX(), player.getY() + 1);
					colorCell(currentLevel, player.getX(), player.getY());
					colorCell(currentLevel, player.getX(), player.getY() - 1);
					steps++;
				}
			}

			if (e.getKeyCode() == KeyEvent.VK_DOWN) {//Everytime the user moves the player down
				if (player.canMoveDown()) {
					moveUndoStack.push(e);//The move is pushed into a stack in order to undo the move later if wanted
					boolean box = (currentLevel[player.getX()][player.getY() + 1].hasBox());
					boxUndoStack.push(box);//Pushes true into the stack if a box was moved by the player, else pushes false
					currentLevel = player.moveDown();
					colorCell(currentLevel, player.getX(), player.getY() - 1);
					colorCell(currentLevel, player.getX(), player.getY());
					colorCell(currentLevel, player.getX(), player.getY() + 1);
					steps++;
				}
			}

			if (e.getKeyCode() == KeyEvent.VK_RIGHT) {//Everytime the user moves the player right
				if (player.canMoveRight()) {
					moveUndoStack.push(e);//The move is pushed into a stack in order to undo the move later if wanted
					boolean box = (currentLevel[player.getX() + 1][player.getY()].hasBox());
					boxUndoStack.push(box);//Pushes true into the stack if a box was moved by the player, else pushes false
					currentLevel = player.moveRight();
					colorCell(currentLevel, player.getX() - 1, player.getY());
					colorCell(currentLevel, player.getX(), player.getY());
					colorCell(currentLevel, player.getX() + 1, player.getY());
					steps++;

				}
			}

			if (e.getKeyCode() == KeyEvent.VK_LEFT) {//Everytime the user moves the player left
				if (player.canMoveLeft()) {
					moveUndoStack.push(e);//The move is pushed into a stack in order to undo the move later if wanted
					boolean box = (currentLevel[player.getX() - 1][player.getY()].hasBox());
					boxUndoStack.push(box);//Pushes true into the stack if a box was moved by the player, else pushes false
					currentLevel = player.moveLeft();
					colorCell(currentLevel, player.getX() - 1, player.getY());
					colorCell(currentLevel, player.getX(), player.getY());
					colorCell(currentLevel, player.getX() + 1, player.getY());

					steps++;
				}
			}

			if (e.getKeyCode() == KeyEvent.VK_U) {//U key is pressed to undo last move
				if (!moveUndoStack.isEmpty()) {
					KeyEvent event = moveUndoStack.pop();//Moves oppositively to the last move put in the stack
					Boolean hasMovedBox = boxUndoStack.pop();//Checks if a box was moved also
					if (event.getKeyCode() == KeyEvent.VK_UP) {
						currentLevel = player.moveDown();
						if (hasMovedBox == true)
							currentLevel = player.undoBox(event);
						colorCell(currentLevel, player.getX(), player.getY() - 1);
						colorCell(currentLevel, player.getX(), player.getY());
						colorCell(currentLevel, player.getX(), player.getY() - 2);
						steps--;
					}
					if (event.getKeyCode() == KeyEvent.VK_DOWN) {
						currentLevel = player.moveUp();
						if (hasMovedBox == true)
							currentLevel = player.undoBox(event);
						colorCell(currentLevel, player.getX(), player.getY() + 1);
						colorCell(currentLevel, player.getX(), player.getY());
						colorCell(currentLevel, player.getX(), player.getY() + 2);
						steps--;
					}
					if (event.getKeyCode() == KeyEvent.VK_RIGHT) {
						currentLevel = player.moveLeft();
						if (hasMovedBox == true)
							currentLevel = player.undoBox(event);
						colorCell(currentLevel, player.getX() + 1, player.getY());
						colorCell(currentLevel, player.getX(), player.getY());
						colorCell(currentLevel, player.getX() + 2, player.getY());
						steps--;
					}
					if (event.getKeyCode() == KeyEvent.VK_LEFT) {
						currentLevel = player.moveRight();
						if (hasMovedBox == true)
							currentLevel = player.undoBox(event);
						colorCell(currentLevel, player.getX() - 1, player.getY());
						colorCell(currentLevel, player.getX(), player.getY());
						colorCell(currentLevel, player.getX() - 2, player.getY());
						steps--;
					}
				}
			}
		}
	}

	public void keyReleased(KeyEvent e) {

	}

	public int getSteps() {//Get current steps counter
		return steps;
	}

	public void initializeCell(Cell[][] level, int i, int j, JLabel c) {//Retrieves data from the level texts and initializes cells accordingly
		if (level[i][j].isFloor()) {
			if (level[i][j].hasPlayer() & level[i][j].isStorage()) {
				ImageIcon icon;
				icon = new ImageIcon("resources\\spidyinstorage2.jpg");
				Image img = icon.getImage();
				Image newimg = img.getScaledInstance(getCellWidth(), getCellHeight(), java.awt.Image.SCALE_SMOOTH);
				icon = new ImageIcon(newimg);
				c.setIcon(icon);
				c.setSize(getCellWidth(), getCellHeight());
				add(c);
				cells[i][j] = c;
				numOfStorage++;

			} else if (level[i][j].hasBox() & level[i][j].isStorage()) {
				ImageIcon icon;
				icon = new ImageIcon("resources\\boxinstorage.jpg");
				Image img = icon.getImage();
				Image newimg = img.getScaledInstance(getCellWidth(), getCellHeight(), java.awt.Image.SCALE_SMOOTH);
				icon = new ImageIcon(newimg);
				c.setIcon(icon);
				c.setSize(getCellWidth(), getCellHeight());
				add(c);
				cells[i][j] = c;
				numOfStorage++;
			} else if (level[i][j].hasPlayer()) {
				ImageIcon icon;
				icon = new ImageIcon("resources\\spidermanchar.png");
				Image img = icon.getImage();
				Image newimg = img.getScaledInstance(getCellWidth(), getCellHeight(), java.awt.Image.SCALE_SMOOTH);
				icon = new ImageIcon(newimg);
				c.setIcon(icon);
				c.setSize(getCellWidth(), getCellHeight());
				add(c);
				cells[i][j] = c;
			}

			else if (level[i][j].hasBox()) {
				ImageIcon icon;
				icon = new ImageIcon("resources\\blacktilesbox.jpg");
				Image img = icon.getImage();
				Image newimg = img.getScaledInstance(getCellWidth(), getCellHeight(), java.awt.Image.SCALE_SMOOTH);
				icon = new ImageIcon(newimg);
				c.setIcon(icon);
				c.setSize(getCellWidth(), getCellHeight());
				add(c);
				cells[i][j] = c;
			} else if (level[i][j].isStorage()) {
				ImageIcon icon;
				icon = new ImageIcon("resources\\storage3.jpg");
				Image img = icon.getImage();
				Image newimg = img.getScaledInstance(getCellWidth(), getCellHeight(), java.awt.Image.SCALE_SMOOTH);
				icon = new ImageIcon(newimg);
				c.setIcon(icon);
				c.setSize(getCellWidth(), getCellHeight());
				add(c);
				cells[i][j] = c;
				numOfStorage++;
			} else {
				ImageIcon icon;
				icon = new ImageIcon("resources\\blacktiles.jpg");
				Image img = icon.getImage();
				Image newimg = img.getScaledInstance(getCellWidth(), getCellHeight(), java.awt.Image.SCALE_SMOOTH);
				icon = new ImageIcon(newimg);
				c.setIcon(icon);
				c.setSize(getCellWidth(), getCellHeight());
				this.add(c);
				cells[i][j] = c;
			}

		} else {
			ImageIcon icon;
			icon = new ImageIcon("resources\\redtile.jpg");
			Image img = icon.getImage();
			Image newimg = img.getScaledInstance(getCellWidth(), getCellHeight(), java.awt.Image.SCALE_SMOOTH);
			icon = new ImageIcon(newimg);
			c.setIcon(icon);
			c.setSize(getCellWidth(), getCellHeight());

			add(c);
			cells[i][j] = c;
		}
	}

	public void colorCell(Cell[][] level, int i, int j) {//After moving/changing a given level cells are updates and being "colored" to be represented according to current state
		if (level[i][j].isFloor()) {
			if (level[i][j].hasPlayer() & level[i][j].isStorage()) {
				ImageIcon icon;
				icon = new ImageIcon("resources\\spidyinstorage2.jpg");
				Image img = icon.getImage();
				Image newimg = img.getScaledInstance(getCellWidth(), getCellHeight(), java.awt.Image.SCALE_SMOOTH);
				icon = new ImageIcon(newimg);
				cells[i][j].setIcon(icon);
				cells[i][j].setSize(getCellWidth(), getCellHeight());

			} else if (level[i][j].hasBox() & level[i][j].isStorage()) {
				ImageIcon icon;
				icon = new ImageIcon("resources\\boxinstorage.jpg");
				Image img = icon.getImage();
				Image newimg = img.getScaledInstance(getCellWidth(), getCellHeight(), java.awt.Image.SCALE_SMOOTH);
				icon = new ImageIcon(newimg);
				cells[i][j].setIcon(icon);
				cells[i][j].setSize(getCellWidth(), getCellHeight());
				checkHasWon();

			} else if (level[i][j].hasPlayer() & hasWon) {
				ImageIcon icon;
				icon = new ImageIcon("resources\\spidywon.png");
				Image img = icon.getImage();
				Image newimg = img.getScaledInstance(getCellWidth(), getCellHeight(), java.awt.Image.SCALE_SMOOTH);
				icon = new ImageIcon(newimg);
				cells[i][j].setIcon(icon);
				cells[i][j].setSize(getCellWidth(), getCellHeight());
			}

			else if (level[i][j].hasPlayer()) {
				ImageIcon icon;
				icon = new ImageIcon("resources\\spidermanchar.png");
				Image img = icon.getImage();
				Image newimg = img.getScaledInstance(getCellWidth(), getCellHeight(), java.awt.Image.SCALE_SMOOTH);
				icon = new ImageIcon(newimg);
				cells[i][j].setIcon(icon);
				cells[i][j].setSize(getCellWidth(), getCellHeight());
			}

			else if (level[i][j].hasBox()) {
				ImageIcon icon;
				icon = new ImageIcon("resources\\blacktilesbox.jpg");
				Image img = icon.getImage();
				Image newimg = img.getScaledInstance(getCellWidth(), getCellHeight(), java.awt.Image.SCALE_SMOOTH);
				icon = new ImageIcon(newimg);
				cells[i][j].setIcon(icon);
				cells[i][j].setSize(getCellWidth(), getCellHeight());

			} else if (level[i][j].isStorage()) {
				ImageIcon icon;
				icon = new ImageIcon("resources\\storage3.jpg");
				Image img = icon.getImage();
				Image newimg = img.getScaledInstance(getCellWidth(), getCellHeight(), java.awt.Image.SCALE_SMOOTH);
				icon = new ImageIcon(newimg);
				cells[i][j].setIcon(icon);
				cells[i][j].setSize(getCellWidth(), getCellHeight());

			} else {
				ImageIcon icon;
				icon = new ImageIcon("resources\\blacktiles.jpg");
				Image img = icon.getImage();
				Image newimg = img.getScaledInstance(getCellWidth(), getCellHeight(), java.awt.Image.SCALE_SMOOTH);
				icon = new ImageIcon(newimg);
				cells[i][j].setIcon(icon);
				cells[i][j].setSize(getCellWidth(), getCellHeight());
			}

		} else {
			ImageIcon icon;
			icon = new ImageIcon("resources\\redtile.jpg");
			Image img = icon.getImage();
			Image newimg = img.getScaledInstance(getCellWidth(), getCellHeight(), java.awt.Image.SCALE_SMOOTH);
			icon = new ImageIcon(newimg);
			cells[i][j].setIcon(icon);
			cells[i][j].setSize(getCellWidth(), getCellHeight());

		}
	}

	private int getCellHeight() {//Ratio
		return 430 / currentLevel[0].length;

	}

	private int getCellWidth() {//Ratio
		return 650 / currentLevel.length;
	}

	public Cell[][] getCurrentLevel() {//Current level is returned
		return currentLevel;
	}

	public static String readFile(String fileName) throws IOException {//Reads text files
		BufferedReader br = new BufferedReader(new FileReader(fileName));
		try {
			StringBuilder sb = new StringBuilder();
			String line = br.readLine();

			while (line != null) {
				sb.append(line);
				sb.append("\n");
				line = br.readLine();
			}
			return sb.toString();
		} finally {
			br.close();
		}
	}

	public int getLevel() {//Retrieves number of level
		return levelNumber;
	}

	public Player getPlayer() {//Player is returned
		return player;
	}

	public boolean checkHasWon() {//Checks if the level is won, meaning that all boxes are in storage
		boxInStorage = 0;
		for (int x = 0; x < width; x++)
			for (int y = 0; y < height; y++)
				if (currentLevel[x][y].hasBox() & currentLevel[x][y].isStorage())
					boxInStorage++;
		hasWon = boxInStorage == numOfStorage;
		return hasWon;
	}
}
