package GameObjects;

import java.awt.event.KeyEvent;

import levelLoader.Cell;

public class Player {

	private Cell up;
	private Cell down;
	private Cell right;
	private Cell left;
	private Cell[][] board;

	private int x;
	private int y;
	private int width;
	private int height;

	public Player() {
	}

	public Player(Cell[][] levelBoard, int X, int Y) {
		board = levelBoard;
		this.x = X;
		this.y = Y;
		width = board.length;
		height = board[0].length;
		if (y > 0)
			up = board[x][y - 1].clone();
		if (y + 1 < height)
			down = board[x][y + 1];
		if (x + 1 < width)
			right = board[x + 1][y];
		if (x > 0)
			left = board[x - 1][y];
	}

	public boolean canMoveUp() {//Checks if the player can move up at a specific time
		if (up == null)
			return false;
		if (up.isWall())
			return false;
		if (up.hasBox()) {//After the cell above the player is proved to be a box:
			if (y - 2 < 0)//Crosses the boundaries of the board
				return false;
			if (board[x][y - 2] == null)
				return false;
			if (board[x][y - 2].hasBox())//Two boxes above the player
				return false;
			if (board[x][y - 2].isWall())//Wall above the box
				return false;
		}
		return true;
	}

	public boolean canMoveDown() {//Checks if the player can move down at a specific time
		if (down == null)
			return false;
		if (down.isWall())
			return false;
		if (down.hasBox()) {//After the cell below the player is proved to be a box:
			if (y + 2 >= height)//Crosses the boundaries of the board
				return false;
			if (board[x][y + 2] == null)
				return false;
			if (board[x][y + 2].hasBox())//Two boxes below the player
				return false;
			if (board[x][y + 2].isWall())//Wall below the box
				return false;
		}
		return true;
	}

	public boolean canMoveRight() {//Checks if the player can move right at a specific time
		if (right == null)
			return false;
		if (right.isWall())
			return false;
		if (right.hasBox()) {//After the cell right to the player is proved to be a box:
			if (x + 2 >= width)//Crosses the boundaries of the board
				return false;
			if (board[x + 2][y] == null)
				return false;
			if (board[x + 2][y].hasBox())//Two boxes right to the player
				return false;
			if (board[x + 2][y].isWall())//Wall right to the box
				return false;
		}
		return true;
	}

	public boolean canMoveLeft() {//Checks if the player can move left at a specific time
		if (left == null)
			return false;
		if (left.isWall())
			return false;
		if (left.hasBox()) {//After the cell left to the player is proved to be a box:
			if (x - 2 < 0)//Crosses the boundaries of the board
				return false;
			if (board[x - 2][y] == null)
				return false;
			if (board[x - 2][y].hasBox())//Two boxes left to the player
				return false;
			if (board[x - 2][y].isWall())//Wall left to the box
				return false;
		}
		return true;
	}

	public Cell[][] moveUp() {
		if (board[x][y - 1].hasBox()) {//The player has one box above
			board[x][y - 2].set_hasBox(true);
			board[x][y - 1].set_hasBox(false);
			board[x][y - 1].set_hasPlayer(true);
			board[x][y].set_hasPlayer(false);
		} else {//The player doesn't have one box above
			board[x][y - 1].set_hasPlayer(true);
			board[x][y].set_hasPlayer(false);
		}
		up = board[x][y - 2];
		down = board[x][y];
		right = board[x + 1][y - 1];
		left = board[x - 1][y - 1];
		y = y - 1;
		return board;
	}

	public Cell[][] moveDown() {
		if (board[x][y + 1].hasBox()) {//The player has one box below
			board[x][y + 2].set_hasBox(true);
			board[x][y + 1].set_hasBox(false);
			board[x][y + 1].set_hasPlayer(true);
			board[x][y].set_hasPlayer(false);
		} else {//The player doesn't have one box below
			board[x][y + 1].set_hasPlayer(true);
			board[x][y].set_hasPlayer(false);
		}
		up = board[x][y];
		down = board[x][y + 2];
		right = board[x + 1][y + 1];
		left = board[x - 1][y + 1];
		y = y + 1;
		return board;
	}

	public Cell[][] moveRight() {
		if (board[x + 1][y].hasBox()) {//The player has one box on the right
			board[x + 2][y].set_hasBox(true);
			board[x + 1][y].set_hasBox(false);
			board[x + 1][y].set_hasPlayer(true);
			board[x][y].set_hasPlayer(false);
		} else {//The player doesn't have one box on the right
			board[x + 1][y].set_hasPlayer(true);
			board[x][y].set_hasPlayer(false);
		}
		up = board[x + 1][y - 1];
		down = board[x + 1][y + 1];
		right = board[x + 2][y];
		left = board[x][y];
		x = x + 1;
		return board;
	}

	public Cell[][] moveLeft() {
		if (board[x - 1][y].hasBox()) {//The player has one box on the left
			board[x - 2][y].set_hasBox(true);
			board[x - 1][y].set_hasBox(false);
			board[x - 1][y].set_hasPlayer(true);
			board[x][y].set_hasPlayer(false);
		} else {//The player doesn't have one box on the left
			board[x - 1][y].set_hasPlayer(true);
			board[x][y].set_hasPlayer(false);
		}
		up = board[x - 1][y - 1];
		down = board[x - 1][y + 1];
		right = board[x][y];
		left = board[x - 2][y];
		x = x - 1;
		return board;
	}

	public Cell[][] undoBox(KeyEvent e) {//Method to retrieve previous location of a pushed box
		if (e.getKeyCode() == KeyEvent.VK_UP) {
			board[x][y - 2].set_hasBox(false);
			board[x][y - 1].set_hasBox(true);
		}
		if (e.getKeyCode() == KeyEvent.VK_DOWN) {
			board[x][y + 2].set_hasBox(false);
			board[x][y + 1].set_hasBox(true);
		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			board[x + 2][y].set_hasBox(false);
			board[x + 1][y].set_hasBox(true);
		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			board[x - 2][y].set_hasBox(false);
			board[x - 1][y].set_hasBox(true);
		}
		return board;
	}

	public Cell getPosition() {
		return board[x][y];
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}
}