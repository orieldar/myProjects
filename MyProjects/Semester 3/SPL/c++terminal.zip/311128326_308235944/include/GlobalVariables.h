//
// Created by orieldar on 20/11/17.
//
#ifndef GLOBALVARIABLES_H_
#define GLOBALVARIABLES_H_

extern unsigned int verbose;

// ... You may not change this file

#endif