


#ifndef FILESYSTEM_H_
#define FILESYSTEM_H_

#include "Files.h"


class FileSystem {
private:
   Directory* rootDirectory;
   Directory* workingDirectory;
   void clear(); // help fun. destructor
   void copy(const FileSystem& other); // help fun. copy cons.
	Directory* goPath (Directory* dest, vector<string> segments);


public:
   FileSystem();
   FileSystem(const FileSystem& other); //copy const
   FileSystem(FileSystem&& other); //move const
   FileSystem & operator=(const FileSystem& other); //3
   FileSystem & operator=(FileSystem&& other); //4
   virtual ~FileSystem(); //5
   Directory& getRootDirectory() const; // Return reference to the root directory
   Directory& getWorkingDirectory() const; // Return reference to the working directory
   void setWorkingDirectory(Directory *newWorkingDirectory); // Change the working directory of the file system void
   void setRootDirectory(Directory *newRootDirectory);
   void resetWorkingDirectory();
    Directory* getPathDir(string path);
	bool parentsCheck(string toChangePath,string workingPath);



};


#endif