//
// Created by orieldar on 18/11/17.
//
#include <iterator>
#include <sstream>
#include <map>
#include "GlobalVariables.h"
#include "Environment.h"
#include "Commands.h"

Environment:: Environment(): commandsHistory(), fs() {}//constructor

//////////////////////////////Rule of 5/////////////////////////////////

Environment:: Environment(const Environment& other):commandsHistory(), fs(other.fs) {//1 copy const
    if((verbose==1) | (verbose==3))
        cout<<"Environment:: Environment(const Environment& other)"<<endl;
    copyHistory(other);
}

Environment & Environment:: operator=(const Environment& other) { //2
    if((verbose==1) | (verbose==3))
        cout<<"Environment & Environment:: operator=(const Environment& other)"<<endl;
    if (this == &other)
        return *this;
    fs=other.fs;
    for (unsigned int i = 0; i < commandsHistory.size(); i++)
        delete commandsHistory[i];
    commandsHistory.clear();
    copyHistory(other);
    return *this;
}

Environment::~Environment() { //3
    if((verbose==1) | (verbose==3))
        cout<<"Environment::~Environment()"<<endl;
    for (unsigned int i=0; i<commandsHistory.size(); i++)
        delete commandsHistory[i];
}


Environment:: Environment(Environment&& other):commandsHistory(other.commandsHistory), fs(other.fs){ //4 move cons
    if((verbose==1) | (verbose==3))
        cout<<"Environment:: Environment(Environment&& other)"<<endl;
    other.commandsHistory.clear();
    other.fs.setWorkingDirectory(nullptr);
    other.fs.setRootDirectory(nullptr);
}

Environment & Environment:: operator=(Environment&& other) { //5
    if((verbose==1) | (verbose==3))
        cout<<"Environment & Environment:: operator=(Environment&& other)"<<endl;
    commandsHistory = other.commandsHistory;
    fs=other.fs;
    other.commandsHistory.clear();
    other.fs.setWorkingDirectory(nullptr);
    other.fs.setRootDirectory(nullptr);
    return *this;
}
/////////////////////////////////////////////////////////////////////////


void Environment:: copyHistory(const Environment& other){

    for (unsigned int i = 0; i < other.commandsHistory.size(); i++) {

        if (dynamic_cast<PwdCommand*>(other.commandsHistory[i])) {
            commandsHistory.push_back(new PwdCommand((PwdCommand&)(*other.commandsHistory[i])));
        }
        else if (dynamic_cast<CdCommand*>(other.commandsHistory[i])) {
            commandsHistory.push_back(new CdCommand((CdCommand&)(*other.commandsHistory[i])));
        }
        else if (dynamic_cast<LsCommand*>(other.commandsHistory[i])) {
            commandsHistory.push_back(new LsCommand((LsCommand&)(*other.commandsHistory[i])));
        }
        else if (dynamic_cast<MkdirCommand*>(other.commandsHistory[i])) {
            commandsHistory.push_back(new MkdirCommand((MkdirCommand&)(*other.commandsHistory[i])));

        }else if (dynamic_cast<MkfileCommand*>(other.commandsHistory[i])) {
            commandsHistory.push_back(new MkfileCommand((MkfileCommand&)(*other.commandsHistory[i])));

        }else if (dynamic_cast<CpCommand*>(other.commandsHistory[i])) {
            commandsHistory.push_back(new CpCommand((CpCommand&)(*other.commandsHistory[i])));

        }else if (dynamic_cast<MvCommand*>(other.commandsHistory[i])) {
            commandsHistory.push_back(new MvCommand((MvCommand&)(*other.commandsHistory[i])));

        }else if (dynamic_cast<RenameCommand*>(other.commandsHistory[i])) {
            commandsHistory.push_back(new RenameCommand((RenameCommand&)(*other.commandsHistory[i])));

        }else if (dynamic_cast<RmCommand*>(other.commandsHistory[i])) {
            commandsHistory.push_back(new RmCommand((RmCommand&)(*other.commandsHistory[i])));

        }else if (dynamic_cast<HistoryCommand*>(other.commandsHistory[i])) {
        commandsHistory.push_back(new HistoryCommand((*other.commandsHistory[i]).getArgs(), commandsHistory));

        }else if (dynamic_cast<ExecCommand*>(other.commandsHistory[i])) {
           commandsHistory.push_back(new ExecCommand((*other.commandsHistory[i]).getArgs(), commandsHistory));

        }else if (dynamic_cast<ErrorCommand*>(other.commandsHistory[i])) {
            commandsHistory.push_back(new ErrorCommand((ErrorCommand&)(*other.commandsHistory[i])));

        }
    }}

void Environment:: start(){
    string command;
    while(command != "exit"){
        if (&fs.getWorkingDirectory() == &fs.getRootDirectory())
            cout<<"/>";
        else
            cout<<fs.getWorkingDirectory().getAbsolutePath()+">";

        getline (cin, command);

        if((verbose==2) | (verbose==3)) {
            if (command != "exit")
                cout << command << endl;
        }


        int found = command.find_first_of(" ");
        string firstCommand(command);
        string restCommand("");

        if(found != -1){
            firstCommand = command.substr(0,found);
            restCommand = command.substr(found+1);
        }

        if (firstCommand=="pwd") {
            commandsHistory.push_back(new PwdCommand(restCommand));
            commandsHistory.back()->execute(fs);
        }
        else if (firstCommand=="cd") {
            commandsHistory.push_back(new CdCommand(restCommand));
            commandsHistory.back()->execute(fs);

        }
        else if (firstCommand=="ls") {
            commandsHistory.push_back(new LsCommand(restCommand));
            commandsHistory.back()->execute(fs);
        }
        else if (firstCommand=="mkdir") {
            //cout<<"restcommand:" + restCommand<<endl;
            commandsHistory.push_back(new MkdirCommand(restCommand));
            commandsHistory.back()->execute(fs);

        }else if (firstCommand=="mkfile") {
            commandsHistory.push_back(new MkfileCommand(restCommand));
            commandsHistory.back()->execute(fs);


        }else if (firstCommand=="cp") {
            commandsHistory.push_back(new CpCommand(restCommand));
            commandsHistory.back()->execute(fs);


        }else if (firstCommand=="mv") {
            commandsHistory.push_back(new MvCommand(restCommand));
            commandsHistory.back()->execute(fs);


        }else if (firstCommand=="rename") {
            commandsHistory.push_back(new RenameCommand(restCommand));
            commandsHistory.back()->execute(fs);


        }else if (firstCommand=="rm") {
            commandsHistory.push_back(new RmCommand(restCommand));
            commandsHistory.back()->execute(fs);


        }else if (firstCommand=="history") {
            commandsHistory.push_back(new HistoryCommand(restCommand,commandsHistory));
            commandsHistory.back()->execute(fs);

        }else if (firstCommand=="exec") {
            commandsHistory.push_back(new ExecCommand(restCommand,commandsHistory));
            commandsHistory.back()->execute(fs);

        }else if (firstCommand=="verbose") {
            commandsHistory.push_back(new VerboseCommand(restCommand));
            commandsHistory.back()->execute(fs);


        }else {
            if(command!="exit") {
                commandsHistory.push_back(new ErrorCommand(command));
                commandsHistory.back()->execute(fs);
            }
        }

    }
    
    //delete history commands

}

FileSystem& Environment:: getFileSystem()  {return fs;} // Get a reference to the file system

void Environment:: addToHistory(BaseCommand *command) {
    commandsHistory.push_back(command);
}//

const vector<BaseCommand*> & Environment:: getHistory() const{ return commandsHistory;}


;