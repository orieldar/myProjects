//
// Created by orieldar on 17/11/17.
//

#include <sstream>
#include "FileSystem.h"
#include "GlobalVariables.h"

FileSystem::FileSystem():rootDirectory(new Directory("/", nullptr)), workingDirectory(rootDirectory){}//constructor

////////////////////////////////Rule of 5//////////////////////////////////

FileSystem::FileSystem(const FileSystem& other):rootDirectory(new Directory(*other.rootDirectory)),workingDirectory(){//1
    if((verbose==1) | (verbose==3))
        cout<<"FileSystem::FileSystem(const FileSystem& other)"<<endl;
    workingDirectory = getPathDir(other.getWorkingDirectory().getAbsolutePath());
}


FileSystem& FileSystem::operator=(const FileSystem& other) {//2
    if((verbose==1) | (verbose==3))
        cout<<"FileSystem & FileSystem::operator=(const FileSystem& other)"<<endl;
    if (this == &other)
        return *this;
    delete rootDirectory;
    rootDirectory = new Directory(*other.rootDirectory);
    workingDirectory = getPathDir(other.getWorkingDirectory().getAbsolutePath());
    return *this;
}

FileSystem::~FileSystem() { //3
    if((verbose==1) | (verbose==3))
        cout<<"FileSystem::~FileSystem() "<<endl;
    delete rootDirectory;
    rootDirectory = nullptr;
    workingDirectory = nullptr;
}


FileSystem::FileSystem(FileSystem&& other): rootDirectory(other.rootDirectory), workingDirectory(other.workingDirectory){//4
    if((verbose==1) | (verbose==3))
        cout<<"FileSystem::FileSystem(FileSystem&& other)"<<endl;
    other.rootDirectory= nullptr;
    other.workingDirectory= nullptr;
}


FileSystem& FileSystem::operator=(FileSystem&& other) { //5
    if((verbose==1) | (verbose==3))
        cout<<"FileSystem & FileSystem::operator=(FileSystem&& other)"<<endl;
    delete rootDirectory;
    rootDirectory = other.rootDirectory;
    workingDirectory = other.workingDirectory;
    other.rootDirectory= nullptr;
    other.workingDirectory= nullptr;
    return *this;
}

//////////////////////////////////////////////////////////////////////////

Directory& FileSystem:: getRootDirectory() const{return *rootDirectory;} // Return reference to the root directory

Directory& FileSystem:: getWorkingDirectory() const{return *workingDirectory;} // Return reference to the working directory

void FileSystem:: setWorkingDirectory(Directory *newWorkingDirectory) {// Change the working directory of the
    workingDirectory = newWorkingDirectory;
}
void FileSystem::setRootDirectory(Directory *newRootDirectory){
    rootDirectory = newRootDirectory;
}

void FileSystem :: resetWorkingDirectory() {
    workingDirectory = rootDirectory;
}

Directory* FileSystem :: getPathDir(string path){
    std::string segment;
    std::string pathSub=path;
    std::vector<string> seglist;
    Directory* dest = workingDirectory;


    if(path.size()==0)
        return dest;


    if (path.at(0) == '/') //absolute path
    {
        if(path.size()==1)
            return rootDirectory;

        pathSub = pathSub.erase(0, 1);
        std::stringstream pathstream(pathSub);//pathstream of substring

        while (std::getline(pathstream, segment, '/')) {
            seglist.push_back(segment);
        }

        dest=rootDirectory;
        return (goPath(dest,seglist));


    }

    else{
        std::stringstream pathstream(path);
        while (std::getline(pathstream, segment, '/')) {
            seglist.push_back(segment);
        }

        dest=workingDirectory;
        return (goPath(dest,seglist));
    }

}


Directory* FileSystem :: goPath (Directory* dest, vector<string> segments) {
    if (segments.size() == 0) {

        return dest;
    }

    if (segments[0] == "..") { //check for ".."

        if (dest->getParent() == nullptr) {
            return nullptr;
        } else {
            dest = dest->getParent();
            segments.erase(segments.begin());
            return goPath(dest, segments);
        }
    }

    if (dest->isDirectory()){
        for (unsigned int i = 0; i < dest->getChildren().size(); i++) {


            if ((dest->getChildren()[i]->getName() == segments[0])) {
                dest = (Directory *) dest->getChildren()[i];

                segments.erase(segments.begin());
                return goPath(dest, segments);
            }

        }
    }

    return nullptr;
}

bool FileSystem::parentsCheck(string toChangePath,string workingPath) {
    if (workingPath == "")
        return false;
    if (toChangePath == workingPath)
        return true;
    return parentsCheck(toChangePath, workingPath.substr(0, workingPath.rfind('/')));
}



