//
// Created by tomer on 14/11/17.
//


#include "Files.h"
#include "GlobalVariables.h"

BaseFile::BaseFile(string name): name(name){}
bool BaseFile::isDirectory() {return false;}
string BaseFile::getName() const{
    return name;
}
void BaseFile::setName(string newName){
    name = newName;
}
File::File(string name, int size): BaseFile(name), size(size){}
int File::getSize() {
    return size;
}
Directory::Directory(string name, Directory* parent): BaseFile(name), children(), parent(parent) {}//constructor

////////////////////////////Rule of 5////////////////////////////////////////

Directory::Directory(const Directory& other): BaseFile(other.getName()), children(),parent(other.parent){//1
    if((verbose==1) | (verbose==3))
        cout<<"Directory::Directory(const Directory& other)"<<endl;
    copy(other);

}

Directory & Directory::operator=(const Directory& other){//2
    if((verbose==1) | (verbose==3))
        cout<<"Directory & Directory::operator=(const Directory& other)"<<endl;
    if (this == &other)
        return *this;
    clear();
    children.clear();
    setName(other.getName());
    parent = other.parent;
    copy(other);
    return *this;
}

Directory:: ~Directory(){//3
    if((verbose==1) | (verbose==3))
        cout<<"Directory:: ~Directory()"<<endl;
    clear();
    children.clear();
    //delete children;
}


Directory::Directory(Directory&& other) :BaseFile(other.getName()), children(other.children),parent(other.parent)//4
{      if((verbose==1) | (verbose==3))
        cout<<"Directory::Directory(Directory&& other) :BaseFile(other.getName())"<<endl;
    other.children.clear();
}
Directory & Directory::operator=(Directory&& other){//5
    if((verbose==1) | (verbose==3))
        cout<<"Directory & Directory::operator=(Directory&& other)"<<endl;
    if (this != &other){
        clear();
        setName(other.getName());
        setParent(other.getParent());
        children=other.children;
        other.children.clear();
    }
    return *this;
}

////////////////////////////////////////////////////////////////////////////////

Directory* Directory::getParent() const{ // Return a pointer to the parent of this directory
    return parent;
}
void Directory::setParent(Directory* newParent){ // Change the parent of this directory
    parent = newParent;
}
void Directory::addFile(BaseFile* file) { // Add the file to children
    if(file->isDirectory()) {
        ((Directory *) (file))->setParent(this);
        children.push_back((Directory *) file);
    }
    else children.push_back(file);
}

void Directory::removeFile(string name) { // Remove the file with the specified name from children

    for(vector<BaseFile*>::iterator iterator = children.begin();
        iterator != children.end(); ++iterator)
    {

        if(*iterator!= nullptr) {

            if ((**iterator).getName() == name) {
                delete *iterator;
                children.erase(iterator);
                break; //!!
            }
        }
    }
}
void Directory::removeFile(BaseFile* file) { // Remove the file from children
    for(vector<BaseFile*>::iterator iterator = children.begin(); iterator != children.end(); iterator++)
    {
        if((*iterator) == file){
            if(((BaseFile*)*iterator)->isDirectory())
                delete ((Directory*)*iterator);
            else
                delete ((File*)*iterator);

            children.erase(iterator);
            break; //!!
        }
    }
}

bool Directory:: myfunctionName (BaseFile* i,BaseFile* j) {
    return ((*i).getName()<(*j).getName());
}

bool Directory:: myfunctionSize (BaseFile* i,BaseFile* j) {
    if ((*i).getSize() == (*j).getSize())
        return ((*i).getName() < (*j).getName());
    return (*i).getSize()<(*j).getSize();
}


void Directory::sortByName() {// Sort children by name alphabetically (not recursively)

    sort(children.begin(), children.end(), myfunctionName);
}
void Directory::sortBySize(){ // Sort children by size (not recursively)

    sort(children.begin(), children.end(), myfunctionSize);
}
vector<BaseFile*> Directory::getChildren() {// Return children
    return children;
}
int Directory::getSize() { // Return the size of the directory (recursively)
    int sum =0;
    for(vector<BaseFile*>::iterator iterator = children.begin(); iterator != children.end(); iterator++)
        sum = sum + (**iterator).getSize();
    return sum;
}
string Directory::getAbsolutePath() { //Return the path from the root to this
    if(parent == nullptr)
        return "";
    else
        return (*parent).getAbsolutePath() + "/" + getName();
}

void Directory::clear(){
   for(vector<BaseFile*>::iterator iterator = children.begin(); iterator != children.end(); iterator++) {
       if(((BaseFile*)*iterator)->isDirectory())
           delete ((Directory*)*iterator);
       else
           delete ((File*)*iterator);
    }
}



void Directory::copy(const Directory& other) {

    for(unsigned int i=0; i<other.children.size(); i++){
        if ((other.children[i])->isDirectory()){
            children.push_back(new Directory((Directory&)(*(other.children[i]))));
        }
        else {
            children.push_back(new File((File&)(*(other.children[i]))));
        }
    }
}


bool Directory::isDirectory(){ return true; }



void Directory::toString() {
    for (vector<BaseFile *>::iterator iterator = children.begin(); iterator != children.end(); iterator++) {

        if((**iterator).isDirectory())
            cout<<"DIR\t" + (**iterator).getName() + "\t" + to_string((**iterator).getSize())<<endl;
        else
            cout<<"FILE\t" + (**iterator).getName() + "\t" +to_string((**iterator).getSize())<<endl;
    }
}

BaseFile* Directory::findByName(string name){
    if(name=="..") {
        return parent;
    }
    for(unsigned int i=0; i<children.size(); i++) {
        if (children[i]->getName() == name)
            return children[i];
    }
    return nullptr;
}
