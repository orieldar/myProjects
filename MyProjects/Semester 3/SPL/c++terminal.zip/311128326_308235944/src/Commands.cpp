//
// Created by orieldar on 17/11/17.
//
#include <sstream>
#include <iterator>
#include "Commands.h"
#include "GlobalVariables.h"

BaseCommand:: BaseCommand(string args):args(args){}

string BaseCommand:: getArgs() { return args;}



CdCommand:: CdCommand(string args) : BaseCommand(args){}

void CdCommand :: execute(FileSystem & fs){

    if(fs.getPathDir(getArgs())==nullptr)
        cout << "The system cannot find the path specified" << endl;
    else {
        fs.setWorkingDirectory(fs.getPathDir(getArgs()));
    }

}


string CdCommand:: toString(){ return "cd " + getArgs(); }

PwdCommand::PwdCommand(string args) : BaseCommand(args){};

void PwdCommand :: execute(FileSystem & fs){
    if (&fs.getWorkingDirectory() == &fs.getRootDirectory())
        cout<<"/"<<endl;
    else
        cout<<fs.getWorkingDirectory().getAbsolutePath()<<endl;
    ;

}


string PwdCommand:: toString(){return "pwd ";}



LsCommand::LsCommand(string args): BaseCommand(args){}
void LsCommand::execute(FileSystem & fs) {
    int sort = 0; // 0=sort by name. 1=sort by size
    string tmp(getArgs());

    if (tmp.substr(0, 2) == "-s") {
        sort = 1;
        tmp.erase(0, 3);
    }

    Directory* toPrint = fs.getPathDir(tmp);
    if(toPrint == nullptr)
        cout <<"The system cannot find the path specified"<<endl;
    else {
        if (sort == 0)
            (*toPrint).sortByName();
        else
            (*toPrint).sortBySize();
        (*toPrint).toString();
    }
}

string LsCommand::toString(){
    return "ls " + getArgs();
}

MkdirCommand::MkdirCommand(string args):BaseCommand(args){}

void MkdirCommand::execute(FileSystem & fs){
    if(fs.getPathDir(getArgs()) != nullptr) {
        cout << "The directory already exists" << endl;

    }

    else {
        string tmp = getArgs();
        if (tmp.front() == '/')
            make(&fs.getRootDirectory(), tmp.erase(0, 1));
        else
            make(&fs.getWorkingDirectory(), tmp);
    }
}
void MkdirCommand::make(Directory* startDir, string path) { //go to dir and make new ones

    int slashPos = path.find('/');
    if(slashPos!=-1){ // if there is a slash
        string name = path.substr(0, slashPos);
        if(name == "..") // go up
            make(startDir->getParent(), path.erase(0, slashPos+1));
        else{ // go forward
            BaseFile* foward = startDir->findByName(name);
            if((foward == nullptr)) { // not found, make new dir
                foward = new Directory(name, startDir);
                startDir->addFile(foward);
            }
            if(foward->isDirectory()) {

                make((Directory*)(foward), path.erase(0, slashPos + 1)); //go foward
            }
            else{//forward is file
                cout<<"The directory already exists"<<endl;
                return;
            }
        }
    }
    else // if there is not slash (last dir)
        startDir->addFile(new Directory(path, startDir));


}
string MkdirCommand::toString(){return "mkdir " + getArgs();}

MkfileCommand::MkfileCommand(string args): BaseCommand(args){}
void MkfileCommand::execute(FileSystem & fs){
    int spacePos1 = getArgs().find(' ');
    int spacePos2 = getArgs().rfind(' ');
    int slashPos = getArgs().rfind('/');
    string fileName(getArgs().substr(spacePos1+1, spacePos2-spacePos1-1));
    string filePath;
    if(spacePos1 == spacePos2) { // there is no path
        filePath = "";
        fileName = getArgs().substr(0, spacePos1);
    }
    else // there is a path with no slash
        filePath =  getArgs().substr(0, spacePos1);

    int fileSize(stoi(getArgs().substr(spacePos2)));
    if(slashPos!= -1) { //there is a slash
        fileName = getArgs().substr(slashPos + 1, (spacePos1 - slashPos) - 1);
        filePath = getArgs().substr(0, slashPos);
    }
    Directory *fileDir = fs.getPathDir(filePath);

    if(fileDir== nullptr)
        cout<<"The system cannot find the path specified"<<endl;
    else{
        BaseFile* check =fileDir->findByName(fileName);
        if((check != nullptr)) {
            if (check->isDirectory() == false)
                cout << "File already exists" << endl;
        }
        else
            fileDir->addFile(new File(fileName, fileSize));
    }
}
string MkfileCommand::toString(){
    return "mkfile " + getArgs();
}

RenameCommand::RenameCommand(string args): BaseCommand(args){}

void RenameCommand:: execute(FileSystem & fs) {

    istringstream buffer(getArgs());
    vector<string> split((istream_iterator<std::string>(buffer)), istream_iterator<std::string>());


    if (split.size() != 2) {
        cout << "No such file or directory" << endl;
        return;
    }

    if((split[0] =="..") & ((&fs.getWorkingDirectory())== &fs.getRootDirectory())){// type .. only from root
        cout << "No such file or directory" << endl;

        return;
    }

    if((fs.getPathDir(split[0]))==(&fs.getRootDirectory()) ){//check if rename root or working directory
        cout << "Can't rename the root directory" << endl;
        return;
    }

    if(fs.getPathDir(split[0])==&fs.getWorkingDirectory()){//check if rename root or working directory
        cout << "Can't rename the working directory" << endl;
        return;
    }

    int found = split[0].find_last_of("/");
    string parentpath("");
    string lastBaseFile = split[0];


    if (found != -1) {//found slash
        parentpath = split[0].substr(0, found);
        lastBaseFile = split[0].substr(found+1);//last basefile without slash

        if(parentpath=="")
            parentpath="/";

    }

    Directory *parent = fs.getPathDir(parentpath);

    if (parent == nullptr) {
        cout << "No such file or directory" << endl;
        return;
    }

    BaseFile *last = parent->findByName(lastBaseFile);

    if(parent->findByName(split[1])!= nullptr)//already file with name
        return;

    if (last == nullptr) {
        cout << "No such file or directory" << endl;
        return;
    }
    else {
        last->setName(split[1]);
        return;
    }

}

string RenameCommand:: toString(){return "rename " + getArgs();}



ErrorCommand:: ErrorCommand(string args):BaseCommand(args){}
void ErrorCommand:: execute(FileSystem & fs){
    cout<< getArgs().substr(0, getArgs().find(' ')) + ": Unknown command"<<endl;
}
string  ErrorCommand:: toString() {return getArgs();}

ExecCommand :: ExecCommand(string args, const vector<BaseCommand *> & history): BaseCommand(args), history(history){}
void ExecCommand:: execute(FileSystem & fs){
    if (((unsigned)stoi(getArgs())) >= (unsigned)(history.size()-1)){
        cout << "Command not found" << endl;
        return;
    }
    else {
        history[stoi(getArgs())]->execute(fs);

    }

}
string ExecCommand:: toString(){return "exec " + getArgs();}

CpCommand::CpCommand(string args):BaseCommand(args){}

void CpCommand::execute(FileSystem & fs){
    int spacePos = getArgs().find(' ');
    int slashPos = (getArgs().substr(0, spacePos - 1)).rfind('/');
    string filePath("");
    string desPath(getArgs().substr(spacePos + 1));
    string fileName = getArgs().substr(0, spacePos);
    Directory *fileDir;
    Directory *desDir;
    BaseFile *toCopy;
    bool isRoot=false;

    if((fileName==".." )&( (&fs.getWorkingDirectory()== &fs.getRootDirectory()))){// type .. only from root
        cout << "No such file or directory" << endl;

        return;
    }

    if((desPath=="..") & ((&fs.getWorkingDirectory()== &fs.getRootDirectory()))){// type .. only from root
        cout << "No such file or directory" << endl;

        return;
    }


    if(((fs.getPathDir(fileName))==(&fs.getRootDirectory() )))//check if root
          isRoot=true;

    if (slashPos != -1) {
        filePath = getArgs().substr(0, slashPos);
        fileName = getArgs().substr(slashPos + 1, spacePos - slashPos - 1);

        if (filePath=="")
            filePath="/";
    }


    fileDir = fs.getPathDir(filePath);
    desDir = fs.getPathDir(desPath);

    if (desDir == nullptr) {
        cout << "No such file or directory" << endl;
        return;
    }

    if ((fileDir== nullptr) & (isRoot==false)) {
        cout << "No such file or directory" << endl;
        return;
    }

    toCopy = fileDir->findByName(fileName);


    if ((toCopy == nullptr)) {
        cout << "No such file or directory" << endl;
        return;
    }


    if (desDir->findByName(toCopy->getName()) == nullptr) { //everything ok

        if(toCopy->isDirectory()) {
            Directory *dir = new Directory((Directory &) (*toCopy));
            desDir->addFile(dir);
        }
        else{
            File* file = new File((File&) (*toCopy));
            desDir->addFile(file);
        }
    }
}


string CpCommand::toString(){ return "cp " + getArgs();}

MvCommand::MvCommand(string args): BaseCommand(args){}
void MvCommand::execute(FileSystem & fs) {
    int spacePos = getArgs().find(' ');
    int slashPos = (getArgs().substr(0, spacePos - 1)).rfind('/');
    string filePath("");
    string desPath(getArgs().substr(spacePos + 1));
    string fileName = getArgs().substr(0, spacePos);
    Directory *fileDir;
    Directory *desDir;
    BaseFile *toMove;

    if((fileName=="..") & ((&fs.getWorkingDirectory())== &fs.getRootDirectory())){// type .. only from root
        cout << "No such file or directory" << endl;
        return;
    }

    if(fs.getPathDir(fileName)==&fs.getRootDirectory() ){//check if rename root or working directory
        cout << "Can't move directory" << endl;
        return;
    }

    if(fs.getPathDir(fileName)==&fs.getWorkingDirectory()){//check if rename root or working directory
        cout << "Can't move directory" << endl;
        return;
    }


    if (slashPos != -1) {
        filePath = getArgs().substr(0, slashPos);
        fileName = getArgs().substr(slashPos + 1, spacePos - slashPos - 1);

        if (filePath=="")
            filePath="/";
    }

    fileDir = fs.getPathDir(filePath);
    desDir = fs.getPathDir(desPath);

    if ((fileDir == nullptr) | (desDir == nullptr)) {
        cout << "No such file or directory" << endl;
        return;
    }



   // if (fileDir!= nullptr) {
       // if (fileName == "..") {
    //    toMove = fileDir->getParent();
    //    fileDir = fileDir->getParent()->getParent();
    // } else
    toMove = fileDir->findByName(fileName);
    //}



    if(toMove == &(fs.getRootDirectory())) {
        cout << "Can't move directory" << endl;
        return;
    }


    if ( (toMove == nullptr)) {
        cout << "No such file or directory" << endl;
        return;
    }

    if (toMove->isDirectory()) {
        if (fs.parentsCheck(((Directory *) (toMove))->getAbsolutePath(),
                            fs.getWorkingDirectory().getAbsolutePath())) {
            cout << "Can't move directory" << endl;
            return;
        }
    }
    //cout << "-------------------------" << endl;
    //cout << toMove->getName() << endl;
    if (desDir->findByName(toMove->getName()) == nullptr) { //everything ok
       // cout << "flag" << endl;
        if(toMove->isDirectory()) {
            Directory *dir = new Directory((Directory &) (*toMove));
            desDir->addFile(dir);
            fileDir->removeFile(toMove);
        }
        else{
            File* file = new File((File&) (*toMove));
            desDir->addFile(file);
            fileDir->removeFile(toMove);

        }
    }
}


string MvCommand::toString(){
    return "mv " + getArgs();
}

RmCommand::RmCommand(string args): BaseCommand(args){}

void RmCommand::execute(FileSystem & fs) {
    int slashPos(getArgs().rfind('/'));
    string fileName(getArgs());
    string filePath("");
    BaseFile *toRemove;
    Directory *fileDir;

    if(fs.getPathDir(fileName)==&fs.getRootDirectory() ){//check if rename root or working directory
        cout << "Can't remove directory" << endl;
        return;
    }

    if(fs.getPathDir(fileName)==&fs.getWorkingDirectory()){//check if rename root or working directory
        cout << "Can't remove directory" << endl;
        return;
    }

    if((fileName==".." )& ((&fs.getWorkingDirectory()== &fs.getRootDirectory()))){// type .. only from root
        cout << "No such file or directory" << endl;
        //cout<<"flag"<<endl;
        return;
    }

    if (slashPos != -1) {
        fileName = getArgs().substr(slashPos + 1);
        filePath = getArgs().substr(0, slashPos);


        if ((filePath == "") & (fileName == "")) {//rootdirectory
            cout << "Can't remove directory" << endl;
            return;
        }


        if (filePath == "")
            filePath = "/";

    }
    //cout << "name to remove:" + fileName << endl;
    //cout << "path to remove:" + filePath << endl;

    fileDir = fs.getPathDir(filePath);

    if (fileDir == nullptr) {
        cout << "No such file or directory" << endl;
        return;
    }


     //   if (fileName == "..") {
     //      toRemove = fileDir->getParent();
     //      fileDir = fileDir->getParent()->getParent();
     //  } else
    toRemove = fileDir->findByName(fileName);

    if(toRemove == &(fs.getRootDirectory())) {
        cout << "Can't remove directory" << endl;
        return;
    }
    if (toRemove == nullptr) {
        cout << "No such file or directory" << endl;
        return;
    }
    if (toRemove->isDirectory()) {
        if (fs.parentsCheck(((Directory *) (toRemove))->getAbsolutePath(),
                            fs.getWorkingDirectory().getAbsolutePath())) {
            cout << "Can't remove directory" << endl;
            return;
        }
    }
    //cout << "toremove:" + toRemove->getName() + "  " << endl;
    //cout << "desdir:" + fileDir->getName() + "  " + fileDir->getAbsolutePath() << endl;
    fileDir->removeFile(toRemove);
}

string RmCommand::toString(){return "rm " + getArgs();}

HistoryCommand::HistoryCommand(string args, const vector<BaseCommand*> & history):BaseCommand(args), history(history){}
void HistoryCommand::execute(FileSystem & fs){
    for(unsigned int i=0; i<(history.size()-1); i++) {
        cout << to_string(i) + "\t" + history[i]->toString() << endl;
    }
}

string HistoryCommand::toString(){return "history " ;}

VerboseCommand ::VerboseCommand(string args):BaseCommand(args){}
void VerboseCommand:: execute(FileSystem & fs){
    int v =stoi(getArgs());
    if((v<0 )| (v>3))
        cout<<"Wrong verbose input"<<endl;
    else
        verbose=v;

}
string VerboseCommand:: toString(){return ("verbose " + getArgs());}

;