#include "Environment.h"

// ... You may not change this file

unsigned int verbose = 0;

int main(int , char **) {
    Environment env;
    env.start();
    return 0;
}