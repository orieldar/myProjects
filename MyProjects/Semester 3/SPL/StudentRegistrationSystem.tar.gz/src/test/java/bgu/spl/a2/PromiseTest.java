package bgu.spl.a2;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import junit.framework.Assert;

public class PromiseTest {
	Promise<Object> s;
	Integer check;

	@Before
	public void setUp() throws Exception {
		s = new Promise<Object>();
		check = new Integer(0);
	}

	@After
	public void tearDown() throws Exception {
		
	}

	@Test
	public void testGet()  {
		try{
			Object tmp = s.get();
			Assert.fail();
		}
		catch(IllegalStateException ex){
			Integer tmp2 = new Integer(0);
			s.resolve(tmp2);
			Assert.assertEquals(s.get(), tmp2);
		}
		catch(Exception ex){
			Assert.fail();
		}
		}
	@Test
	public void testIsResolved()  {
		try{
			if(s.isResolved())
				Assert.fail();
			s.resolve(check);
			Assert.assertTrue(s.isResolved());
			}
		catch(Exception ex){
			Assert.fail();
		}
	}
	@Test
	public void testResolve()  {
		try{
			s.subscribe(() -> {check++;});
			s.subscribe(() -> {check++;});
			s.subscribe(() -> {check++;});
			s.subscribe(() -> {check++;});
			s.resolve(check);
			s.resolve(new Object());
			Assert.fail();	
		}
		catch(IllegalStateException ex){
			Assert.assertTrue(check==4);
		}
		catch(Exception ex){
			Assert.fail();
		}
		}
	public void testSubscribe() {
		try{
			s.subscribe(() -> {check=10;});
			s.resolve(check);
			Assert.assertTrue(check==10);
		}
		catch(Exception ex){
			Assert.fail();
		}
	}
}
