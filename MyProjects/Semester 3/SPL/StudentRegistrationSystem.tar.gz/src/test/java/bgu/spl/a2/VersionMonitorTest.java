package bgu.spl.a2;

import static org.junit.Assert.*;

import org.junit.Test;

import junit.framework.Assert;

public class VersionMonitorTest {

	@Test
	public void testGetVersion() {
		try{
			VersionMonitor ver = new VersionMonitor();
			Assert.assertTrue(ver.getVersion()>=0);
		}
		catch(NullPointerException ex){
			Assert.fail();
		}
		catch (Exception ex){
			Assert.fail();
		}
		
	}
	@Test
	public void testInc() {
		try{
			VersionMonitor ver = new VersionMonitor();
			int tmp = ver.getVersion();
			ver.inc();
			Assert.assertEquals(tmp+1, ver.getVersion());
			}
		catch (Exception ex){
			Assert.fail();
		}	
	}
	@Test
	public void testAwait() {
		try{
			VersionMonitor ver = new VersionMonitor();
			Thread t1 = new Thread(() -> {
				
				try {ver.await(0);} 
				catch (Exception ex){}
				try {ver.inc();} 
				catch (Exception ex){}
				
				
			});
			Thread t2 = new Thread(() -> {
				try{ver.inc();}
				catch (Exception ex){}
			});
			t1.start();
			t2.start();
			Assert.assertEquals(ver.getVersion(), 2);
			}
		catch (Exception ex){
			Assert.fail();
		}	
	}

}
