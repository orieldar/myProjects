package bgu.spl.a2.sim;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import bgu.spl.a2.Promise;
import bgu.spl.a2.VersionMonitor;
import bgu.spl.a2.callback;

/**
 * represents a warehouse that holds a finite amount of computers
 *  and their suspended mutexes.
 * 
 */
public class Warehouse {
	
	private Map<Computer, SuspendingMutex> computersMutex;
	
	/**
	 * creates a {@link Warehouse} which holds the computers and their
	 * suspending mutex.
	 * 
	 * @param computers the given computer list to insert into the warehouse
	 */
	public Warehouse(List<Computer> computers){
		computersMutex = new ConcurrentHashMap<Computer,SuspendingMutex>();
		for(Computer computer : computers)
			computersMutex.put(computer, new SuspendingMutex(computer));
	}
	
	/**
	 * trys to aquire a computer from the warehouse,
	 * returns a {@link Promise} which holds resembels the relevent computer,
	 * returns null if not found
	 * 
	 * @param computerType the computer wanted
	 * 
	 * @return the computer promise
	 */
	public Promise<Computer> aquire(String computerType){
		Set<Computer> computers = computersMutex.keySet();
		for(Computer computer : computers){
			if(computer.getType().equals(computerType))
				return computersMutex.get(computer).down();
		}
		return null;
	}
	
	/**
	 * releases a computer from the warehouse,
	 * 
	 * @param computerType  the computer wanted to release
	 */
	public void release(String computerType){
		Set<Computer> computers = computersMutex.keySet();
		for(Computer computer : computers){
			if(computer.getType().equals(computerType))
				computersMutex.get(computer).up();
		}
	}
}
