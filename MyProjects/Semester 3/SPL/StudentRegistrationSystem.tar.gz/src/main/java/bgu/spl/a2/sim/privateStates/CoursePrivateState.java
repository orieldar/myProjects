package bgu.spl.a2.sim.privateStates;

import java.util.LinkedList;
import java.util.List;

import bgu.spl.a2.PrivateState;

/**
 * this class describe course's private state
 */
public class CoursePrivateState extends PrivateState{

	private Integer availableSpots;
	private Integer registered;
	private List<String> regStudents;
	private List<String> prequisites;
	
	/**
 	 * Implementors note: you may not add other constructors to this class nor
	 * you allowed to add any other parameter to this constructor - changing
	 * this may cause automatic tests to fail..
	 */
	public CoursePrivateState() {
		this.availableSpots = new Integer(0);
		this.registered = new Integer(0);
		this.regStudents = new LinkedList<String>();
		this.prequisites = new LinkedList<String>();
	}
	/**
	 * getter for the available spots,
	 *
	 * @return the availabe spots in the course
	 *            
	 */
	public Integer getAvailableSpots() {
		return availableSpots;
	}
	/**
	 * getter for number of registered students,
	 *
	 * @return the number of registered students
	 *            
	 */
	public Integer getRegistered() {
		return registered;
	}

	/**
	 * getter for the list of registered students,
	 *
	 * @return the registered students list
	 *            
	 */
	public List<String> getRegStudents() {
		return regStudents;
	}
	/**
	 * getter for the list of prequisites,
	 *
	 * @return the prequisites list
	 *            
	 */
	public List<String> getPrequisites() {
		return prequisites;
	}
	/**
	 * setter for available spots
	 *
	 * @param the new available spots
	 *            
	 */
	public void setAvailableSpots(int availbleSpots) {
		availableSpots = availbleSpots;
	}
	
	/**
	 * adds spots to the available spots
	 *
	 * @param spotsToAdd the number of spots to add
	 *            
	 */
	public void addAvailableSpots(int spotsToAdd){
		availableSpots = availableSpots + spotsToAdd;
	}
	/**
	 * adds a student to the courses student list
	 *
	 * @param studentId the student to add
	 *            
	 */
	public void addStudent(String studentId) {
		if(!regStudents.contains(studentId)){
			regStudents.add(studentId);
			registered++;
			availableSpots--;
		}
	}
	/**
	 * removes a student to the courses student list
	 *
	 * @param studentId the student to remove
	 * @return if student has been removed or not          
	 */
	public boolean removeStudent(String studentId) {
		if(regStudents.remove(studentId)){
			registered--;
			return true;
		}
		else
			return false;
	}
	
	/**
	 * sets the prequisites list
	 *
	 * @param prequisites the new prewuisites list
	 *            
	 */
	public void setPrequisites(List<String> prequisites) {
		this.prequisites = prequisites;
	}
	
}