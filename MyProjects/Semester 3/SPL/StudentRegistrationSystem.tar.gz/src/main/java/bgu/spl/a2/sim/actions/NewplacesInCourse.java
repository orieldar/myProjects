package bgu.spl.a2.sim.actions;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import bgu.spl.a2.Action;
import bgu.spl.a2.Promise;
import bgu.spl.a2.sim.privateStates.CoursePrivateState;
import bgu.spl.a2.sim.privateStates.DepartmentPrivateState;
/**
 * {@link CloseACourse}   This action increases the number of available spaces in a course
 * 
 */
public class NewplacesInCourse extends Action<Boolean>{
	

	@SerializedName("Course")
	@Expose
	private	String courseId;
	@SerializedName("Number")
	@Expose
	private	Integer newPlaces;
	
	/**
	 *no args constructor 
	 * 
	 */
	
	public NewplacesInCourse(){
		actionName = "Add Spaces";
		result=new Promise<Boolean>();
	}
	
	/**
	 *constructor
	 *@param newPlaces the number of places to add
	 * 
	 */
	public NewplacesInCourse(String newPlaces){
		actionName = "Add Spaces";
		this.newPlaces = Integer.parseInt(newPlaces);
		result=new Promise<Boolean>();
	}

	/**
	 * start handling the action - and add action to the log,
	 * adds the available spots
	 */
	@Override
	protected void start() {
		actorState.addRecord(getActionName());//add action to log
		((CoursePrivateState) actorState).addAvailableSpots(newPlaces);
		complete(true);
	}
	/**
	 * sets the actor id after the serialization, and returns it , 
	 * 
	 * @return the actors id
	 */
	public String setAndGetActorId(){
		actorId=courseId;
		return actorId;
		}
}
