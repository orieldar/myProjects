package bgu.spl.a2.sim.privateStates;

import java.util.LinkedList;
import java.util.List;

import bgu.spl.a2.PrivateState;

/**
 * this class describe department's private state
 */
public class DepartmentPrivateState extends PrivateState{
	private List<String> courseList;
	private List<String> studentList;
	/**
	 * no args constructor
	 *            
	 */
	public DepartmentPrivateState() {
		courseList = new LinkedList<String>();
		studentList = new LinkedList<String>();
	}
	/**
	 * adds a course to the department courses list
	 *
	 * @param courseId the course to add
	 *            
	 */
	public void addCourse(String courseId){
		courseList.add(courseId);
	}
	/**
	 * adds a student to the department student list
	 *
	 * @param srudentId the student to add
	 *            
	 */
	public void addStudent(String studentId){
		studentList.add(studentId);
		
	}
	/**
	 * getter for the list of registered students,
	 *
	 * @return the registered students list
	 *            
	 */
	public List<String> getStudentList() {
		return studentList;
	}
	/**
	 * getter for the list of courses,
	 *
	 * @return the departments courses list
	 *            
	 */
	public List<String> getCourseList() {
		return courseList;
	}
	
}
