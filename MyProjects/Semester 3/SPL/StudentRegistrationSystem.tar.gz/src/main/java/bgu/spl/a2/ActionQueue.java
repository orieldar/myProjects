package bgu.spl.a2;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;
/**
 * a class that extends @link ConcurrentLinkedQueue 
 * and holds the Actor's actions
 *
 */
public class ActionQueue extends ConcurrentLinkedQueue<Action> {
	
	private Semaphore semaphore;
	
	/**
	 * Constructor that starts a semaphore,
	 * that is used to permit only one thread 
	 * to enter the Action queue
	 */
	public ActionQueue(){
		super();
		semaphore = new Semaphore(1);
	}
	
	 /**
     * @return ActionQueue's semaphore 
     */
	public Semaphore getSemaphore(){
		return semaphore;
	}

}
