package bgu.spl.a2.sim.actions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import bgu.spl.a2.Action;
import bgu.spl.a2.Promise;
import bgu.spl.a2.sim.Computer;
import bgu.spl.a2.sim.Warehouse;
import bgu.spl.a2.sim.privateStates.CoursePrivateState;
import bgu.spl.a2.sim.privateStates.StudentPrivateState;


/**
 * {@link CheckAdministrativeObligations}   allocates one of the computers available in the warehouse,
 *and checks for each student if he meets some administrative obligations. The computer generates
 *a signature and saves it in the students private state
 * 
 */
public class CheckAdministrativeObligations extends Action<Boolean>{
	

	@SerializedName("Department")
	@Expose
	private String departmentId;
	@SerializedName("Computer")
	@Expose
	private String computerName;
	@SerializedName("Students")
	@Expose
	private List<String> students;
	@SerializedName("Conditions")
	@Expose
	private List<String> courses;
	
	private Warehouse warehouse;
	private Promise<Computer> computer;

	
	/**
	 *no args constructor that creates a {@CheckAdminstrativeObligations }
	 * 
	 */
	public CheckAdministrativeObligations(){
		actionName = "Administrative Check";
		result=new Promise<Boolean>();
	}
	
	/**
	 * constructor that creates a {@CheckAdminstrativeObligations }
	 * 
	 * @param warehouse the warehouse to get the computer from
	 * @param computerName the computers name
	 * @param the students to check
	 * @param the courses to check
	 * 
	 */
	public CheckAdministrativeObligations(Warehouse warehouse, String computerName, List<String> students, List<String> courses){
		actionName = "Administrative Check";
		result=new Promise<Boolean>();
		this.warehouse = warehouse;
		this.computerName = computerName;
		this.students = students;
		this.courses = courses;
	}
	
	/**
     * start handling the action - and add the action to the log,
     * aquire the computer, check the obligations and sign the relevant
     * signature
     * 
     * note - releases the acomputer after its use
     */
	protected void start() {
		actorState.addRecord(getActionName());
		computer = warehouse.aquire(computerName);
		computer.subscribe(()->
		{
		List<Action<Boolean>> actions = new LinkedList<Action<Boolean>>();
		for(String student : students){
			StudentPrivateState studentPrivateState = (StudentPrivateState) pool.getPrivateState(student);
			CheckAndSign coursesGrades = new CheckAndSign(computer.get(), courses);
			sendMessage(coursesGrades, student, studentPrivateState);
			actions.add(coursesGrades);
		}
		then(actions, ()-> 
		{
			warehouse.release(computerName);
			complete(true);
			});
		});
	}
	
	/**
	 * sets the actor id after the serialization, and returns it , 
	 * sets the warehouse as well
	 * 
	 * @param warehouse the warehouse to use
	 * 
	 * @return the actors id
	 */
	public String setAndGetActorId(Warehouse warehouse){
		this.warehouse = warehouse;
		actorId=departmentId;
		return actorId;
		}
	
}
