package bgu.spl.a2.sim.privateStates;

import java.util.HashMap;

import bgu.spl.a2.PrivateState;

/**
 * this class describe student private state
 */
public class StudentPrivateState extends PrivateState{

	private HashMap<String, Integer> grades;
	private long signature;
	
	/**
 	 * Implementors note: you may not add other constructors to this class nor
	 * you allowed to add any other parameter to this constructor - changing
	 * this may cause automatic tests to fail..
	 * 
	 * no args constructor
	 */
	
	public StudentPrivateState() {
	 grades = new HashMap<String, Integer>();
	}
	
	/**
	 * getter for the grades
	 * @return the courses and grades hashmap          
	 */
	public HashMap<String, Integer> getGrades() {
		return grades;
	}
	/**
	 * getter for students signature,
	 * @return the students signature         
	 */
	public long getSignature() {
		return signature;
	}
	/**
	 * setter for students signature,
	 * @param signature the students signature         
	 */
	public void setSignature(long signature) {
		this.signature = signature;
	}
	/**
	 * adds a course to students courses hashmap and its grade
	 *
	 * @param courseName the courses id
	 * @param courseGrade the students course grade
	 *            
	 */
	public void addCourse(String courseName, Integer courseGrade){
		grades.put(courseName, courseGrade);
	}
	
	/**
	 * removes a course to students courses hashmap and its grade
	 *
	 * @param courseName the courses id to remove
	 *            
	 */
	public void removeCourse(String courseName){
		 grades.remove(courseName);
	}
}
