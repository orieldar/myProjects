package bgu.spl.a2.sim.actions;

import java.util.List;

import bgu.spl.a2.Action;
import bgu.spl.a2.Promise;
import bgu.spl.a2.sim.Warehouse;
import bgu.spl.a2.sim.privateStates.CoursePrivateState;
import bgu.spl.a2.sim.privateStates.DepartmentPrivateState;
import bgu.spl.a2.sim.privateStates.StudentPrivateState;

/**
 * An inner action, that
 * adds a course and its grade too the student's grade list
 * 
 */

public class AddCourseToGradeList extends Action<Boolean>{
	
	private	String courseId;
	private Integer courseGrade;
	
	
	/**
	 * constructor that creates a {@link AddCourseToGradeList} 
	 * 
	 * @param courseId the course to add
	 * @param courseGrade the grade to add
	 */
	public AddCourseToGradeList(String courseId, Integer courseGrade){
		actionName ="Add Course To Grade List";
		this.courseId = courseId;
		this.courseGrade = courseGrade;
		result=new Promise<Boolean>();
	}
	
	/**
     * start handling the action - adds the course to the students list
     */
	@Override
	protected void start() {
		((StudentPrivateState)(actorState)).addCourse(courseId, courseGrade);
		complete(true);
	}
	

}

