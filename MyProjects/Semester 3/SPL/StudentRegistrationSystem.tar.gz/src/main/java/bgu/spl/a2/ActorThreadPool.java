package bgu.spl.a2;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import javafx.util.Pair;


/**
 * represents an actor thread pool - to understand what this class does please
 * refer to your assignment.
 *
 * Note for implementors: you may add methods and synchronize any of the
 * existing methods in this class *BUT* you must be able to explain why the
 * synchronization is needed. In addition, the methods you add can only be
 * private, protected or package protected - in other words, no new public
 * methods
 */
public class ActorThreadPool {
	
	private ConcurrentHashMap<String, Pair<PrivateState, ActionQueue>> actors;
	private VersionMonitor poolVersion;
	private Boolean active;
	private Thread[] threads;
	/**
	 * creates a {@link ActorThreadPool} which has nthreads. Note, threads
	 * should not get started until calling to the {@link #start()} method.
	 *
	 * Implementors note: you may not add other constructors to this class nor
	 * you allowed to add any other parameter to this constructor - changing
	 * this may cause automatic tests to fail..
	 *
	 * @param nthreads
	 *            the number of threads that should be started by this thread
	 *            pool
	 */
	public ActorThreadPool(int nthreads) {
		actors = new ConcurrentHashMap<String, Pair<PrivateState, ActionQueue>>();
		poolVersion = new VersionMonitor();
		active = false;
		threads = new Thread[nthreads];
		for(int i=0; i < nthreads; i++){
			threads[i] = new Thread(()->
			{
				while(active){ //!!!!!
					int startVersion = poolVersion.getVersion();
					for(String actorId : actors.keySet()){
						Pair<PrivateState, ActionQueue> actor = actors.get(actorId);
						if((actor.getValue()).getSemaphore().tryAcquire()){
							if(!actor.getValue().isEmpty()){
								Action action = actor.getValue().poll();
								action.handle(this, actorId, actor.getKey());
								poolVersion.inc();
							}
							(actor.getValue()).getSemaphore().release();
						}
					}
					try {
						poolVersion.await(startVersion);
					} catch (InterruptedException ignored) {}
				}
				
			
				
			});
		}
	}

	/**
	 * getter for actors
	 * @return actors
	 */
	public Map<String, PrivateState> getActors(){
		HashMap<String, PrivateState> actorsNew = new HashMap<String, PrivateState>();
		for(String actorId : actors.keySet()){
			actorsNew.put(actorId, actors.get(actorId).getKey());
		}
		return actorsNew;
	}
	
	/**
	 * getter for actor's ActionQueue
	 * @return ActionQueue
	 */
	private ActionQueue getActorQueue(String actorId){
		return actors.get(actorId).getValue();
	}
	
	/**
	 * getter for actor's private state
	 * @param actorId actor's id
	 * @return actor's private state
	 */
	public PrivateState getPrivateState(String actorId){
		if(actors.get(actorId)!=null)
			return actors.get(actorId).getKey();
		return null;
	}


	/**
	 * submits an action into an actor to be executed by a thread belongs to
	 * this thread pool
	 *
	 * @param action
	 *            the action to execute
	 * @param actorId
	 *            corresponding actor's id
	 * @param actorState
	 *            actor's private state (actor's information)
	 */
	public void submit(Action<?> action, String actorId, PrivateState actorState) { 
		boolean found = false;
		for(String actorName : actors.keySet())
			if(actorName.equals(actorId)){
				found=true;
				break;
			}
		if(found==false)
			addActor(actorId, actorState);
		(actors.get(actorId)).getValue().add(action);
		
		
		poolVersion.inc();
	}

	/**
	 * closes the thread pool - this method interrupts all the threads and waits
	 * for them to stop - it is returns *only* when there are no live threads in
	 * the queue.
	 *
	 * after calling this method - one should not use the queue anymore.
	 *
	 * @throws InterruptedException
	 *             if the thread that shut down the threads is interrupted
	 */
	public void shutdown() throws InterruptedException {
		active = false;
		poolVersion.inc();
	}

	/**
	 * start the threads belongs to this thread pool
	 */
	public void start() {
		active = true;
		for(int i =0; i < threads.length; i++){
			threads[i].start();
		}
	}
	
	/**
	 * adds an actor to the actor thread Pool
	 * 
	 *
	 * @param actorId
	 *            the new actor's id
	 * @param actorState
	 *            the new actor's private state (actor's information)
	 */
	private void addActor(String actorId, PrivateState actorState){ 
		Pair<PrivateState, ActionQueue> actor = new Pair(actorState, new ActionQueue());
		actors.put(actorId, actor);
	}
	
// can be deleted?
	private void updateActorState(String actorId, PrivateState newActorState){
		ActionQueue actorQueue = getActorQueue(actorId);
		actors.remove(actorId);
		Pair<PrivateState, ActionQueue> actorNew = new Pair(newActorState, actorQueue);
		actors.put(actorId, actorNew);
	}
}
