package bgu.spl.a2.sim.actions;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import bgu.spl.a2.Action;
import bgu.spl.a2.Promise;
import bgu.spl.a2.sim.privateStates.CoursePrivateState;
import bgu.spl.a2.sim.privateStates.DepartmentPrivateState;
import bgu.spl.a2.sim.privateStates.StudentPrivateState;

/**
 * {@link CloseACourse}   This action closes a course, unregisters all the registered students in the
 * course and removes the course from the department courses' list and from the grade sheets of the
 * students. The number of available spaces of the closed course is updated to -1.
 * After closing the course, all the request for registration are denied.
 * 
 */
public class CloseACourse extends Action<Boolean>{
	
	@SerializedName("Department")
	@Expose
	private String departmentid;
	@SerializedName("Course")
	@Expose
	private	String courseId;
	private CoursePrivateState coursePrivateState;
	
	
	/**
	 *no args constructor 
	 * 
	 */
	public CloseACourse(){
		actionName = "Close Course";
		result=new Promise<Boolean>();
		
	}
	
	/**
	 *constructor 
	 *@param courseId the courses id 
	 */
	public CloseACourse(String courseId){
		actionName = "Close Course";
		this.courseId = courseId;
	}
	/**
     * start handling the action - and add action to the log,
     * removes the course from the departments course list and
     * and creates an {@link UnRegisterAllStudents} action to unregister 
     * all the registered students
     */
	@Override
	protected void start() {
		actorState.addRecord(getActionName());
		this.coursePrivateState = (CoursePrivateState) pool.getPrivateState(courseId);
		((DepartmentPrivateState) actorState).getCourseList().remove(courseId);
		UnRegisterAllStudents unRegisterAllStudents = new UnRegisterAllStudents();
		sendMessage(unRegisterAllStudents, courseId, coursePrivateState).subscribe(()-> {complete(true);}); 
	}
	
	/**
	 * sets the actor id after the serialization, and returns it , 
	 * 
	 * @return the actors id
	 */
	public String setAndGetActorId(){
		actorId=departmentid;
		return actorId;
		}
}
