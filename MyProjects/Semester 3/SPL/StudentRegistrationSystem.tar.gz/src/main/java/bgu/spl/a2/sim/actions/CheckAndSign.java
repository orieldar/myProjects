package bgu.spl.a2.sim.actions;

import java.util.List;

import bgu.spl.a2.Action;
import bgu.spl.a2.Promise;
import bgu.spl.a2.sim.Computer;
import bgu.spl.a2.sim.privateStates.StudentPrivateState;


/**
 * {@link CheckAndSign} is an inner action used by {@link CheckAdministrativeObligations}
 * that checks the relevent courses and signs the signature accordingly
 * 
 */
public class CheckAndSign extends Action<Boolean>{

	private Computer computer;
	private List<String> courses;

	
	/**
	 *constructor that creates a {@CheckAndSign }
	 * 
	 * @param computer the computer used
	 * @param courses the courses to check
	 */
	public CheckAndSign(Computer computer, List<String> courses){
		this.computer = computer;
		this.courses = courses;
		result=new Promise<Boolean>();
		actionName = "Check And Sign";
	}
	
	/**
     * start handling the action - 
     * sets the signature
     */
	@Override
	protected void start() {
		((StudentPrivateState) actorState).setSignature(computer.checkAndSign(courses, ((StudentPrivateState) actorState).getGrades()));
		complete(true);
	}

}
