package bgu.spl.a2.sim.actions;

import java.util.ArrayList;
import java.util.List;
import bgu.spl.a2.Action;
import bgu.spl.a2.Promise;
import bgu.spl.a2.sim.privateStates.CoursePrivateState;
import bgu.spl.a2.sim.privateStates.StudentPrivateState;
/**
 * {@link UnregisterAllStudents}   An inner action that unregisters all the students from
 * a specific course
 * 
 */
public class UnRegisterAllStudents extends Action<Boolean>{
	
	
	/**
	 *no args constructor 
	 *
	 */
	public UnRegisterAllStudents(){
		result=new Promise<Boolean>();
		actionName="Unregister All Students";

	}
	/**
	 * start handling the action -
	 * unregisters all the students using {@link Unregister} action, and
	 * sets the available spots to -1.=
	 */
	@Override
	protected void start() {
		List<String> studentsInCourse = ((CoursePrivateState) actorState).getRegStudents();
		((CoursePrivateState) actorState).setAvailableSpots( ((-1)*(studentsInCourse.size())) -1 );
		List<Action<Boolean>> actions = new ArrayList<>();
		for(String student : studentsInCourse){
			Action<Boolean> unRegister = new Unregister(student);
			sendMessage(unRegister, actorId, actorState);
			actions.add(unRegister);
		}
			if(actions.isEmpty())
				complete(true);
			else				
				then(actions,()->{complete(true);});
		}
}
