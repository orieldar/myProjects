package bgu.spl.a2.sim.actions;

import bgu.spl.a2.Action;
import bgu.spl.a2.Promise;
import bgu.spl.a2.sim.privateStates.StudentPrivateState;

/**
 *  an inner action, that
 * removes a students course and grade from his grades list
 * 
 */
public class RemoveCourseFromGradeList extends Action<Boolean>{
	
	private	String courseId;
	
	/**
	 *constructor 
	 *
	 *@param coursesId the course to remove
	 */
	public RemoveCourseFromGradeList(String courseId){
		this.courseId = courseId;
		result=new Promise<Boolean>();
		actionName = "Remove Course From GradeList";
	}
	/**
	 * start handling the action 
	 */
	@Override
	protected void start() {
		((StudentPrivateState)(actorState)).removeCourse(courseId);
		complete(true);
	}
	
}
