package bgu.spl.a2.sim.actions;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import bgu.spl.a2.Action;
import bgu.spl.a2.Promise;
import bgu.spl.a2.sim.privateStates.CoursePrivateState;
import bgu.spl.a2.sim.privateStates.DepartmentPrivateState;
import bgu.spl.a2.sim.privateStates.StudentPrivateState;

/**
 * {@link AddStudentToDepartment} is an action that adds a student to the department,
 * and creates the students actor
 * 
 */
public class AddStudentToDepartment extends Action<Boolean>{

	@SerializedName("Department")
	@Expose
	private String departmentid;
	@SerializedName("Student")
	private	String studentId;
	
	/**
	 * no args constructor
	 * 
	 */
	public AddStudentToDepartment(){
		actionName = "Add Student";
		result=new Promise<Boolean>();
	}
	/**
	 * constructor
	 * 
	 * @param studentId the student to add to the department
	 */
	public AddStudentToDepartment(String studentId){
		actionName = "Add Student";
		this.studentId = studentId;
		result=new Promise<Boolean>();
	}
	
	/**
     * start handling the action - and add the action to the log,
     * creates the student actor and add student to the department
     */
	@Override
	protected void start() {
		actorState.addRecord(getActionName());
		if((StudentPrivateState) pool.getPrivateState(studentId) == null){
			
			AddState addStateAction = new AddState();
			pool.submit(addStateAction, studentId, new StudentPrivateState()); 
		}
		((DepartmentPrivateState)this.actorState).addStudent(studentId);
		complete(true);
	}
	
	/**
	 * sets the actor id after the serialization, and returns it 
	 * 
	 * @return the actors id
	 */
	public String setAndGetActorId(){
	actorId=departmentid;
	return actorId;
	}
}