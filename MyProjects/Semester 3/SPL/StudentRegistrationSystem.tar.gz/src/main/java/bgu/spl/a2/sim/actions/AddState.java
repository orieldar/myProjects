package bgu.spl.a2.sim.actions;

import bgu.spl.a2.Action;
import bgu.spl.a2.Promise;
/**
 *  an inner action, that
 * adds a new actor to the actors hash map 
 * 
 */
public class AddState extends Action<Boolean> {
	/**
	 * constructor that creates a {@link AddState}
	 * 
	 */
	public AddState(){
		actionName = "AddStateAction";
		result=new Promise<Boolean>();
	}
	/**
     * start handling the action 
     */
	@Override
	protected void start() {
		complete(true);
	}

}
