/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bgu.spl.a2.sim;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CountDownLatch;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import bgu.spl.a2.ActorThreadPool;
import bgu.spl.a2.PrivateState;
import bgu.spl.a2.sim.actions.AddStudentToDepartment;
import bgu.spl.a2.sim.actions.CheckAdministrativeObligations;
import bgu.spl.a2.sim.actions.CloseACourse;
import bgu.spl.a2.sim.actions.NewplacesInCourse;
import bgu.spl.a2.sim.actions.OpenANewCourse;
import bgu.spl.a2.sim.actions.ParticipatingInCourse;
import bgu.spl.a2.sim.actions.RegisterWithPreferences;
import bgu.spl.a2.sim.actions.Unregister;
import bgu.spl.a2.sim.privateStates.CoursePrivateState;
import bgu.spl.a2.sim.privateStates.DepartmentPrivateState;
import bgu.spl.a2.sim.privateStates.StudentPrivateState;

/**
 * A class describing the simulator for part 2 of the assignment
 */
public class Simulator {

	private static Warehouse warehouse;
	public static ActorThreadPool actorThreadPool;
	private static JsonObject input;
	private static Gson gson;
	private static CountDownLatch CDL1;
	private static CountDownLatch CDL2;
	private static CountDownLatch CDL3;
	
	/**
	* Begin the simulation Should not be called before attachActorThreadPool()
	* 
	* Parses the JasonObject input into three phases and gets the computers
	* inserting them into the warehouse.
	* furthermore initialises the 3 coundownLatches used to keep track of the actions
	* completed in each phase
	* 
	* starts and ends the threadpool , and parses the hashmap return into
	* a .ser file
	*/
    public static void start(){
    	
    	JsonArray computers = input.getAsJsonArray("Computers");
    	List<Computer> computerList = new LinkedList<Computer>();
    	
    	for(int i=0; i<computers.size();i++){
    	Computer comp = gson.fromJson(computers.get(i), Computer.class);
    	computerList.add(comp);
    	}
    	warehouse = new Warehouse(computerList);
    	
	    JsonArray phase1 = input.getAsJsonArray("Phase 1");
	    JsonArray phase2 = input.getAsJsonArray("Phase 2");
	    JsonArray phase3 = input.getAsJsonArray("Phase 3");
	    
	    CDL1=new CountDownLatch(phase1.size());
	    CDL2=new CountDownLatch(phase2.size());
	    CDL3=new CountDownLatch(phase3.size());
	  	submitPhase(phase1,CDL1);
	  	actorThreadPool.start();
	  	try {
			CDL1.await();
		} catch (InterruptedException e) {}
	  	submitPhase(phase2,CDL2);
	  	try {
			CDL2.await();
		} catch (InterruptedException e) {}
	  	submitPhase(phase3,CDL3);
		try {
			CDL3.await();
		} catch (InterruptedException e) {}
    	

    }
	
	/**
	* attach an ActorThreadPool to the Simulator, this ActorThreadPool will be used to run the simulation
	* 
	* @param myActorThreadPool - the ActorThreadPool which will be used by the simulator
	*/
	public static void attachActorThreadPool(ActorThreadPool myActorThreadPool){
		actorThreadPool = myActorThreadPool;
	}
	
	/**
	* shut down the simulation
	* returns list of private states
	*/
	public static HashMap<String,PrivateState> end(){
		try {
			actorThreadPool.shutdown();
		} catch (InterruptedException e) {	}
		

		return (HashMap<String, PrivateState>) actorThreadPool.getActors();
	}
	
	private static void submitPhase(JsonArray phase, CountDownLatch cdl){

		for(int i=0; i<phase.size(); i++){
		    JsonObject act = (JsonObject) (phase.get(i));
		    String actiontype = (String) act.get("Action").getAsString();
	
	        switch(actiontype)
	        {
	            case "Open Course":
	            	OpenANewCourse newcourse = gson.fromJson(act,OpenANewCourse.class );
	            	String OCactor = newcourse.setAndGetActorId();
	            	newcourse.getResult().subscribe(()->{cdl.countDown(); });
	            	if(actorThreadPool.getPrivateState(OCactor)==null)
	            		actorThreadPool.submit(newcourse, OCactor, new DepartmentPrivateState());
	            	else
	            	actorThreadPool.submit(newcourse, OCactor, actorThreadPool.getPrivateState(OCactor));
	                break;
	            case "Add Student":
	            	AddStudentToDepartment addstudent = gson.fromJson(act,AddStudentToDepartment.class );
	            	addstudent.getResult().subscribe(()->{cdl.countDown(); });
	            	String ATDactor = addstudent.setAndGetActorId();
	            	if(actorThreadPool.getPrivateState(ATDactor)==null)
	            		actorThreadPool.submit(addstudent, ATDactor, new DepartmentPrivateState());
	            	else
	            	actorThreadPool.submit(addstudent, ATDactor, actorThreadPool.getPrivateState(ATDactor));
	                break;
	            case "Participate In Course":
	               	ParticipatingInCourse parincourse = gson.fromJson(act,ParticipatingInCourse.class );
	               	parincourse.getResult().subscribe(()->{cdl.countDown(); });
	               	String PICactor = parincourse.setAndGetActorId();
	            	if(actorThreadPool.getPrivateState(PICactor)==null)
	            		actorThreadPool.submit(parincourse, PICactor, new CoursePrivateState());
	            	else
	            	actorThreadPool.submit(parincourse, PICactor, actorThreadPool.getPrivateState(PICactor));
	                break;
	            case "Add Spaces":
	            	NewplacesInCourse newplaces = gson.fromJson(act,NewplacesInCourse.class );
	            	newplaces.getResult().subscribe(()->{cdl.countDown(); });
	            	String ASactor = newplaces.setAndGetActorId();
	            	if(actorThreadPool.getPrivateState(ASactor)==null)
	            		actorThreadPool.submit(newplaces, ASactor, new CoursePrivateState());
	            	actorThreadPool.submit(newplaces, ASactor, actorThreadPool.getPrivateState(ASactor));
	                break;
	            case "Register With Preferences":
	            	RegisterWithPreferences registerwithpre = gson.fromJson(act,RegisterWithPreferences.class );
	            	registerwithpre.getResult().subscribe(()->{cdl.countDown(); });
	            	String RWPactor = registerwithpre.setAndGetActorId();
	            	if(actorThreadPool.getPrivateState(RWPactor)==null)
	            		actorThreadPool.submit(registerwithpre, RWPactor, new DepartmentPrivateState());
	            	actorThreadPool.submit(registerwithpre, RWPactor, actorThreadPool.getPrivateState(RWPactor));
	                break;
	            case "Unregister":
	            	Unregister unregister = gson.fromJson(act,Unregister.class );
	            	unregister.getResult().subscribe(()->{cdl.countDown(); });
	            	String URactor = unregister.setAndGetActorId();
	            	if(actorThreadPool.getPrivateState(URactor)==null)
	            		actorThreadPool.submit(unregister, URactor, new CoursePrivateState());
	            	actorThreadPool.submit(unregister, URactor, actorThreadPool.getPrivateState(URactor));
	                break;
	            case "Close Course":
	            	CloseACourse closeCourse = gson.fromJson(act,CloseACourse.class );
	            	closeCourse.getResult().subscribe(()->{cdl.countDown(); });
	            	String CCactor = closeCourse.setAndGetActorId();
	            	if(actorThreadPool.getPrivateState(CCactor)==null)
	            		actorThreadPool.submit(closeCourse, CCactor, new DepartmentPrivateState());
	            	actorThreadPool.submit(closeCourse, CCactor, actorThreadPool.getPrivateState(CCactor));
	                break;
	            case "Administrative Check":
	            	CheckAdministrativeObligations checkAd = gson.fromJson(act,CheckAdministrativeObligations.class );
	            	checkAd.getResult().subscribe(()->{cdl.countDown(); });
	            	String ACactor = checkAd.setAndGetActorId(warehouse);
	            	if(actorThreadPool.getPrivateState(ACactor)==null)
	            		actorThreadPool.submit(checkAd, ACactor, new DepartmentPrivateState());
	            	actorThreadPool.submit(checkAd, ACactor, actorThreadPool.getPrivateState(ACactor));
	                break;
	            default:
	                break;
	        }
		}
	}
	
	
	/**
	 * The Main method called
	 */
	public static void main(String [] args){
		
		gson = new Gson();
	    JsonParser parser = new JsonParser();
	    input = new JsonObject();
		try {
			input = (JsonObject) parser.parse(new FileReader(args[0]));
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
	    int threads = (int) input.get("threads").getAsInt();
		ActorThreadPool myActorThreadPool = new ActorThreadPool(threads);
		
		attachActorThreadPool(myActorThreadPool);
		start();
		
		HashMap<String,PrivateState> SimulationResult;
		SimulationResult = end();
		
		FileOutputStream fout;
		try {
			fout = new FileOutputStream("result.ser");
			ObjectOutputStream oos = new ObjectOutputStream(fout);
			oos.writeObject(SimulationResult);
		} catch (IOException e) {}
		
		
		
	}

	

}
