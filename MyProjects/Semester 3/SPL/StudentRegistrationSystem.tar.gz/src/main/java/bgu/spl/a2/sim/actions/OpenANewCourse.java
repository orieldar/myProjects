package bgu.spl.a2.sim.actions;

import java.util.LinkedList;
import java.util.List;

import javax.swing.plaf.basic.BasicSliderUI.ActionScroller;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import bgu.spl.a2.Action;
import bgu.spl.a2.PrivateState;
import bgu.spl.a2.Promise;
import bgu.spl.a2.sim.privateStates.CoursePrivateState;
import bgu.spl.a2.sim.privateStates.DepartmentPrivateState;
/**
 * {@link OpenANewCourse}   This action opens a new course in a specied department. The course has an initially
 * available spaces and a list of prerequisites
 * 
 */
public class OpenANewCourse extends Action<Boolean> {


	@SerializedName("Department")
	@Expose
	private String departmentid;
	@SerializedName("Course")
	@Expose
	private	String courseId;
	@SerializedName("Space")
	@Expose
	private String initSpots;
	@SerializedName("Prerequisites")
	@Expose
	private String[] preq;
	private List<String> prerequisites;
	
	private CoursePrivateState coursePrivateState;
	
	/**
	 *no args constructor 
	 * 
	 */
	public OpenANewCourse(){
		actionName = "Open Course";
		this.coursePrivateState = new CoursePrivateState();
		prerequisites  = new LinkedList<String>();
		result=new Promise<Boolean>();
	}
	
	
	/**
	 *constructor 
	 *@param courseId the courses id
	 *@param initSpots the initial available spots in the course
	 *@param prerequisites the prequisites required for registering for a course 
	 */
	public OpenANewCourse(String courseId, String initSpots, List<String> prerequisites){
		actionName = "Open Course";
		result=new Promise<Boolean>();
		this.courseId = courseId;
		this.coursePrivateState = new CoursePrivateState();
		this.coursePrivateState.setAvailableSpots(Integer.parseInt(initSpots));
		this.coursePrivateState.setPrequisites(prerequisites); //
	}
	
	/**
	 * start handling the action - and add action to the log,
	 * sends an action to add a Coursestate and adds the course
	 * to the department
	 */
	@Override
	protected void start() {
		actorState.addRecord(getActionName());//add action to log
		AddState addStateAction = new AddState();
		sendMessage(addStateAction, courseId, coursePrivateState).subscribe(()-> {complete(true);});
		((DepartmentPrivateState)this.actorState).addCourse(courseId);
	}
	
	/**
	 * sets the actor id after the serialization, and returns it , 
	 * converts the prequistes array into a list
	 * 
	 * @return the actors id
	 */
	public String setAndGetActorId(){
		this.coursePrivateState.setAvailableSpots(Integer.parseInt(initSpots));
		this.coursePrivateState.setPrequisites(prerequisites);
		actorId=departmentid;
		for(String pre : preq)
			prerequisites.add(pre);
			
	return actorId;
	}
	
	
}
