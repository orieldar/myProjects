package bgu.spl.a2.sim;

import java.util.List;
import java.util.Map;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import bgu.spl.a2.VersionMonitor;

public class Computer {
	@SerializedName("Type")
	@Expose
	private String computerType;
	@SerializedName("Sig Success")
	@Expose
	private long successSig;
	@SerializedName("Sig Fail")
	@Expose
	private long failSig;
	
	/**
	 * creates a {@link Computer} and holds its type (name)
	 * @param computer type the computers type (name)
	 * 				
	 * 
	 	 */
	public Computer(String computerType) {
		this.computerType = computerType;
	}
	
	/**
	 * setter for the fail signature,
	 *
	 * @param failSig the new fail signature
	 *            
	 */
	public void setFailSig(String failSig){
		this.failSig = Long.parseLong(failSig);
	}
	
	/**
	 * setter for the success signature,
	 *
	 * @param successSig the new success signature
	 *            
	 */
	public void setSuccessSig(String successSig){
		this.successSig = Long.parseLong(successSig);
	}
	
	/**
	 * getter for the fail signature,
	 *
	 * @return the new fail signature
	 *            
	 */
	public long getFailSig(){
		return failSig ;
	}
	
	/**
	 * getter for the success signature,
	 *
	 * @return the new success signature
	 *            
	 */
	public long getSuccessSig(){
		return successSig;
	}
	
	/**
	 * getter for the computer type,
	 *
	 * @return the computers type(name)
	 *            
	 */
	public String getType(){
		return computerType;
	}
	
	/**
	 * this method checks if the courses' grades fulfill the conditions
	 * @param courses
	 * 							courses that should be pass
	 * @param coursesGrades
	 * 							courses' grade
	 * @return a signature if couersesGrades grades meet the conditions
	 */
	public long checkAndSign(List<String> courses, Map<String, Integer> coursesGrades){
		Integer grade;
		for(String course : courses){
			grade = coursesGrades.get(course);
			if((grade == null) || (grade < 56))
				return failSig;
		}
		return successSig;
		}
}
