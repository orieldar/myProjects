package bgu.spl.a2.sim.actions;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import bgu.spl.a2.Action;
import bgu.spl.a2.Promise;
import bgu.spl.a2.sim.privateStates.CoursePrivateState;

/**
 * {@link RegisterWithPreferences}   as in Participate In Course, here we are given a list of grades, each
 * grade for a course, and try to register the student to the courses by his preferences. The students registers
 * for only one course or no course at all if he dosent meet any of the conditions.
 * 
 */
public class RegisterWithPreferences extends Action<Boolean>{

	@SerializedName("Student")
	@Expose
	private	String studentId;
	@SerializedName("Preferences")
	@Expose
	private List<String> courses;
	@SerializedName("Grade")
	@Expose
	private List<String> grades;
	
	private boolean first;

	/**
	 *no args constructor 
	 * 
	 */
	public RegisterWithPreferences(){ //
		actionName = "Register With Preferences";
		result=new Promise<Boolean>();
		first=true;

	}
	/**
	 *constructor 
	 *@param courses list of the preferable courses
	 *@param grades list of the grades for the courses accordingly 
	 */
	public RegisterWithPreferences(List<String> courses, List<String> grades){ //subbmitted to the student actor
			actionName = "Register With Preferences";
			result=new Promise<Boolean>();
			this.courses = courses;
			this.grades = grades;
		}
	
	/**
	 * start handling the action - and add action to the log,
	 * trys to participate in the course one by one, unitl he succeeds using
	 * the {@link ParticipatingInCourse} action.
	 */
		@Override
		protected void start() {
			if(first) {
			actorState.addRecord(getActionName());
			first = false;
			}
			
			if(courses.isEmpty())
				complete(false);
			else{
				String courseId = courses.get(0);
				String courseGrade = grades.get(0);
				CoursePrivateState coursePriveState = (CoursePrivateState) pool.getPrivateState(courseId);
				ParticipatingInCourse tryParticipateInCourse = new ParticipatingInCourse(actorId, courseGrade);
				sendMessage(tryParticipateInCourse, courseId, coursePriveState).subscribe(()->
				{
					if(tryParticipateInCourse.getResult().get()) //succeeded to register 
						complete(true);
					else{ // failed to register
						courses.remove(0);
						pool.submit(this, actorId, actorState);
					}
				});
			}
		}
		
		/**
		 * sets the actor id after the serialization, and returns it , 
		 * 
		 * @return the actors id
		 */
		public String setAndGetActorId(){
			actorId=studentId;
			return actorId;
			}
					
	}
