package bgu.spl.a2.sim.actions;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import bgu.spl.a2.Action;
import bgu.spl.a2.Promise;
import bgu.spl.a2.sim.privateStates.CoursePrivateState;
import bgu.spl.a2.sim.privateStates.StudentPrivateState;
/**
 * {@link Unregister}   If the student is enrolled in the course, this action unregisters him (updates the
 *list of students of course, removes the course from the grades sheet of the student and increases the
 *number of available spaces).
 * 
 */
public class Unregister extends Action<Boolean>{
	
	@SerializedName("Student")
	@Expose
	private	String studentId;
	@SerializedName("Course")
	@Expose
	private	String courseId;

	private StudentPrivateState studentPrivateState;
	
	/**
	 *no args constructor 
	 *
	 */
	public Unregister(){
		actionName="Unregister";
		result=new Promise<Boolean>();
		
	}
	
	/**
	 *constructor 
	 *@param studentId the student to unregister
	 */
	public Unregister(String studentId){
		actionName="Unregister";
		result=new Promise<Boolean>();
		this.studentId = studentId;

	}
	/**
	 * start handling the action - add action to the log,
	 * removes the course from the grade list using {@link RemoveCourseFromGradeList} action and
	 * sets the available spots
	 */
	@Override
	protected void start() {
		actorState.addRecord(getActionName());
		studentPrivateState = (StudentPrivateState) pool.getPrivateState(studentId);
		if(((CoursePrivateState) actorState).removeStudent(studentId)){
			Action<Boolean> removeCourseFromGradeList = new RemoveCourseFromGradeList(actorId);
			sendMessage(removeCourseFromGradeList, studentId, studentPrivateState);
			List<Action<Boolean>> actions = new ArrayList<>();
			actions.add(removeCourseFromGradeList);
			then(actions,()->
			{
				if(actions.get(0).getResult().get()){
					((CoursePrivateState) actorState).setAvailableSpots(((CoursePrivateState) actorState).getAvailableSpots().intValue()+1);
					complete(actions.get(0).getResult().get());
				}
				else
					complete(actions.get(0).getResult().get());		
					
			});
		}
		else
			complete(false);
	}
	
	/**
	 * sets the actor id after the serialization, and returns it , 
	 * 
	 * @return the actors id
	 */
	public String setAndGetActorId(){
		actorId=courseId;
		return actorId;
		}
}
