package bgu.spl.a2.sim.actions;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import bgu.spl.a2.Action;
import bgu.spl.a2.Promise;
import bgu.spl.a2.sim.privateStates.CoursePrivateState;
import bgu.spl.a2.sim.privateStates.StudentPrivateState;

/**
 * {@link CheckPrequisitesForCourse}   an action used by {@link ParticipatingInCourse} to check
 * if a students has the relevent preqyuistes for a cours he wants to
 * participate in
 * 
 */
public class CheckPrequisitesForCourse extends Action<Boolean>{
	
	private List<String> preCourses;
	
	/**
	 *constructor that creates a {@CheckPrequisitesForCourse }
	 * 
	 * @param preCourses the prequisites to check
	 * @param courses the courses to check
	 */
	public CheckPrequisitesForCourse(List<String> preCourses){
		this.preCourses = preCourses;
		result=new Promise<Boolean>();
		actionName = "Check Prequisites For Course";
		
	}
	/**
     * start handling the action - 
     * comlpletes true if student has all the courses needed,
     * and false otherwise
     */
	@Override
	protected void start() {
		Set<String> studentCourses = (((StudentPrivateState) actorState).getGrades()).keySet();
		if(studentCourses.containsAll(preCourses))
			complete(true);
		else
			complete(false);
			
		}			
	}
