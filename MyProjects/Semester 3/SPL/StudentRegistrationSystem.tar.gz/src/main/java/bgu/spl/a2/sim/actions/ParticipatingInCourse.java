package bgu.spl.a2.sim.actions;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import bgu.spl.a2.Action;
import bgu.spl.a2.Promise;
import bgu.spl.a2.sim.privateStates.CoursePrivateState;
import bgu.spl.a2.sim.privateStates.DepartmentPrivateState;
import bgu.spl.a2.sim.privateStates.StudentPrivateState;
/**
 * {@link ParticipatingInCourse}   This action tries to register the student in the course, if it succeeds, it adds the
 * course to the grades sheet of the student, and gives him a grade if supplied
 * 
 */
public class ParticipatingInCourse extends Action<Boolean>{

	@SerializedName("Student")
	@Expose
	private	String studentId;
	@SerializedName("Course")
	@Expose
	private String courseId;
	@SerializedName("Grade")
	@Expose
	private String[] StringcourseGrade; 
	private Integer courseGrade;
	
	private StudentPrivateState studentPrivateState;
	
	/**
	 *no args constructor 
	 * 
	 */
	public ParticipatingInCourse(){
		result=new Promise<Boolean>();
		actionName = "Participate In Course";
	}
	/**
	 *constructor 
	 *
	 * @param studentId the student to register
	 * @param the students course grade
	 */
	public ParticipatingInCourse(String studentId, String courseGrade){
		this.studentId = studentId;
		actionName = "Participate In Course";
		result=new Promise<Boolean>();
		if(courseGrade.equals("-"))
			this.courseGrade = new Integer(-1);
		else
			this.courseGrade = new Integer(Integer.parseInt(courseGrade));
	}
	/**
	 * start handling the action - and add action to the log,
	 * checks if the course has available spots, if so checks if the student is
	 * registered to the prequistes (if they exist) by {@link CheckPrequisitesForCourse} , 
	 * and registers the student accordingly
	 */
	@Override
	protected void start() {
		actorState.addRecord(getActionName());//add action to log
		studentPrivateState = (StudentPrivateState) pool.getPrivateState(studentId);
		if(((CoursePrivateState) actorState).getAvailableSpots()<=0) 
			complete(false);
		else{
			List<String> preCourses = ((CoursePrivateState) actorState).getPrequisites();
			if( ! preCourses.isEmpty()){
				CheckPrequisitesForCourse checkStudentPreCourses = new CheckPrequisitesForCourse(preCourses);
				sendMessage(checkStudentPreCourses, studentId, studentPrivateState);
				List<Action<Boolean>> actions = new ArrayList<>();
				actions.add(checkStudentPreCourses);
				then(actions,()->
				{
					if((((CoursePrivateState) actorState).getAvailableSpots()<=0)||(!actions.get(0).getResult().get())) 
						complete(false);
					else{
						((CoursePrivateState) actorState).addStudent(studentId);
						sendMessage(new AddCourseToGradeList(actorId, courseGrade), studentId, studentPrivateState).subscribe(()->
						{
							complete(true); 
						});
						}
				});
			}
			else{
				((CoursePrivateState) actorState).addStudent(studentId);
				sendMessage(new AddCourseToGradeList(actorId, courseGrade), studentId, studentPrivateState).subscribe(()->
				{
					complete(true);
				});
				}
				
			}
	}
	
	/**
	 * sets the actor id after the serialization, and returns it , 
	 * converts the course grade into an integer
	 * 
	 * @return the actors id
	 */
	public String setAndGetActorId(){
		if(StringcourseGrade[0].equals("-"))
			this.courseGrade = new Integer(-1);
		else
			this.courseGrade = new Integer(Integer.parseInt(StringcourseGrade[0]));
	actorId=courseId;
	return actorId;
	}
}


