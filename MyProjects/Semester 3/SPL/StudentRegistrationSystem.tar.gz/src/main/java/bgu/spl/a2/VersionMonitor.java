package bgu.spl.a2;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Describes a monitor that supports the concept of versioning - its idea is
 * simple, the monitor has a version number which you can receive via the method
 * {@link #getVersion()} once you have a version number, you can call
 * {@link #await(int)} with this version number in order to wait until this
 * version number changes.
 *
 * you can also increment the version number by one using the {@link #inc()}
 * method.
 *
 * Note for implementors: you may add methods and synchronize any of the
 * existing methods in this class *BUT* you must be able to explain why the
 * synchronization is needed. In addition, the methods you add can only be
 * private, protected or package protected - in other words, no new public
 * methods
 */
public class VersionMonitor {
	
	AtomicInteger version;
	
	/**
	 * creates a {@link VersionMonitor} which holds an Atomic integer
	 * starting at zero, which keeps track of the version number
	 */
	public VersionMonitor(){
		version = new AtomicInteger(0);
	}
	
	/**
	 * getter for the version,
	 * returns the private state actions that have been executed
	 *
	 * @return the current version number
	 *            
	 */
    public int getVersion() {
        return version.get();
    }
    
	/**
	 * increments the version by one,
	 * and notify's all the the threads waiting on the current version
	 *
	 *            
	 */
    public void inc() {
    	synchronized(version){ //need to be synchronized with the await method because we need to make the Thread wait while synch on the version Object. and to wake him up only when the version is changed
    		version.getAndIncrement(); 
    		version.notifyAll();
    	}
    }
    
    /**
	 * 
	 * checks if the current version is the same a the input version.
	 * if so' waits on the current version until it is changed
	 * 
	 * @param version
	 *            the number the current version is compared to
	 *            
	 */
    public void await(int version) throws InterruptedException {
    	synchronized(this.version){ // same reason as mentioned above
    		while(this.version.get() == version)
    			(this.version).wait();
    	}
    	}
    }
